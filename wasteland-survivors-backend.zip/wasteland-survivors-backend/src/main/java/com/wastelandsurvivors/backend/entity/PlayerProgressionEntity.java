package com.wastelandsurvivors.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Player EXP and level progression per world — persisted in {@code player_progression}.
 *
 * <p>Separated from player_world_state because progression changes less frequently
 * than position/health, which avoids lock contention during combat-heavy sessions.</p>
 *
 * <h3>Unity source mapping</h3>
 * <ul>
 *   <li>{@code experience} → ExpManager.currentExp</li>
 *   <li>{@code level} → ExpManager.level</li>
 *   <li>{@code expToLevel} → ExpManager.expToLevel</li>
 *   <li>{@code expGrowthMultiplier} → ExpManager.expGrowthMultiplier</li>
 * </ul>
 */
@Entity
@Table(name = "player_progression",
       uniqueConstraints = @jakarta.persistence.UniqueConstraint(columnNames = {"player_id", "world_id"}))
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PlayerProgressionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "player_id", nullable = false)
    private Long playerId;

    @Column(name = "world_id", nullable = false, length = 64)
    private String worldId;

    /**
     * Total EXP earned so far.
     * When experience >= expToLevel, a level-up occurs.
     * Maps to: ExpManager.currentExp
     */
    @Column(nullable = false)
    @Builder.Default
    private long experience = 0L;

    /**
     * Current player level. Starts at 1.
     * Maps to: ExpManager.level
     */
    @Column(nullable = false)
    @Builder.Default
    private int level = 1;

    /**
     * EXP threshold needed for the next level-up.
     * After each level-up, this is multiplied by expGrowthMultiplier.
     * Maps to: ExpManager.expToLevel
     */
    @Column(name = "exp_to_level", nullable = false)
    @Builder.Default
    private long expToLevel = 10L;

    /**
     * Multiplier applied to expToLevel after each level-up.
     * Default 1.2 means each level requires 20% more EXP than the last.
     * Maps to: ExpManager.expGrowthMultiplier
     */
    @Column(name = "exp_growth_multiplier", nullable = false)
    @Builder.Default
    private float expGrowthMultiplier = 1.2f;

    /**
     * Last time progression was updated.
     */
    @Column(name = "updated_at", nullable = false, insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}
