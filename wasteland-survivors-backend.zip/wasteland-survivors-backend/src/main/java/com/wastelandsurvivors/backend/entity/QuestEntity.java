package com.wastelandsurvivors.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Quest state per world — persisted in {@code quests}.
 * Tracks quests with a 4-state machine. Supports multiple quests per world
 * via the questId discriminator (e.g., "sara_village", "quest2").
 *
 * <p>State machine:
 * <ul>
 *   <li>0 — Not Started (quest not yet accepted from NPC)</li>
 *   <li>1 — Active (tracking objectives)</li>
 *   <li>2 — Objectives Complete (return to NPC)</li>
 *   <li>3 — Handed In (reward collected, quest finalized)</li>
 * </ul></p>
 *
 * <h3>Unity source mapping</h3>
 * <ul>
 *   <li>{@code questState} → SimpleQuestManager.QuestState</li>
 *   <li>{@code zombiesRemaining} → SimpleQuestManager.ZombiesRemaining (Sara quest)</li>
 *   <li>{@code isBossAlive} → SimpleQuestManager.IsBossAlive (Sara quest)</li>
 *   <li>{@code questId} → quest discriminator string for multi-quest support</li>
 *   <li>{@code objectivesJson} → flexible JSON for Quest2 objectives</li>
 * </ul>
 */
@Entity
@Table(name = "quests",
       uniqueConstraints = @jakarta.persistence.UniqueConstraint(columnNames = {"world_id", "quest_id"}))
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class QuestEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Which world this quest belongs to.
     * Combined with questId to form the unique key (world_id, quest_id).
     */
    @Column(name = "world_id", nullable = false, length = 64)
    private String worldId;

    /**
     * Quest discriminator — enables multiple quests per world.
     * Default: "sara_village" (the original Clear the Village quest).
     * Quest2 uses its own identifier, e.g., "quest2".
     *
     * <p>Previous schema had unique constraint on world_id alone (one quest per world).
     * Now the unique constraint is on (world_id, quest_id), so a world can have
     * both "sara_village" and "quest2" quest records simultaneously.</p>
     *
     * <p>columnDefinition includes DEFAULT so Hibernate's ddl-auto=update can add
     * this column to existing tables without failing on NOT NULL for existing rows.</p>
     */
    @Column(name = "quest_id", nullable = false, length = 64,
            columnDefinition = "VARCHAR(64) NOT NULL DEFAULT 'sara_village'")
    @Builder.Default
    private String questId = "sara_village";

    /**
     * Flexible JSON blob for quest-type-specific objectives.
     * Sara quest: {"zombiesToKill": 12, "bossName": "Mutated Boss"}
     * Quest2: structure TBD by the Unity Quest2 system.
     * Allows new quest types without schema migrations.
     */
    @Column(name = "objectives_json", columnDefinition = "TEXT")
    private String objectivesJson;

    /**
     * Current quest phase: 0=NotStarted, 1=Active, 2=Complete, 3=HandedIn.
     * Maps to: SimpleQuestManager.QuestState
     */
    @Column(name = "quest_state", nullable = false)
    @Builder.Default
    private int questState = 0;

    /**
     * How many zombies the player still needs to kill. Starts at 12.
     * Maps to: SimpleQuestManager.ZombiesRemaining
     */
    @Column(name = "zombies_remaining", nullable = false)
    @Builder.Default
    private int zombiesRemaining = 12;

    /**
     * Whether the Mutated Boss is still alive. Initially true.
     * Maps to: SimpleQuestManager.IsBossAlive
     */
    @Column(name = "is_boss_alive", nullable = false)
    @Builder.Default
    private boolean isBossAlive = true;

    @Column(name = "updated_at", nullable = false, insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}
