package com.wastelandsurvivors.backend.service;

import com.wastelandsurvivors.backend.dto.response.FriendResponse;
import com.wastelandsurvivors.backend.dto.response.InviteCodeResponse;

import java.util.List;

/**
 * Declares friend management capabilities for the Wasteland Survivors backend.
 *
 * <p>Friendship is bidirectional — when player A adds player B, both can see
 * each other in their friends lists. This matches the social model used by
 * Unity's FriendMenuManager.</p>
 *
 * <p>Invite/join functionality delegates to {@link LobbyService} for session
 * creation and join-key management, reusing the existing multiplayer lobby
 * infrastructure.</p>
 */
public interface FriendService {

    /**
     * Adds a friend relationship between two players.
     * Creates rows in both directions so each player sees the other.
     *
     * @param playerId The player adding a friend
     * @param friendId The player being added
     * @return FriendResponse with the friend's info
     * @throws com.wastelandsurvivors.backend.exception.GameException
     *         if the friend does not exist or the friendship already exists
     */
    FriendResponse addFriend(Long playerId, Long friendId);

    /**
     * Removes a friend relationship between two players.
     * Deletes rows in both directions.
     *
     * @param playerId The player removing a friend
     * @param friendId The friend being removed
     * @throws com.wastelandsurvivors.backend.exception.GameException
     *         if the friendship does not exist
     */
    void removeFriend(Long playerId, Long friendId);

    /**
     * Returns all friends for a player with their usernames and last-login times.
     *
     * @param playerId The player whose friends to list
     * @return List of FriendResponse (empty if no friends)
     */
    List<FriendResponse> getFriends(Long playerId);

    /**
     * Generates an invite code for the player to share with a friend.
     * Creates a lobby session (via LobbyService) and returns the 6-character
     * join key. The friend uses {@link #joinFriend} with this code.
     *
     * @param playerId The player generating the invite
     * @param worldId   The world to invite the friend into
     * @return InviteCodeResponse with the join code and session ID
     */
    InviteCodeResponse generateInviteCode(Long playerId, String worldId);

    /**
     * Joins a friend's session using an invite code.
     * Delegates to LobbyService.joinSession.
     *
     * @param playerId   The player joining
     * @param inviteCode The 6-character code from {@link #generateInviteCode}
     * @return InviteCodeResponse with session details
     * @throws com.wastelandsurvivors.backend.exception.GameException
     *         if the code is invalid or the session is full
     */
    InviteCodeResponse joinFriend(Long playerId, String inviteCode);
}
