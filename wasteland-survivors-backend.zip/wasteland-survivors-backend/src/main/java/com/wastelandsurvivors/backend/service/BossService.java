package com.wastelandsurvivors.backend.service;

import com.wastelandsurvivors.backend.entity.BossEncounterEntity;

/**
 * Declares boss encounter management per world.
 * Manages the two-phase boss fight lifecycle:
 * <ol>
 *   <li>Not started — boss trigger zone not yet entered</li>
 *   <li>Phase 1 — normal boss fight (base stats)</li>
 *   <li>Phase 2 — enraged boss (triggered when health first hits 0, restores to 100 HP, +2 damage, 1.5× speed)</li>
 *   <li>Defeated — boss killed in phase 2, quest updated</li>
 * </ol>
 */
public interface BossService {

    /**
     * Returns the boss encounter state for a world.
     *
     * @param worldId The world
     * @return BossEncounterEntity (created with defaults if none exists)
     */
    BossEncounterEntity getBossState(String worldId);

    /**
     * Starts the boss fight — sets fightStarted=true.
     * Called when the player enters the boss trigger zone.
     *
     * @param worldId     The world
     * @param bossEnemyId The enemy instance ID that IS the boss
     * @return Updated BossEncounterEntity
     */
    BossEncounterEntity startBossFight(String worldId, Long bossEnemyId);

    /**
     * Triggers Phase 2 of the boss fight — sets currentPhase=2, phase2Activated=true.
     * Called when the boss health first hits 0 (but the boss isn't truly dead yet).
     * In Phase 2: boss restores to phase2Health (100 HP), gains +2 damage,
     * and moves at phase2SpeedMultiplier (1.5×) speed.
     * Only valid when fight is started, boss is not yet defeated, and phase 2
     * hasn't already been activated.
     *
     * @param worldId The world
     * @return Updated BossEncounterEntity with currentPhase=2
     * @throws com.wastelandsurvivors.backend.exception.GameException if fight not started,
     *         boss already defeated, or phase 2 already active
     */
    BossEncounterEntity triggerPhase2(String worldId);

    /**
     * Marks the boss as defeated — sets isDefeated=true.
     * Also updates the quest system (sets isBossAlive=false).
     * Only valid from phase 2 (the boss can only be truly killed in phase 2).
     *
     * @param worldId The world
     * @return Updated BossEncounterEntity
     */
    BossEncounterEntity defeatBoss(String worldId);
}
