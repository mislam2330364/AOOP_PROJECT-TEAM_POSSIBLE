package com.wastelandsurvivors.backend.service;

import java.util.Map;

/**
 * Declares world data management capabilities.
 * A world belongs to one owner and holds the RPG game state — terrain, items, progress.
 * World state is stored per-player so solo progress and multiplayer state
 * can diverge and be saved independently.
 */
public interface WorldService {

    /**
     * Creates a new RPG world owned by the given player.
     * @param ownerId   The database ID of the player who will own this world
     * @param worldName The display name chosen by the player for this world
     * @return The server-generated world ID — Unity must store this for future load and save calls
     */
    String createWorld(Long ownerId, String worldName);

    /**
     * Loads the saved state of a world for a specific player.
     * Returns a raw map now — will be replaced with a typed World model when the database layer is built.
     * @param worldId  The world to load
     * @param playerId The player loading the world — state can differ per player
     * @return A map of world data properties
     */
    Map<String, Object> getWorld(String worldId, Long playerId);

    /**
     * Persists the current world state to storage.
     * Called on manual player save (solo mode) and automatically at the end of a multiplayer session.
     * @param worldId   The world to save
     * @param playerId  The player whose state is being saved
     * @param worldData Serialized world state sent from Unity
     */
    void saveWorld(String worldId, Long playerId, Map<String, Object> worldData);
}

