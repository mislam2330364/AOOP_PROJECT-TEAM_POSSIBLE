package com.wastelandsurvivors.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * A single line within a dialogue tree — persisted in {@code dialogue_lines}.
 * Lines are played in order (by line_index) before the branching options appear.
 *
 * <h3>Unity source mapping</h3>
 * <ul>
 *   <li>{@code lineIndex} → DialogueManager.dialogueIndex</li>
 *   <li>{@code actorId} → DialogueLine.actor (who speaks)</li>
 *   <li>{@code lineText} → DialogueLine.text (the actual words)</li>
 * </ul>
 */
@Entity
@Table(name = "dialogue_lines")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DialogueLineEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Which dialogue tree this line belongs to. FK to dialogue_trees.dialogue_id.
     */
    @Column(name = "dialogue_id", nullable = false, length = 64)
    private String dialogueId;

    /**
     * Order of this line within the dialogue. 0 = first line spoken.
     * Unique per dialogue (dialogue_id + line_index).
     */
    @Column(name = "line_index", nullable = false)
    private int lineIndex;

    /**
     * Who speaks this line. FK to npc_actors.actor_id.
     */
    @Column(name = "actor_id", nullable = false, length = 64)
    private String actorId;

    /**
     * The actual dialogue text displayed to the player.
     * Supports Unity rich text tags.
     * Maps to: DialogueLine.text
     */
    @Column(name = "line_text", nullable = false, columnDefinition = "TEXT")
    private String lineText;
}
