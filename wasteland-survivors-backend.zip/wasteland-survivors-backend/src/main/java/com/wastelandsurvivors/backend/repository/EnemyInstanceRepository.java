package com.wastelandsurvivors.backend.repository;

import com.wastelandsurvivors.backend.entity.EnemyInstanceEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Spring Data JPA repository for {@link EnemyInstanceEntity} (enemy_instances table).
 */
public interface EnemyInstanceRepository extends JpaRepository<EnemyInstanceEntity, Long> {

    /**
     * Finds all enemy instances in a world, optionally filtered by alive status.
     */
    List<EnemyInstanceEntity> findByWorldIdAndIsAlive(String worldId, boolean isAlive);

    /**
     * Finds all enemy instances in a world regardless of alive status.
     */
    List<EnemyInstanceEntity> findByWorldId(String worldId);
}
