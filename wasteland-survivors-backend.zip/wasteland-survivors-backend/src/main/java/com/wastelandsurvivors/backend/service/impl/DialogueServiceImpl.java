package com.wastelandsurvivors.backend.service.impl;

import com.wastelandsurvivors.backend.entity.DialogueLineEntity;
import com.wastelandsurvivors.backend.entity.DialogueOptionEntity;
import com.wastelandsurvivors.backend.entity.DialogueTreeEntity;
import com.wastelandsurvivors.backend.entity.NpcActorEntity;
import com.wastelandsurvivors.backend.exception.GameException;
import com.wastelandsurvivors.backend.repository.DialogueLineRepository;
import com.wastelandsurvivors.backend.repository.DialogueOptionRepository;
import com.wastelandsurvivors.backend.repository.DialogueTreeRepository;
import com.wastelandsurvivors.backend.repository.NpcActorRepository;
import com.wastelandsurvivors.backend.service.DialogueService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Full implementation of {@link DialogueService}.
 *
 * <p>Quest-state-driven dialogue routing matches Unity's NPC_Talk.cs:
 * <ul>
 *   <li>State 0 (Not Started) → intro dialogue (questStateFilter=0)</li>
 *   <li>State 1 (Active) → waiting dialogue (questStateFilter=1)</li>
 *   <li>State 2 (Complete) → completion dialogue (questStateFilter=2)</li>
 *   <li>Fallback: any dialogue for the NPC without a specific quest state filter</li>
 * </ul></p>
 */
@Service
@Slf4j
public class DialogueServiceImpl implements DialogueService {

    private final NpcActorRepository npcRepository;
    private final DialogueTreeRepository treeRepository;
    private final DialogueLineRepository lineRepository;
    private final DialogueOptionRepository optionRepository;

    public DialogueServiceImpl(NpcActorRepository npcRepository,
                                DialogueTreeRepository treeRepository,
                                DialogueLineRepository lineRepository,
                                DialogueOptionRepository optionRepository) {
        this.npcRepository = npcRepository;
        this.treeRepository = treeRepository;
        this.lineRepository = lineRepository;
        this.optionRepository = optionRepository;
    }

    @Override
    public List<NpcActorEntity> getAllNpcs() {
        return npcRepository.findAll();
    }

    @Override
    public NpcActorEntity getNpc(String actorId) {
        return npcRepository.findById(actorId)
                .orElseThrow(() -> GameException.notFound("NPC_NOT_FOUND",
                        "NPC actor '" + actorId + "' does not exist"));
    }

    @Override
    public Map<String, Object> getDialogueForNpc(String npcActorId, int questState) {
        // Verify the NPC exists
        if (!npcRepository.existsById(npcActorId)) {
            throw GameException.notFound("NPC_NOT_FOUND",
                    "NPC actor '" + npcActorId + "' does not exist");
        }

        // Try to find a dialogue filtered to this specific quest state first
        DialogueTreeEntity tree = treeRepository
                .findByNpcActorIdAndQuestStateFilter(npcActorId, questState)
                .orElseGet(() -> {
                    // Fallback: find any dialogue for this NPC without a quest state filter
                    List<DialogueTreeEntity> npcDialogues = treeRepository.findByNpcActorId(npcActorId);
                    if (npcDialogues.isEmpty()) {
                        throw GameException.notFound("DIALOGUE_NOT_FOUND",
                                "No dialogue found for NPC '" + npcActorId + "' at quest state " + questState);
                    }
                    // Return the first dialogue (or one without a quest state filter)
                    return npcDialogues.stream()
                            .filter(d -> d.getQuestStateFilter() == null)
                            .findFirst()
                            .orElse(npcDialogues.get(0));
                });

        log.info("[Dialogue] Routed NPC '{}' at questState={} → dialogue '{}'",
                npcActorId, questState, tree.getDialogueId());

        return buildDialogueResponse(tree);
    }

    @Override
    public Map<String, Object> getDialogue(String dialogueId) {
        DialogueTreeEntity tree = treeRepository.findById(dialogueId)
                .orElseThrow(() -> GameException.notFound("DIALOGUE_NOT_FOUND",
                        "Dialogue '" + dialogueId + "' does not exist"));

        return buildDialogueResponse(tree);
    }

    // -- Helpers --

    /**
     * Builds the full dialogue response: tree metadata + lines + options.
     */
    private Map<String, Object> buildDialogueResponse(DialogueTreeEntity tree) {
        List<DialogueLineEntity> lines = lineRepository
                .findByDialogueIdOrderByLineIndexAsc(tree.getDialogueId());
        List<DialogueOptionEntity> options = optionRepository
                .findByDialogueIdOrderByOptionIndexAsc(tree.getDialogueId());

        // Build actor map for the lines so Unity can look up names/portraits
        List<Map<String, Object>> lineList = new ArrayList<>();
        for (DialogueLineEntity line : lines) {
            Map<String, Object> lineMap = new LinkedHashMap<>();
            lineMap.put("lineIndex", line.getLineIndex());
            lineMap.put("actorId", line.getActorId());
            lineMap.put("text", line.getLineText());

            // Optionally include actor display name
            npcRepository.findById(line.getActorId()).ifPresent(actor -> {
                lineMap.put("actorName", actor.getActorName());
                lineMap.put("portraitSpriteName", actor.getPortraitSpriteName());
            });

            lineList.add(lineMap);
        }

        List<Map<String, Object>> optionList = new ArrayList<>();
        for (DialogueOptionEntity opt : options) {
            Map<String, Object> optMap = new LinkedHashMap<>();
            optMap.put("optionIndex", opt.getOptionIndex());
            optMap.put("optionText", opt.getOptionText());
            optMap.put("nextDialogueId", opt.getNextDialogueId());
            optionList.add(optMap);
        }

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("dialogue", Map.of(
                "dialogueId", tree.getDialogueId(),
                "npcActorId", tree.getNpcActorId(),
                "questStateFilter", tree.getQuestStateFilter(),
                "description", tree.getDescription()
        ));
        response.put("lines", lineList);
        response.put("options", optionList);

        return response;
    }
}
