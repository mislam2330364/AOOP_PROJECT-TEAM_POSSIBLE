package com.wastelandsurvivors.backend.service.impl;

import com.wastelandsurvivors.backend.entity.PlayerProgressionEntity;
import com.wastelandsurvivors.backend.exception.GameException;
import com.wastelandsurvivors.backend.repository.PlayerProgressionRepository;
import com.wastelandsurvivors.backend.repository.PlayerRepository;
import com.wastelandsurvivors.backend.service.ExperienceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Full implementation of {@link ExperienceService}.
 *
 * <p>Level-up formula matches Unity's ExpManager.cs:
 * when experience >= expToLevel → level++, subtract threshold,
 * multiply threshold by expGrowthMultiplier (default 1.2).</p>
 */
@Service
@Slf4j
public class ExperienceServiceImpl implements ExperienceService {

    private final PlayerProgressionRepository progressionRepository;
    private final PlayerRepository playerRepository;

    public ExperienceServiceImpl(PlayerProgressionRepository progressionRepository,
                                  PlayerRepository playerRepository) {
        this.progressionRepository = progressionRepository;
        this.playerRepository = playerRepository;
    }

    @Override
    public PlayerProgressionEntity getProgression(Long playerId, String worldId) {
        if (!playerRepository.existsById(playerId)) {
            throw GameException.notFound("PLAYER_NOT_FOUND",
                    "Player " + playerId + " does not exist");
        }

        return progressionRepository.findByPlayerIdAndWorldId(playerId, worldId)
                .orElseGet(() -> {
                    PlayerProgressionEntity defaults = PlayerProgressionEntity.builder()
                            .playerId(playerId)
                            .worldId(worldId)
                            .build();
                    log.info("[Exp] Auto-created default progression for playerId={} worldId={}",
                            playerId, worldId);
                    return progressionRepository.save(defaults);
                });
    }

    @Override
    public PlayerProgressionEntity addExperience(Long playerId, String worldId, long expAmount) {
        if (!playerRepository.existsById(playerId)) {
            throw GameException.notFound("PLAYER_NOT_FOUND",
                    "Player " + playerId + " does not exist");
        }

        PlayerProgressionEntity prog = progressionRepository
                .findByPlayerIdAndWorldId(playerId, worldId)
                .orElseGet(() -> {
                    PlayerProgressionEntity defaults = PlayerProgressionEntity.builder()
                            .playerId(playerId)
                            .worldId(worldId)
                            .build();
                    return progressionRepository.save(defaults);
                });

        long oldExp = prog.getExperience();
        int oldLevel = prog.getLevel();

        prog.setExperience(prog.getExperience() + expAmount);

        // Level-up loop: keep leveling up while experience meets the threshold.
        // This handles edge cases where a single large EXP award triggers
        // multiple level-ups (e.g., boss kill with massive EXP).
        int levelsGained = 0;
        while (prog.getExperience() >= prog.getExpToLevel()) {
            prog.setExperience(prog.getExperience() - prog.getExpToLevel());
            prog.setLevel(prog.getLevel() + 1);
            // Grow the threshold for the next level
            prog.setExpToLevel((long) (prog.getExpToLevel() * prog.getExpGrowthMultiplier()));
            levelsGained++;
        }

        progressionRepository.save(prog);

        if (levelsGained > 0) {
            log.info("[Exp] Level up! playerId={} {}→{} ({} levels gained) EXP: {}→{}",
                    playerId, oldLevel, prog.getLevel(), levelsGained,
                    oldExp, prog.getExperience());
        } else {
            log.debug("[Exp] Added {} EXP to playerId={} (total: {})", expAmount, playerId, prog.getExperience());
        }

        return prog;
    }
}
