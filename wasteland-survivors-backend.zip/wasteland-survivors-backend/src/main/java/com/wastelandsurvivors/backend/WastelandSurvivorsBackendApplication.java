package com.wastelandsurvivors.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * Spring Boot entry point for the Wasteland Survivors backend.
 *
 * <p>Explicit {@code @ComponentScan} ensures all service implementations
 * are discovered even during DevTools restart cycles.</p>
 */
@SpringBootApplication
@ComponentScan(basePackages = "com.wastelandsurvivors.backend")
public class WastelandSurvivorsBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(WastelandSurvivorsBackendApplication.class, args);
    }
}

