package com.wastelandsurvivors.backend.config;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wastelandsurvivors.backend.websocket.SessionSubscriptionInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.ChannelRegistration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

/**
 * Configures the STOMP-over-WebSocket message broker for live multiplayer sync.
 * WebSocket creates a persistent two-way channel between Unity and the server.
 * Unlike REST which is request-response, WebSocket allows the server to push
 * messages to Unity at any time without Unity asking first.
 *
 * Message routing:
 *   Unity SENDS to /app/game       -> @MessageMapping in GameSocketHandler receives it
 *   Server PUSHES to /topic/session/{id} -> subscribed Unity clients receive it
 *   Each Unity client subscribes to /topic/session/{sessionId} on connect
 */
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    private final SessionSubscriptionInterceptor sessionInterceptor;

    public WebSocketConfig(SessionSubscriptionInterceptor sessionInterceptor) {
        this.sessionInterceptor = sessionInterceptor;
    }

    /**
     * PHASE 7: Registers the SessionSubscriptionInterceptor on the inbound
     * client channel so STOMP SUBSCRIBE frames can be intercepted to map
     * STOMP session IDs → game session IDs.
     */
    @Override
    public void configureClientInboundChannel(ChannelRegistration registration) {
        registration.interceptors(sessionInterceptor);
    }

    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        // In-memory broker at /topic prefix. For production with multiple server
        // instances, replace with a Redis or RabbitMQ broker using enableStompBrokerRelay().
        config.enableSimpleBroker("/topic");
        // Messages sent to /app/... are routed to @MessageMapping methods.
        // /app is stripped before matching — /app/game routes to @MessageMapping("/game").
        config.setApplicationDestinationPrefixes("/app");
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        // Raw WebSocket endpoint for native clients (Unity).
        // Unity uses System.Net.WebSockets.ClientWebSocket — a raw WebSocket
        // client, NOT a SockJS client.  SockJS requires an HTTP handshake that
        // raw WebSocket clients don't perform, causing "Unable to connect to
        // the remote server".
        //
        // This endpoint MUST be registered BEFORE the SockJS one so Spring
        // routes raw WebSocket connections correctly.
        registry.addEndpoint(AppConstants.WS_ENDPOINT).setAllowedOrigins("*");

        // SockJS endpoint for browser-based clients (fallback).
        // Uses a different path to avoid conflicting with the raw endpoint.
        registry.addEndpoint("/ws/sockjs").setAllowedOrigins("*").withSockJS();
    }

    /**
     * Explicit ObjectMapper bean for GameSocketHandler payload deserialization.
     * MUST ignore unknown properties because the Unity C# DTOs may carry fields
     * (e.g., PositionDTO.sceneName) that are not present in the corresponding
     * Java DTO.  A plain {@code new ObjectMapper()} fails on unknown properties
     * by default, which silently drops ALL messages of that type.
     */
    @Bean
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return mapper;
    }
}

