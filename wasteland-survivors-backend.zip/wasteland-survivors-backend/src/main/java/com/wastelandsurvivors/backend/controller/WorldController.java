package com.wastelandsurvivors.backend.controller;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.service.WorldService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * REST Controller for world management.
 * All endpoints are now fully implemented — world create/load/save.
 */
@RestController
@RequestMapping(AppConstants.API_V1 + "/worlds")
@Slf4j
public class WorldController {

    private final WorldService worldService;

    public WorldController(WorldService worldService) {
        this.worldService = worldService;
    }

    /**
     * Creates a new RPG world for the given player.
     * HTTP 201 CREATED — returns the new world ID as a plain string.
     */
    @PostMapping("/create")
    public ResponseEntity<?> createWorld(@RequestParam Long ownerId,
                                         @RequestParam String worldName) {
        log.info("[WorldController] POST /create — ownerId={} worldName='{}'", ownerId, worldName);
        String worldId = worldService.createWorld(ownerId, worldName);
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of("worldId", worldId));
    }

    /**
     * Loads the saved state of a world for a specific player.
     */
    @GetMapping("/{worldId}")
    public ResponseEntity<?> getWorld(@PathVariable String worldId,
                                      @RequestParam Long playerId) {
        log.info("[WorldController] GET /{} — playerId={}", worldId, playerId);
        return ResponseEntity.ok(worldService.getWorld(worldId, playerId));
    }

    /**
     * Saves the current world state for a player.
     */
    @PostMapping("/{worldId}/save")
    public ResponseEntity<?> saveWorld(@PathVariable String worldId,
                                       @RequestParam Long playerId,
                                       @RequestBody Map<String, Object> worldData) {
        log.info("[WorldController] POST /{}/save — playerId={}", worldId, playerId);
        worldService.saveWorld(worldId, playerId, worldData);
        return ResponseEntity.ok(Map.of("message", "World saved successfully"));
    }
}
