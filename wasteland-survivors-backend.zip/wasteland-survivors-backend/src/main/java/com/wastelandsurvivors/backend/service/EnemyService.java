package com.wastelandsurvivors.backend.service;

import com.wastelandsurvivors.backend.entity.EnemyInstanceEntity;
import com.wastelandsurvivors.backend.entity.EnemyTypeEntity;

import java.util.List;

/**
 * Declares enemy catalog and instance management.
 * Enemy types are template definitions; enemy instances are runtime spawns in a world.
 */
public interface EnemyService {

    // -- Type catalog --

    /**
     * Returns all enemy type definitions from the catalog.
     */
    List<EnemyTypeEntity> getAllEnemyTypes();

    /**
     * Returns a single enemy type by its ID.
     *
     * @param typeId e.g. "ZOMBIE_VARIANT_01"
     * @throws com.wastelandsurvivors.backend.exception.GameException if not found
     */
    EnemyTypeEntity getEnemyType(String typeId);

    // -- Instance management --

    /**
     * Returns all enemy instances currently alive in a world.
     */
    List<EnemyInstanceEntity> getAliveEnemies(String worldId);

    /**
     * Returns all enemy instances (alive or dead) in a world.
     */
    List<EnemyInstanceEntity> getAllEnemies(String worldId);

    /**
     * Spawns a new enemy instance in a world.
     *
     * @param worldId  The world to spawn in
     * @param typeId   The enemy type (must exist in enemy_types)
     * @param x        Spawn X coordinate
     * @param y        Spawn Y coordinate
     * @return The created EnemyInstanceEntity with server-assigned enemyId
     */
    EnemyInstanceEntity spawnEnemy(String worldId, String typeId, float x, float y);

    /**
     * Applies damage to an enemy instance.
     * If health drops to 0 or below, marks the enemy as dead.
     *
     * @param enemyId The enemy to damage
     * @param damage  Amount of damage to apply
     * @return The updated EnemyInstanceEntity
     * @throws com.wastelandsurvivors.backend.exception.GameException if enemy not found
     */
    EnemyInstanceEntity damageEnemy(Long enemyId, int damage);
}
