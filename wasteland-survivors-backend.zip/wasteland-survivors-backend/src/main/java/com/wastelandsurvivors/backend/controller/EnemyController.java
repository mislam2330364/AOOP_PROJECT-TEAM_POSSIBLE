package com.wastelandsurvivors.backend.controller;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.entity.EnemyInstanceEntity;
import com.wastelandsurvivors.backend.service.EnemyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * REST Controller for enemy type catalog and per-world enemy instances.
 */
@RestController
@RequestMapping(AppConstants.API_V1 + "/enemies")
@Slf4j
public class EnemyController {

    private final EnemyService enemyService;

    public EnemyController(EnemyService enemyService) {
        this.enemyService = enemyService;
    }

    // -- Type catalog --

    /**
     * Returns all enemy type definitions.
     * GET /api/v1/enemies/types
     */
    @GetMapping("/types")
    public ResponseEntity<?> getAllEnemyTypes() {
        log.debug("[EnemyController] GET /types");
        return ResponseEntity.ok(enemyService.getAllEnemyTypes());
    }

    /**
     * Returns a single enemy type by ID.
     * GET /api/v1/enemies/types/{typeId}
     */
    @GetMapping("/types/{typeId}")
    public ResponseEntity<?> getEnemyType(@PathVariable String typeId) {
        log.debug("[EnemyController] GET /types/{}", typeId);
        return ResponseEntity.ok(enemyService.getEnemyType(typeId));
    }

    // -- Instance management --

    /**
     * Returns all enemy instances (alive + dead) in a world.
     * GET /api/v1/enemies/instances?worldId=...
     */
    @GetMapping("/instances")
    public ResponseEntity<?> getAllEnemies(@RequestParam String worldId) {
        log.debug("[EnemyController] GET /instances?worldId={}", worldId);
        return ResponseEntity.ok(enemyService.getAllEnemies(worldId));
    }

    /**
     * Returns all alive enemy instances in a world.
     * GET /api/v1/enemies/instances/alive?worldId=...
     */
    @GetMapping("/instances/alive")
    public ResponseEntity<?> getAliveEnemies(@RequestParam String worldId) {
        log.debug("[EnemyController] GET /instances/alive?worldId={}", worldId);
        return ResponseEntity.ok(enemyService.getAliveEnemies(worldId));
    }

    /**
     * Spawns a new enemy instance in a world.
     * POST /api/v1/enemies/instances/spawn?worldId=...&typeId=...&x=...&y=...
     */
    @PostMapping("/instances/spawn")
    public ResponseEntity<?> spawnEnemy(@RequestParam String worldId,
                                        @RequestParam String typeId,
                                        @RequestParam float x,
                                        @RequestParam float y) {
        log.info("[EnemyController] POST /instances/spawn — worldId={} typeId={} pos=({},{})",
                worldId, typeId, x, y);
        EnemyInstanceEntity spawned = enemyService.spawnEnemy(worldId, typeId, x, y);
        return ResponseEntity.ok(spawned);
    }

    /**
     * Applies damage to an enemy instance.
     * POST /api/v1/enemies/instances/{enemyId}/damage?amount=...
     */
    @PostMapping("/instances/{enemyId}/damage")
    public ResponseEntity<?> damageEnemy(@PathVariable Long enemyId,
                                         @RequestParam int amount) {
        log.info("[EnemyController] POST /instances/{}/damage?amount={}", enemyId, amount);
        return ResponseEntity.ok(enemyService.damageEnemy(enemyId, amount));
    }
}
