package com.wastelandsurvivors.backend.repository;

import com.wastelandsurvivors.backend.entity.QuestEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Spring Data JPA repository for {@link QuestEntity} (quests table).
 * Supports multiple quests per world via (world_id, quest_id) unique constraint.
 */
public interface QuestRepository extends JpaRepository<QuestEntity, Long> {

    /**
     * Finds the default quest (sara_village) for a world.
     * Backward-compatible with single-quest callers.
     */
    Optional<QuestEntity> findByWorldId(String worldId);

    /**
     * Finds a specific quest by world and quest discriminator.
     * Primary lookup for multi-quest system.
     */
    Optional<QuestEntity> findByWorldIdAndQuestId(String worldId, String questId);
}
