package com.wastelandsurvivors.backend.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Sent by Unity to /api/v1/lobby/join/{key} when the guest player enters the join key shared by the owner.
 * (Unity to server)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class JoinLobbyRequest {

    // The 6-character code the owner shared out-of-game with the guest — set from the URL path variable in the controller
    private String joinKey;

    // The database ID of the guest player who is joining
    @NotNull(message = "Guest ID is required")
    private Long guestId;
}

