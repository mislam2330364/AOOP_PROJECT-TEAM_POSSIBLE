package com.wastelandsurvivors.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * NPC actor catalog entry — persisted in {@code npc_actors}.
 * Defines "who speaks" in dialogues. Runtime dialogue routing uses
 * the actor_id to find the correct conversation for a given quest state.
 *
 * <h3>Unity source mapping</h3>
 * <ul>
 *   <li>{@code actorId} → ActorSO.actorName</li>
 *   <li>{@code actorName} → ActorSO.actorName, DialogueManager.actionName.text</li>
 *   <li>{@code portraitSpriteName} → ActorSO.portrait, DialogueManager.portrait.sprite</li>
 * </ul>
 */
@Entity
@Table(name = "npc_actors")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NpcActorEntity {

    /**
     * Unique actor identifier, e.g. "SARA", "JOEL".
     * Maps to: ActorSO.actorName
     */
    @Id
    @Column(name = "actor_id", nullable = false, length = 64)
    private String actorId;

    /**
     * Display name shown in the dialogue UI.
     * Maps to: DialogueManager.actionName.text
     */
    @Column(name = "actor_name", nullable = false, length = 100)
    private String actorName;

    /**
     * Identifier for the portrait sprite asset in Unity.
     * Maps to: ActorSO.portrait, DialogueManager.portrait.sprite
     */
    @Column(name = "portrait_sprite_name", length = 100)
    private String portraitSpriteName;
}
