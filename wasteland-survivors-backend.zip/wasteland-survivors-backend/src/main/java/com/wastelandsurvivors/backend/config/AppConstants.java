package com.wastelandsurvivors.backend.config;

/**
 * Central store for all constant string values shared across the entire application.
 *
 * RULE FOR ALL DEVELOPERS:
 * Never write a raw string for a message type, session status, or API path anywhere
 * in the codebase. Always reference a constant from this class.
 * Example — WRONG:  if (message.getType().equals('POSITION'))
 * Example — RIGHT:  if (message.getType().equals(AppConstants.MSG_POSITION))
 *
 * Reason: If a value ever needs to change, you edit it here once.
 * Every file that references the constant is automatically updated.
 * Files that use raw strings would each need to be found and edited individually.
 *
 * MIRROR FILE: This file has an exact C# mirror called NetworkConstants.cs in Unity.
 * If you change a value here, change the matching value in NetworkConstants.cs.
 * If they differ, messages between Unity and the server will be silently misrouted.
 */
@SuppressWarnings("unused")
public final class AppConstants {

    /*
     * SECTION 1 — WebSocket Message Types
     */

    // The type field of a position update message — sent every 100ms during multiplayer
    public static final String MSG_POSITION = "POSITION";

    // The type field of a combat action message — sent when the player attacks
    public static final String MSG_ACTION = "ACTION";

    // The type field of a health update message — sent when the player's health changes
    public static final String MSG_HEALTH = "HEALTH";

    // The type field of an inventory message — defined now, used when inventory is built in Unity
    public static final String MSG_INVENTORY = "INVENTORY";

    // Sent by Unity every 30 seconds to verify the connection is still alive
    public static final String MSG_PING = "PING";

    // Server reply to a PING — confirms the connection is alive. If Unity does not
    // receive a PONG within 5 seconds of sending a PING, it should attempt reconnection.
    public static final String MSG_PONG = "PONG";

    // Sent by the server to both players when the session becomes ACTIVE.
    // Unity reacts to this by loading the multiplayer world scene.
    public static final String MSG_SESSION_READY = "SESSION_READY";

    // Sent by the server to the remaining player when the opponent's connection drops.
    // Unity reacts to this by showing a disconnection message and returning to the lobby.
    public static final String MSG_PLAYER_DISCONNECTED = "PLAYER_DISCONNECTED";

    // The type field of an enemy position update message — sent by the host client
    public static final String MSG_ENEMY_POSITION = "ENEMY_POSITION";

    // The type field of an enemy combat action message — sent when an enemy attacks
    public static final String MSG_ENEMY_ACTION = "ENEMY_ACTION";

    // The type field of an enemy health update message — sent when an enemy takes damage
    public static final String MSG_ENEMY_HEALTH = "ENEMY_HEALTH";

    // Sent when an enemy is spawned in the session (host authoritative)
    public static final String MSG_ENEMY_SPAWN = "ENEMY_SPAWN";

    // Sent when an enemy is removed from the session (host authoritative)
    public static final String MSG_ENEMY_DESPAWN = "ENEMY_DESPAWN";

    // Sent when the host applies knockback to an enemy (melee hit).
    // Guest clients apply the knockback force/duration to their local enemy instance.
    public static final String MSG_ENEMY_KNOCKBACK = "ENEMY_KNOCKBACK";

    // Sent when a player's ammo state changes (fire, reload, pickup).
    // Keeps the opponent's ammo UI in sync during multiplayer.
    public static final String MSG_AMMO_UPDATE = "AMMO_UPDATE";

    // Sent by the host when they change scenes (walk through a door).
    // The guest receives this and loads the same scene so both players stay together.
    public static final String MSG_SCENE_CHANGE = "SCENE_CHANGE";

    // Sent when the boss transitions to Phase 2 (enraged mode).
    // Payload includes restored health, new damage, and speed multiplier.
    // Guest clients use this to trigger the phase 2 scream (Boss_Scream.mp3) and stat changes.
    public static final String MSG_BOSS_PHASE = "BOSS_PHASE";

    // Sent by a multiplayer GUEST when they attack an enemy.  The guest does NOT
    // apply damage locally — the host receives this, applies damage to the
    // authoritative enemy, and the resulting health change syncs back to the guest.
    public static final String MSG_ENEMY_DAMAGE = "ENEMY_DAMAGE";

    /*
     * SECTION 2 — Session Status Values
     */

    // Session has been created by the owner but the guest has not joined yet.
    // Both players see the lobby waiting screen while status is WAITING.
    public static final String STATUS_WAITING = "WAITING";

    // Both players have confirmed. The multiplayer world is loading or running.
    // Unity stops polling and loads the game world when it receives this status.
    public static final String STATUS_ACTIVE = "ACTIVE";

    // Session has ended — either both players finished or one disconnected.
    // World state should be saved before the session reaches CLOSED.
    public static final String STATUS_CLOSED = "CLOSED";

    /*
     * SECTION 3 — API Version Prefix
     */

    // Prefix applied to all REST endpoint paths.
    // If the API ever needs a breaking change, create /api/v2 for new endpoints.
    // Existing Unity clients using /api/v1 continue working without modification.
    public static final String API_V1 = "/api/v1";

    /*
     * SECTION 4 — WebSocket Route Prefixes
     */

    // The URL path Unity connects to for the WebSocket handshake.
    // Full connection URL: ws://localhost:8080/ws/game
    public static final String WS_ENDPOINT = "/ws/game";

    // Prefix for the session broadcast channel.
    // Append a sessionId to get the full topic: /topic/session/STUB_SESSION_001
    // Both players subscribe to this topic. The server broadcasts opponent updates here.
    public static final String WS_TOPIC_SESSION = "/topic/session/";

    // The path Unity sends messages TO on the server.
    // Full send destination: /app/game
    // Spring routes anything prefixed with /app to a @MessageMapping handler method.
    public static final String WS_APP_DESTINATION = "/app/game";

    // Private constructor — this class cannot be instantiated.
    // All values are static constants. Access them as: AppConstants.CONSTANT_NAME
    private AppConstants() {
    }
}

