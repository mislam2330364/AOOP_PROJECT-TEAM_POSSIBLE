package com.wastelandsurvivors.backend.service;

import com.wastelandsurvivors.backend.entity.NpcActorEntity;

import java.util.List;
import java.util.Map;

/**
 * Declares dialogue and NPC management capabilities.
 * Handles NPC actor catalog, dialogue tree retrieval, and
 * quest-state-driven dialogue routing (matching NPC_Talk.cs logic).
 */
public interface DialogueService {

    /**
     * Returns all NPC actors in the catalog.
     */
    List<NpcActorEntity> getAllNpcs();

    /**
     * Returns a single NPC actor by ID.
     *
     * @param actorId e.g. "SARA"
     * @throws com.wastelandsurvivors.backend.exception.GameException if not found
     */
    NpcActorEntity getNpc(String actorId);

    /**
     * Returns the correct dialogue tree for an NPC at a given quest state.
     * This replicates Unity's NPC_Talk.cs routing logic:
     *   questState 0 → intro dialogue
     *   questState 1 → waiting dialogue
     *   questState 2 → completion dialogue
     *
     * @param npcActorId The NPC, e.g. "SARA"
     * @param questState Current quest state (0-3)
     * @return Map containing the dialogue tree with its lines and options,
     *         or the default dialogue for that NPC if no quest-state-specific one exists
     */
    Map<String, Object> getDialogueForNpc(String npcActorId, int questState);

    /**
     * Returns a complete dialogue tree by its ID, including all lines and options.
     *
     * @param dialogueId e.g. "SARA_INTRO"
     * @return Map with "dialogue" (tree metadata), "lines" (ordered list),
     *         and "options" (ordered list of choices)
     * @throws com.wastelandsurvivors.backend.exception.GameException if not found
     */
    Map<String, Object> getDialogue(String dialogueId);
}
