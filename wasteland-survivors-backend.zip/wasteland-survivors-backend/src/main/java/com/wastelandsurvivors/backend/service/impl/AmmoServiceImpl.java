package com.wastelandsurvivors.backend.service.impl;

import com.wastelandsurvivors.backend.entity.PlayerAmmoEntity;
import com.wastelandsurvivors.backend.exception.GameException;
import com.wastelandsurvivors.backend.repository.PlayerAmmoRepository;
import com.wastelandsurvivors.backend.repository.PlayerRepository;
import com.wastelandsurvivors.backend.service.AmmoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Full implementation of {@link AmmoService}.
 *
 * <p>Reload logic mirrors Player_Combat.ReloadRoutine():
 * bulletsNeeded = maxClipSize - currentClip,
 * bulletsToLoad = min(bulletsNeeded, totalAmmoReserve).</p>
 */
@Service
@Slf4j
public class AmmoServiceImpl implements AmmoService {

    private final PlayerAmmoRepository ammoRepository;
    private final PlayerRepository playerRepository;

    public AmmoServiceImpl(PlayerAmmoRepository ammoRepository,
                            PlayerRepository playerRepository) {
        this.ammoRepository = ammoRepository;
        this.playerRepository = playerRepository;
    }

    @Override
    public PlayerAmmoEntity getAmmo(Long playerId, String worldId) {
        if (!playerRepository.existsById(playerId)) {
            throw GameException.notFound("PLAYER_NOT_FOUND",
                    "Player " + playerId + " does not exist");
        }
        return ammoRepository.findByPlayerIdAndWorldId(playerId, worldId)
                .orElseGet(() -> {
                    PlayerAmmoEntity defaults = PlayerAmmoEntity.builder()
                            .playerId(playerId)
                            .worldId(worldId)
                            .build();
                    log.info("[Ammo] Auto-created default ammo for playerId={} worldId={}", playerId, worldId);
                    return ammoRepository.save(defaults);
                });
    }

    @Override
    public PlayerAmmoEntity consumeBullet(Long playerId, String worldId) {
        PlayerAmmoEntity ammo = getOrCreate(playerId, worldId);

        if (ammo.getCurrentClip() <= 0) {
            throw GameException.badRequest("CLIP_EMPTY",
                    "No bullets in clip — reload required");
        }

        ammo.setCurrentClip(ammo.getCurrentClip() - 1);
        ammoRepository.save(ammo);

        log.debug("[Ammo] Bullet consumed: playerId={} clip={}/{} reserve={}",
                playerId, ammo.getCurrentClip(), ammo.getMaxClipSize(), ammo.getTotalAmmoReserve());
        return ammo;
    }

    @Override
    public PlayerAmmoEntity reload(Long playerId, String worldId) {
        PlayerAmmoEntity ammo = getOrCreate(playerId, worldId);

        if (ammo.getCurrentClip() >= ammo.getMaxClipSize()) {
            throw GameException.badRequest("CLIP_FULL",
                    "Clip is already full — no reload needed");
        }
        if (ammo.getTotalAmmoReserve() <= 0) {
            throw GameException.badRequest("NO_AMMO",
                    "No ammo in reserve to reload from");
        }

        int bulletsNeeded = ammo.getMaxClipSize() - ammo.getCurrentClip();
        int bulletsToLoad = Math.min(bulletsNeeded, ammo.getTotalAmmoReserve());

        ammo.setCurrentClip(ammo.getCurrentClip() + bulletsToLoad);
        ammo.setTotalAmmoReserve(ammo.getTotalAmmoReserve() - bulletsToLoad);
        ammoRepository.save(ammo);

        log.info("[Ammo] Reloaded: playerId={} clip={}/{} reserve={} (loaded {} bullets)",
                playerId, ammo.getCurrentClip(), ammo.getMaxClipSize(),
                ammo.getTotalAmmoReserve(), bulletsToLoad);
        return ammo;
    }

    @Override
    public PlayerAmmoEntity addAmmo(Long playerId, String worldId, int amount) {
        PlayerAmmoEntity ammo = getOrCreate(playerId, worldId);
        ammo.setTotalAmmoReserve(ammo.getTotalAmmoReserve() + amount);
        ammoRepository.save(ammo);

        log.info("[Ammo] Added {} ammo: playerId={} totalReserve={}",
                amount, playerId, ammo.getTotalAmmoReserve());
        return ammo;
    }

    private PlayerAmmoEntity getOrCreate(Long playerId, String worldId) {
        if (!playerRepository.existsById(playerId)) {
            throw GameException.notFound("PLAYER_NOT_FOUND",
                    "Player " + playerId + " does not exist");
        }
        return ammoRepository.findByPlayerIdAndWorldId(playerId, worldId)
                .orElseGet(() -> ammoRepository.save(PlayerAmmoEntity.builder()
                        .playerId(playerId)
                        .worldId(worldId)
                        .build()));
    }
}
