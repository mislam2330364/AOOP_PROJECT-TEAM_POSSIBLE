package com.wastelandsurvivors.backend.service.impl;

import com.wastelandsurvivors.backend.dto.game.InventoryDTO;
import com.wastelandsurvivors.backend.dto.game.InventoryItemDTO;
import com.wastelandsurvivors.backend.entity.InventoryEntity;
import com.wastelandsurvivors.backend.entity.InventoryItemEntity;
import com.wastelandsurvivors.backend.exception.GameException;
import com.wastelandsurvivors.backend.repository.InventoryRepository;
import com.wastelandsurvivors.backend.repository.PlayerRepository;
import com.wastelandsurvivors.backend.service.InventoryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * Inventory persistence service backed by JPA.
 * All mutating operations are @Transactional to prevent partial updates
 * from concurrent requests (e.g., drop + save happening simultaneously).
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class InventoryServiceImpl implements InventoryService {

    private final InventoryRepository inventoryRepository;
    private final PlayerRepository playerRepository;

    @Override
    public InventoryDTO getInventory(Long playerId, String worldId) {
        if (!playerRepository.existsById(playerId)) {
            throw GameException.notFound("PLAYER_NOT_FOUND", "Player does not exist");
        }

        InventoryEntity inventory = inventoryRepository.findByPlayerIdAndWorldId(playerId, worldId)
                .orElseGet(() -> InventoryEntity.builder()
                        .playerId(playerId)
                        .worldId(worldId)
                        .items(new ArrayList<>())
                        .build());

        return toDto(inventory);
    }

    @Override
    public InventoryDTO saveInventory(Long playerId, InventoryDTO inventory) {
        if (!playerRepository.existsById(playerId)) {
            throw GameException.notFound("PLAYER_NOT_FOUND", "Player does not exist");
        }

        String worldId = inventory.getWorldId();
        InventoryEntity entity = inventoryRepository.findByPlayerIdAndWorldId(playerId, worldId)
                .orElseGet(() -> InventoryEntity.builder()
                        .playerId(playerId)
                        .worldId(worldId)
                        .items(new ArrayList<>())
                        .build());

        entity.getItems().clear();
        List<InventoryItemEntity> itemEntities = new ArrayList<>();
        if (inventory.getItems() != null) {
            for (InventoryItemDTO dto : inventory.getItems()) {
                InventoryItemEntity item = InventoryItemEntity.builder()
                        .inventory(entity)
                        .itemId(dto.getItemId())
                        .itemName(dto.getItemName())
                        .quantity(dto.getQuantity())
                        .itemDescription(dto.getItemDescription())
                        .spriteName(dto.getSpriteName())
                        .build();
                itemEntities.add(item);
            }
        }
        entity.getItems().addAll(itemEntities);

        InventoryEntity saved = inventoryRepository.save(entity);
        return toDto(saved);
    }

    @Override
    public InventoryDTO removeItem(Long playerId, String worldId, String itemName, int quantity) {
        if (!playerRepository.existsById(playerId)) {
            throw GameException.notFound("PLAYER_NOT_FOUND", "Player does not exist");
        }

        InventoryEntity inventory = inventoryRepository.findByPlayerIdAndWorldId(playerId, worldId)
                .orElseThrow(() -> GameException.notFound("INVENTORY_NOT_FOUND",
                        "No inventory found for player " + playerId + " in world " + worldId));

        if (inventory.getItems() == null || inventory.getItems().isEmpty()) {
            throw GameException.badRequest("INVENTORY_EMPTY",
                    "Inventory is empty — nothing to drop");
        }

        // Find the item by name (case-insensitive, trim whitespace)
        InventoryItemEntity targetItem = inventory.getItems().stream()
                .filter(i -> i.getItemName() != null
                        && i.getItemName().replace("(Clone)", "").trim()
                        .equalsIgnoreCase(itemName.replace("(Clone)", "").trim()))
                .findFirst()
                .orElseThrow(() -> GameException.notFound("ITEM_NOT_FOUND",
                        "Item '" + itemName + "' not found in inventory"));

        int newQuantity = targetItem.getQuantity() - quantity;
        if (newQuantity <= 0) {
            // Fully remove the item from inventory
            inventory.getItems().remove(targetItem);
            log.info("[Inventory] Item fully removed: playerId={} item={} (quantity reached 0)",
                    playerId, itemName);
        } else {
            targetItem.setQuantity(newQuantity);
            log.info("[Inventory] Item quantity reduced: playerId={} item={} quantity={}→{}",
                    playerId, itemName, targetItem.getQuantity() + quantity, newQuantity);
        }

        InventoryEntity saved = inventoryRepository.save(inventory);
        return toDto(saved);
    }

    private InventoryDTO toDto(InventoryEntity entity) {
        List<InventoryItemDTO> items = new ArrayList<>();
        if (entity.getItems() != null) {
            for (InventoryItemEntity item : entity.getItems()) {
                items.add(InventoryItemDTO.builder()
                        .itemId(item.getItemId())
                        .itemName(item.getItemName())
                        .itemDescription(item.getItemDescription())
                        .spriteName(item.getSpriteName())
                        .quantity(item.getQuantity())
                        .build());
            }
        }

        return InventoryDTO.builder()
                .playerId(entity.getPlayerId())
                .worldId(entity.getWorldId())
                .items(items)
                .build();
    }
}



