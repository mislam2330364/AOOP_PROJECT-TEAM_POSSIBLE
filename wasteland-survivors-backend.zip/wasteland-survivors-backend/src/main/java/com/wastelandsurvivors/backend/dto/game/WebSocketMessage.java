package com.wastelandsurvivors.backend.dto.game;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The universal envelope for ALL WebSocket messages in the game.
 * Every message sent or received over the WebSocket connection uses this exact wrapper — whether it carries
 * position, combat, health, or any future data. (Both directions)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WebSocketMessage {

    // What kind of data is in the payload. MUST be one of the constants in AppConstants (MSG_POSITION, MSG_ACTION, etc.).
    private String type;

    // The session this message belongs to — used to route the message to the correct players
    private String sessionId;

    // The playerId of who sent this message. The receiving client ignores messages where senderId matches their own playerId.
    private long senderId;

    // The actual game data. When sending: use JsonUtility.ToJson(dto) in Unity.
    // When receiving: use ObjectMapper to deserialize to the correct DTO class based on type.
    private Object payload;

    // Unix milliseconds when the message was created. Used for ordering and debugging.
    private long timestamp;

    // PHASE 7: Monotonically increasing sequence number per sender.
    // Host increments on each outbound message. Guest rejects stale messages
    // (sequenceNumber < lastProcessedSequence). Prevents reordered/stale state.
    private long sequenceNumber;
}

