package com.wastelandsurvivors.backend.dto.game;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Carries an enemy's current and maximum health values.
 * Sent over WebSocket by the host client, wrapped inside a WebSocketMessage. (Both directions)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EnemyHealthDTO {

    // Server-assigned enemy ID — unique within the session (0 for scene enemies)
    private long enemyId;

    // Runtime-unique identifier for SCENE enemies (pre-placed in the Unity scene).
    // Matches ScenePersistentObject.runtimeUniqueID so the guest can find the
    // correct enemy to apply health changes to. Null/empty for server-spawned enemies.
    private String enemyRuntimeId;

    // Which multiplayer session this health update belongs to
    private String sessionId;

    // The enemy's current HP
    private int currentHealth;

    // The enemy's maximum HP
    private int maxHealth;

    // Current X position (for movement sync via ENEMY_HEALTH stream)
    private float x;

    // Current Y position (for movement sync via ENEMY_HEALTH stream)
    private float y;

    // Unix time in milliseconds when this was captured in Unity
    private long timestamp;
}

