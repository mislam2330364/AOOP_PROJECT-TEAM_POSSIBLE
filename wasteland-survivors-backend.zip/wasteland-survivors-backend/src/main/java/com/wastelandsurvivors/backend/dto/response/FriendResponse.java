package com.wastelandsurvivors.backend.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Returned by GET /api/v1/friends/list — represents one friend in the player's list.
 * (Server to Unity)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FriendResponse {

    private Long friendId;
    private String username;
    private LocalDateTime lastLoginAt;
}
