package com.wastelandsurvivors.backend.controller;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.dto.request.CreateLobbyRequest;
import com.wastelandsurvivors.backend.dto.request.JoinLobbyRequest;
import com.wastelandsurvivors.backend.service.LobbyService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST Controller for multiplayer lobby management.
 * All endpoints are now fully implemented — lobby lifecycle is:
 * WAITING → (guest joins) → ACTIVE (owner starts) → CLOSED.
 */
@RestController
@RequestMapping(AppConstants.API_V1 + "/lobby")
@Slf4j
public class LobbyController {

    private final LobbyService lobbyService;

    public LobbyController(LobbyService lobbyService) {
        this.lobbyService = lobbyService;
    }

    /**
     * Creates a multiplayer session and returns a join key for the owner to share.
     * HTTP 201 CREATED on success.
     */
    @PostMapping("/create")
    public ResponseEntity<?> createSession(@RequestBody @Valid CreateLobbyRequest request) {
        log.info("[LobbyController] POST /create — ownerId={} worldId={}",
                request.getOwnerId(), request.getWorldId());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(lobbyService.createSession(request));
    }

    /**
     * Registers the guest player into a session using the shared join key.
     * HTTP 200 OK on success.
     */
    @PostMapping("/join/{key}")
    public ResponseEntity<?> joinSession(@PathVariable String key,
                                         @RequestBody @Valid JoinLobbyRequest request) {
        log.info("[LobbyController] POST /join/{} — guestId={}", key, request.getGuestId());
        request.setJoinKey(key);
        return ResponseEntity.ok(lobbyService.joinSession(request));
    }

    /**
     * Returns the current status of a session. Unity polls this every 2 seconds.
     */
    @GetMapping("/status/{sessionId}")
    public ResponseEntity<?> getSessionStatus(@PathVariable String sessionId) {
        log.debug("[LobbyController] GET /status/{}", sessionId);
        return ResponseEntity.ok(lobbyService.getSessionStatus(sessionId));
    }

    /**
     * Transitions a session to ACTIVE. Only the owner may call this.
     */
    @PostMapping("/start/{sessionId}")
    public ResponseEntity<?> startSession(@PathVariable String sessionId,
                                          @RequestParam Long ownerId) {
        log.info("[LobbyController] POST /start/{} — ownerId={}", sessionId, ownerId);
        return ResponseEntity.ok(lobbyService.startSession(sessionId, ownerId));
    }
}
