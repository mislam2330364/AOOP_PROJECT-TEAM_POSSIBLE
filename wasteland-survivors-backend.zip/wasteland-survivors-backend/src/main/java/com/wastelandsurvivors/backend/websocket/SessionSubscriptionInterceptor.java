package com.wastelandsurvivors.backend.websocket;

import com.wastelandsurvivors.backend.config.AppConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.support.ChannelInterceptor;
import org.springframework.messaging.support.MessageHeaderAccessor;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * PHASE 7: Captures the mapping between STOMP session IDs and game session IDs
 * during the SUBSCRIBE frame. The Unity client subscribes to
 * /topic/session/{gameSessionId} — we extract that gameSessionId so that
 * WebSocketSessionLifecycleListener can use it during disconnect.
 *
 * <p>This interceptor is registered in WebSocketConfig.configureClientInboundChannel().</p>
 */
@Component
@Slf4j
public class SessionSubscriptionInterceptor implements ChannelInterceptor {

    /**
     * Maps Spring STOMP simpSessionId → game sessionId extracted from the
     * subscription destination (e.g., /topic/session/abc123 → abc123).
     */
    private final Map<String, String> stompToGameSession = new ConcurrentHashMap<>();

    /**
     * Maps game sessionId → player ID that was connected.
     * Populated from the WebSocketMessage senderId on first message.
     */
    private final Map<String, Long> gameSessionToPlayerId = new ConcurrentHashMap<>();

    @Override
    public Message<?> preSend(Message<?> message, MessageChannel channel) {
        StompHeaderAccessor accessor = MessageHeaderAccessor.getAccessor(message, StompHeaderAccessor.class);
        if (accessor == null) return message;

        if (StompCommand.SUBSCRIBE.equals(accessor.getCommand())) {
            String destination = accessor.getDestination();
            if (destination != null && destination.startsWith(AppConstants.WS_TOPIC_SESSION)) {
                String gameSessionId = destination.substring(AppConstants.WS_TOPIC_SESSION.length());
                String stompSessionId = accessor.getSessionId();
                if (stompSessionId != null && !gameSessionId.isEmpty()) {
                    stompToGameSession.put(stompSessionId, gameSessionId);
                    log.info("[SessionInterceptor] Mapped STOMP session {} → game session {}",
                            stompSessionId, gameSessionId);
                }
            }
        }

        if (StompCommand.DISCONNECT.equals(accessor.getCommand())) {
            String stompSessionId = accessor.getSessionId();
            if (stompSessionId != null) {
                // Mapping will be cleaned up by the lifecycle listener
                log.debug("[SessionInterceptor] STOMP DISCONNECT from session {}", stompSessionId);
            }
        }

        return message;
    }

    /**
     * Returns the game session ID for a given STOMP session, then removes the mapping.
     */
    public String removeGameSessionMapping(String stompSessionId) {
        return stompToGameSession.remove(stompSessionId);
    }

    /**
     * Returns the game session ID without removing the mapping.
     */
    public String getGameSessionId(String stompSessionId) {
        return stompToGameSession.get(stompSessionId);
    }

    /**
     * Stores which player ID was connected to a game session.
     * Called by GameSocketHandler or lifecycle listener.
     */
    public void mapPlayerToSession(long playerId, String gameSessionId) {
        gameSessionToPlayerId.put(gameSessionId, playerId);
        log.debug("[SessionInterceptor] Mapped player {} → game session {}", playerId, gameSessionId);
    }

    /**
     * Returns the player ID associated with a game session.
     */
    public Long getPlayerIdForSession(String gameSessionId) {
        return gameSessionToPlayerId.get(gameSessionId);
    }

    /**
     * Removes the player-to-session mapping.
     */
    public void removePlayerMapping(String gameSessionId) {
        gameSessionToPlayerId.remove(gameSessionId);
    }
}
