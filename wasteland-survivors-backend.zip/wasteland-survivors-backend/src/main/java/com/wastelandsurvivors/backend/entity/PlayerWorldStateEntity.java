package com.wastelandsurvivors.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Runtime player state within a specific world — persisted in {@code player_world_state}.
 *
 * <p>Separated from {@link PlayerEntity} because a player can be in multiple worlds
 * with different stats, positions, and scenes. This is the "where you are and what
 * you have right now" table for a given world.</p>
 *
 * <h3>Unity source mapping</h3>
 * <ul>
 *   <li>Health → StatsManager.currentHealth / maxHealth, Player_Health.cs</li>
 *   <li>Damage → StatsManager.damage, Player_Combat.damage</li>
 *   <li>Weapon range → StatsManager.weaponRange, Player_Combat.weaponRange</li>
 *   <li>Speed → StatsManager.speed, player_movement.speed</li>
 *   <li>Position → PositionDTO.x/y, player_movement.transform.position</li>
 *   <li>Facing → player_movement.facingDirection</li>
 *   <li>Scene → SceneChanger.sceneToLoad</li>
 * </ul>
 */
@Entity
@Table(name = "player_world_state",
       uniqueConstraints = @jakarta.persistence.UniqueConstraint(columnNames = {"player_id", "world_id"}))
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PlayerWorldStateEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "player_id", nullable = false)
    private Long playerId;

    @Column(name = "world_id", nullable = false, length = 64)
    private String worldId;

    // -- Health --
    @Column(name = "current_health", nullable = false)
    @Builder.Default
    private int currentHealth = 20;

    @Column(name = "max_health", nullable = false)
    @Builder.Default
    private int maxHealth = 20;

    // -- Combat stats --
    @Column(nullable = false)
    @Builder.Default
    private float damage = 1.0f;

    @Column(name = "weapon_range", nullable = false)
    @Builder.Default
    private float weaponRange = 3.5f;

    // -- Movement --
    @Column(nullable = false)
    @Builder.Default
    private float speed = 5.0f;

    // -- Position --
    @Column(name = "position_x", nullable = false)
    @Builder.Default
    private float positionX = 0.0f;

    @Column(name = "position_y", nullable = false)
    @Builder.Default
    private float positionY = 0.0f;

    @Column(name = "facing_direction", nullable = false)
    @Builder.Default
    private int facingDirection = 1;

    // -- Scene tracking --
    @Column(name = "current_scene", length = 100)
    private String currentScene;

    /**
     * Last time this state was saved.
     * Auto-updated by the database ON UPDATE CURRENT_TIMESTAMP.
     */
    @Column(name = "updated_at", nullable = false, insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}
