package com.wastelandsurvivors.backend.service;

import java.util.Map;

/**
 * Declares server-authoritative combat resolution.
 * The server validates attack cooldowns, selects targets, computes damage,
 * and manages the frenzy mechanic — the client is NOT trusted.
 *
 * <p>Supports two attack types:
 * <ul>
 *   <li><b>GUN (actionType="ATTACK")</b> — ranged, dot-product targeting,
 *       frenzy-scaling damage, no knockback</li>
 *   <li><b>MELEE (actionType="MELEE")</b> — proximity targeting, fixed melee
 *       damage (no frenzy), applies knockback</li>
 * </ul></p>
 */
public interface CombatService {

    /**
     * Processes an attack request from a client.
     * The server validates the cooldown, finds the closest valid target,
     * computes damage (with frenzy for gun, without for melee),
     * applies damage to the enemy, and handles kill consequences.
     *
     * @param playerId     The attacking player
     * @param worldId      The world context
     * @param attackPointX X coordinate of the attack origin
     * @param attackPointY Y coordinate of the attack origin
     * @param weaponRange  The weapon's attack radius (gun range or melee range)
     * @param actionType   "ATTACK" (gun) or "MELEE" (melee). Determines
     *                     targeting logic and whether frenzy applies.
     * @param meleeDamage  Damage for melee attacks (ignored for gun attacks)
     * @return A map with keys: "hit" (boolean), "targetEnemyId" (Long, nullable),
     *         "damageDealt" (int), "enemyDied" (boolean), "actionType" (String),
     *         "knockback" (Map with directionX, force, duration — only for melee hits),
     *         "frenzyDamage" (int, only for gun)
     */
    Map<String, Object> resolveAttack(Long playerId, String worldId,
                                       float attackPointX, float attackPointY,
                                       float weaponRange, String actionType,
                                       int meleeDamage);

    /**
     * Returns the current frenzy state for a player.
     *
     * @param playerId The player
     * @param worldId  The world
     * @return Map with "frenzyActive" (boolean), "currentDamage" (int),
     *         "baseDamage" (int), "maxDamage" (int)
     */
    Map<String, Object> getFrenzyState(Long playerId, String worldId);

    /**
     * Reloads the player's weapon — moves bullets from reserve to clip.
     * Calculates bulletsNeeded = maxClipSize - currentClip,
     * bulletsToLoad = min(bulletsNeeded, totalAmmoReserve).
     * Matches the reload logic in Player_Combat.cs.
     *
     * @param playerId The player reloading
     * @param worldId  The world context
     * @return Map with "currentClip" (int), "totalAmmoReserve" (int),
     *         "maxClipSize" (int), "bulletsLoaded" (int)
     */
    Map<String, Object> reload(Long playerId, String worldId);

    /**
     * Returns the current ammo state for a player in a world.
     *
     * @param playerId The player
     * @param worldId  The world
     * @return Map with "currentClip" (int), "maxClipSize" (int),
     *         "totalAmmoReserve" (int)
     */
    Map<String, Object> getAmmo(Long playerId, String worldId);
}
