package com.wastelandsurvivors.backend.repository;

import com.wastelandsurvivors.backend.entity.DialogueTreeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data JPA repository for {@link DialogueTreeEntity} (dialogue_trees table).
 */
public interface DialogueTreeRepository extends JpaRepository<DialogueTreeEntity, String> {

    /**
     * Finds all dialogue trees that belong to a specific NPC.
     */
    List<DialogueTreeEntity> findByNpcActorId(String npcActorId);

    /**
     * Finds the dialogue tree for a specific NPC at a specific quest state.
     * Used to route dialogue based on game progress (e.g., Sara says different
     * things before/after the quest).
     */
    Optional<DialogueTreeEntity> findByNpcActorIdAndQuestStateFilter(String npcActorId, int questStateFilter);
}
