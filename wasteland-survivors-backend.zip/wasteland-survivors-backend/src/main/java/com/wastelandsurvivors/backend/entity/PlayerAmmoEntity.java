package com.wastelandsurvivors.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Player ammunition state per world — persisted in {@code player_ammo}.
 *
 * <p>3NF design: separated from {@code player_world_state} because ammo changes
 * at a different frequency than position/health. Kept in its own table to avoid
 * lock contention and to keep the schema clean — ammo depends on the player+world
 * key, not on position or health.</p>
 *
 * <h3>Unity source mapping</h3>
 * <ul>
 *   <li>{@code currentClip} → Player_Combat.currentClip (default 5)</li>
 *   <li>{@code maxClipSize} → Player_Combat.maxClipSize (default 5)</li>
 *   <li>{@code totalAmmoReserve} → Player_Combat.totalAmmoReserve (default 25)</li>
 * </ul>
 */
@Entity
@Table(name = "player_ammo",
       uniqueConstraints = @jakarta.persistence.UniqueConstraint(columnNames = {"player_id", "world_id"}))
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PlayerAmmoEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "player_id", nullable = false)
    private Long playerId;

    @Column(name = "world_id", nullable = false, length = 64)
    private String worldId;

    /**
     * Bullets currently loaded in the magazine.
     * Maps to: Player_Combat.currentClip
     */
    @Column(name = "current_clip", nullable = false)
    @Builder.Default
    private int currentClip = 5;

    /**
     * Maximum bullets the magazine can hold.
     * Maps to: Player_Combat.maxClipSize
     */
    @Column(name = "max_clip_size", nullable = false)
    @Builder.Default
    private int maxClipSize = 5;

    /**
     * Total spare bullets the player carries (not in the magazine).
     * Maps to: Player_Combat.totalAmmoReserve
     */
    @Column(name = "total_ammo_reserve", nullable = false)
    @Builder.Default
    private int totalAmmoReserve = 25;

    @Column(name = "updated_at", nullable = false, insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}
