package com.wastelandsurvivors.backend.repository;

import com.wastelandsurvivors.backend.entity.PlayerWorldStateEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Spring Data JPA repository for {@link PlayerWorldStateEntity} (player_world_state table).
 */
public interface PlayerWorldStateRepository extends JpaRepository<PlayerWorldStateEntity, Long> {

    /**
     * Finds the state for a specific player in a specific world.
     * There is at most one row per (playerId, worldId) combination (unique constraint).
     */
    Optional<PlayerWorldStateEntity> findByPlayerIdAndWorldId(Long playerId, String worldId);
}
