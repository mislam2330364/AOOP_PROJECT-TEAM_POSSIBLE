package com.wastelandsurvivors.backend.exception;

import org.springframework.http.HttpStatus;

/**
 * Custom exception for all known game-specific error conditions.
 * Throw this instead of generic RuntimeException when a game rule is violated
 * or an expected resource is not found.
 * Carrying an HttpStatus means GlobalExceptionHandler can return the exact
 * correct HTTP status code to Unity without additional logic in controllers.
 *
 * Usage example:
 *   throw GameException.notFound('SESSION_NOT_FOUND', 'Session 42 does not exist');
 *   throw GameException.unauthorized('Token has expired — please log in again');
 */
public class GameException extends RuntimeException {

    // The HTTP status code returned to Unity — NOT_FOUND, UNAUTHORIZED, BAD_REQUEST etc.
    private final HttpStatus status;
    // Short machine-readable identifier, e.g. SESSION_NOT_FOUND, INVALID_JOIN_KEY.
    // Unity can switch on this to handle specific error cases without parsing the message string.
    private final String errorCode;

    public GameException(HttpStatus status, String errorCode, String message) {
        super(message);
        this.status = status;
        this.errorCode = errorCode;
    }

    public HttpStatus getStatus() {
        return status;
    }

    public String getErrorCode() {
        return errorCode;
    }

    // Static factories for common cases — cleaner than calling the constructor directly.
    public static GameException notFound(String errorCode, String message) {
        return new GameException(HttpStatus.NOT_FOUND, errorCode, message);
    }

    public static GameException unauthorized(String message) {
        return new GameException(HttpStatus.UNAUTHORIZED, "UNAUTHORIZED", message);
    }

    public static GameException badRequest(String errorCode, String message) {
        return new GameException(HttpStatus.BAD_REQUEST, errorCode, message);
    }
}

