package com.wastelandsurvivors.backend.service;

import com.wastelandsurvivors.backend.dto.game.AmmoUpdateDTO;
import com.wastelandsurvivors.backend.dto.game.CombatActionDTO;
import com.wastelandsurvivors.backend.dto.game.EnemyActionDTO;
import com.wastelandsurvivors.backend.dto.game.EnemyHealthDTO;
import com.wastelandsurvivors.backend.dto.game.EnemyLifecycleDTO;
import com.wastelandsurvivors.backend.dto.game.EnemyPositionDTO;
import com.wastelandsurvivors.backend.dto.game.HealthDTO;
import com.wastelandsurvivors.backend.dto.game.PositionDTO;

/**
 * Declares live game state synchronisation capabilities for multiplayer sessions.
 * Each method corresponds to one type of WebSocket message that can arrive from Unity.
 * GameSocketHandler calls these methods when a message arrives, then broadcasts
 * the message to the other player in the session.
 * Implementations store the latest state so reconnecting players can be resynchronised.
 */
public interface SyncService {

    /**
     * Processes a live position update from a player.
     * The latest position is stored so it can be retrieved if the player reconnects.
     * @param position Contains x, y coordinates, facingDirection, and a timestamp.
     *                 Maps directly to transform.position and facingDirection in player_movement.cs.
     */
    void handlePositionUpdate(PositionDTO position);

    /**
     * Processes a combat action performed by a player.
     * Logs the action for session replay. May apply server-side validation in future.
     * @param action Contains damage value, weapon range, attack origin coordinates, and timestamp.
     *               Maps directly to damage, weaponRange, and attackPoint in Player_Combat.cs.
     */
    void handleCombatAction(CombatActionDTO action);

    /**
     * Processes a health change event for a player.
     * Updates the server's authoritative health value for this player.
     * @param health Contains currentHealth and maxHealth.
     *               Maps directly to currentHealth and maxHealth in Player_Health.cs.
     */
    void handleHealthUpdate(HealthDTO health);

    /**
     * Retrieves the last known position of a player in a session.
     * Used when a player reconnects mid-session to restore their position.
     * @param playerId  The player whose position to retrieve
     * @param sessionId The session context for this query
     * @return The last saved PositionDTO, or a default spawn position if none is stored
     */
    PositionDTO getLastKnownPosition(String playerId, String sessionId);

    /**
     * Processes a live enemy position update from the host client.
     * Used to keep enemy movement in sync across all players.
     * @param position Contains enemyId, x/y coordinates, and a timestamp.
     */
    void handleEnemyPositionUpdate(EnemyPositionDTO position);

    /**
     * Processes an enemy combat action performed by the host client.
     * @param action Contains damage, attack range, attack origin, and a timestamp.
     */
    void handleEnemyAction(EnemyActionDTO action);

    /**
     * Processes an enemy health change event from the host client.
     * @param health Contains currentHealth and maxHealth for the enemy.
     */
    void handleEnemyHealthUpdate(EnemyHealthDTO health);

    /**
     * Processes an enemy spawn event for the session.
     * @param spawn Contains enemyId, enemyType, spawn position, and a timestamp.
     */
    void handleEnemySpawn(EnemyLifecycleDTO spawn);

    /**
     * Processes an enemy despawn event for the session.
     * @param despawn Contains enemyId and session context.
     */
    void handleEnemyDespawn(EnemyLifecycleDTO despawn);

    /**
     * Processes a boss phase transition (Phase 1 → Phase 2 enraged mode).
     * Broadcast to session so the guest client can trigger the scream SFX
     * (Boss_Scream.mp3), health restore, damage buff, and speed multiplier.
     * @param message The raw WebSocket message containing boss phase transition data
     */
    void handleBossPhase(Object payload);

    /**
     * Processes an ammo state update from a player.
     * Sent when the player fires, reloads, or picks up ammo during a multiplayer session.
     * Stores the latest ammo state so reconnecting players can be resynchronised.
     * @param ammo Contains currentClip, maxClipSize, totalAmmoReserve, and a timestamp.
     *             Maps directly to the ammo fields in Player_Combat.cs.
     */
    void handleAmmoUpdate(AmmoUpdateDTO ammo);
}

