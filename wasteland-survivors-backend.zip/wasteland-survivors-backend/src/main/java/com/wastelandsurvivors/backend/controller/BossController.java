package com.wastelandsurvivors.backend.controller;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.service.BossService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST Controller for boss encounter management.
 * Tracks the two-phase boss fight lifecycle per world.
 *
 * <p>Phase 1 → Phase 2 transition happens when the boss health first hits 0.
 * The boss restores to phase2Health (100), gains +2 damage, and 1.5× speed.
 * The boss can only be truly killed in Phase 2.</p>
 */
@RestController
@RequestMapping(AppConstants.API_V1 + "/worlds")
@Slf4j
public class BossController {

    private final BossService bossService;

    public BossController(BossService bossService) {
        this.bossService = bossService;
    }

    /**
     * Returns the boss encounter state for a world.
     * GET /api/v1/worlds/{worldId}/boss
     */
    @GetMapping("/{worldId}/boss")
    public ResponseEntity<?> getBossState(@PathVariable String worldId) {
        log.debug("[BossController] GET /{}/boss", worldId);
        return ResponseEntity.ok(bossService.getBossState(worldId));
    }

    /**
     * Starts the boss fight. Called when the player enters the boss trigger zone.
     * POST /api/v1/worlds/{worldId}/boss/start?bossEnemyId=...
     */
    @PostMapping("/{worldId}/boss/start")
    public ResponseEntity<?> startBossFight(@PathVariable String worldId,
                                            @RequestParam Long bossEnemyId) {
        log.info("[BossController] POST /{}/boss/start?bossEnemyId={}", worldId, bossEnemyId);
        return ResponseEntity.ok(bossService.startBossFight(worldId, bossEnemyId));
    }

    /**
     * Triggers Phase 2 of the boss fight. Called when boss health first hits 0.
     * The boss restores to phase2Health (100 HP), gains +2 damage, and 1.5× speed.
     * POST /api/v1/worlds/{worldId}/boss/phase2
     */
    @PostMapping("/{worldId}/boss/phase2")
    public ResponseEntity<?> triggerPhase2(@PathVariable String worldId) {
        log.info("[BossController] POST /{}/boss/phase2", worldId);
        return ResponseEntity.ok(bossService.triggerPhase2(worldId));
    }

    /**
     * Marks the boss as defeated.
     * POST /api/v1/worlds/{worldId}/boss/defeat
     */
    @PostMapping("/{worldId}/boss/defeat")
    public ResponseEntity<?> defeatBoss(@PathVariable String worldId) {
        log.info("[BossController] POST /{}/boss/defeat", worldId);
        return ResponseEntity.ok(bossService.defeatBoss(worldId));
    }
}
