package com.wastelandsurvivors.backend.controller;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.service.PersistenceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * REST Controller for persistent object tracking per world.
 * Tracks which objects have been destroyed/collected so they don't respawn.
 */
@RestController
@RequestMapping(AppConstants.API_V1 + "/worlds")
@Slf4j
public class PersistenceController {

    private final PersistenceService persistenceService;

    public PersistenceController(PersistenceService persistenceService) {
        this.persistenceService = persistenceService;
    }

    /**
     * Returns all destroyed object IDs for a world.
     * GET /api/v1/worlds/{worldId}/destroyed-objects
     */
    @GetMapping("/{worldId}/destroyed-objects")
    public ResponseEntity<?> getDestroyedObjects(@PathVariable String worldId) {
        log.debug("[PersistenceController] GET /{}/destroyed-objects", worldId);
        return ResponseEntity.ok(persistenceService.getDestroyedObjects(worldId));
    }

    /**
     * Checks if a specific object is destroyed in a world.
     * GET /api/v1/worlds/{worldId}/destroyed-objects/{objectId}
     */
    @GetMapping("/{worldId}/destroyed-objects/{objectId}")
    public ResponseEntity<?> isObjectDestroyed(@PathVariable String worldId,
                                                @PathVariable String objectId) {
        log.debug("[PersistenceController] GET /{}/destroyed-objects/{}", worldId, objectId);
        boolean destroyed = persistenceService.isObjectDestroyed(worldId, objectId);
        return ResponseEntity.ok(Map.of("worldId", worldId,
                "objectId", objectId, "isDestroyed", destroyed));
    }

    /**
     * Marks an object as destroyed in a world. Idempotent.
     * POST /api/v1/worlds/{worldId}/destroyed-objects/{objectId}
     */
    @PostMapping("/{worldId}/destroyed-objects/{objectId}")
    public ResponseEntity<?> markObjectDestroyed(@PathVariable String worldId,
                                                  @PathVariable String objectId) {
        log.info("[PersistenceController] POST /{}/destroyed-objects/{}", worldId, objectId);
        persistenceService.markObjectDestroyed(worldId, objectId);
        return ResponseEntity.ok(Map.of("message", "Object marked as destroyed"));
    }
}
