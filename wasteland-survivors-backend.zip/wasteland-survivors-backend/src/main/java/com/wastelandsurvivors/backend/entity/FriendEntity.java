package com.wastelandsurvivors.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Represents a friend relationship between two players in the {@code friends} table.
 *
 * <p>Friendship is bidirectional — if player A adds player B, both can see each
 * other in their friends list. The relationship is stored as a single row where
 * {@code playerId} is the player who initiated the request and {@code friendId}
 * is the player who was added.</p>
 *
 * <h3>Table mapping</h3>
 * <pre>
 * friends
 *   id          BIGINT PK    → this.id
 *   player_id   BIGINT       → this.playerId (FK → players.id)
 *   friend_id   BIGINT       → this.friendId (FK → players.id)
 *   created_at  TIMESTAMP    → auto-set by DB on insert
 * </pre>
 *
 * <h3>Unity source mapping</h3>
 * <ul>
 *   <li>{@code playerId} → FriendMenuManager local player ID</li>
 *   <li>{@code friendId} → The friend being added/removed</li>
 * </ul>
 */
@Entity
@Table(name = "friends",
       uniqueConstraints = @jakarta.persistence.UniqueConstraint(columnNames = {"player_id", "friend_id"}))
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FriendEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long playerId;

    @Column(nullable = false)
    private Long friendId;

    @Column(nullable = false, insertable = false, updatable = false)
    private LocalDateTime createdAt;
}
