package com.wastelandsurvivors.backend.dto.game;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Carries the details of a combat action performed by a player.
 * Sent over WebSocket when the player attacks, wrapped inside a WebSocketMessage. (Both directions)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CombatActionDTO {

    // The playerId of who performed the action — matches the playerId stored in GameAPI.cs
    private long playerId;

    // The session this action belongs to — matches sessionId in GameAPI.cs
    private String sessionId;

    // Type of action performed — "ATTACK" (gun) or "MELEE" (melee). Use AppConstants.MSG_ACTION for the envelope type.
    private String actionType;

    // The damage value of this attack — sourced from the damage variable in Player_Combat.cs
    private int damage;

    // The radius of the attack hitbox — sourced from weaponRange in Player_Combat.cs (gun) or meleeRange (melee)
    private float weaponRange;

    // X coordinate of the attack origin point — sourced from attackPoint.position.x in Player_Combat.cs
    private float attackPointX;

    // Y coordinate of the attack origin point — sourced from attackPoint.position.y in Player_Combat.cs
    private float attackPointY;

    // Damage for melee attacks — sourced from meleeDamage in Player_Combat.cs. Only used when actionType is "MELEE".
    @Builder.Default
    private int meleeDamage = 2;

    // Current bullets in the magazine — sourced from currentClip in Player_Combat.cs
    @Builder.Default
    private int currentClip = 30;

    // Total bullets in reserve — sourced from totalAmmoReserve in Player_Combat.cs
    @Builder.Default
    private int totalAmmoReserve = 60;

    // Unix time in milliseconds when this action was captured in Unity
    private long timestamp;
}

