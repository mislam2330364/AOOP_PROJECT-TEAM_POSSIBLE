package com.wastelandsurvivors.backend.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Returned by the GlobalExceptionHandler for every error that occurs.
 * Every error Unity ever receives will always have this exact shape — never a raw HTML error page or unparseable response.
 * Unity should always check for this structure when a request fails. (Server to Unity)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ErrorResponse {

    // The HTTP status code, e.g. 400 for bad input, 404 for not found, 500 for server error
    private int statusCode;

    // Short machine-readable error name, e.g. SESSION_NOT_FOUND, VALIDATION_FAILED
    private String error;

    // Plain English explanation of what went wrong — safe to display to the developer, not necessarily to the player
    private String message;

    // ISO-8601 formatted date and time when the error occurred — useful for debugging logs
    private String timestamp;
}

