package com.wastelandsurvivors.backend.repository;

import com.wastelandsurvivors.backend.entity.PlayerAmmoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Spring Data JPA repository for {@link PlayerAmmoEntity} (player_ammo table).
 */
public interface PlayerAmmoRepository extends JpaRepository<PlayerAmmoEntity, Long> {

    /**
     * Finds ammo state for a specific player in a specific world.
     */
    Optional<PlayerAmmoEntity> findByPlayerIdAndWorldId(Long playerId, String worldId);
}
