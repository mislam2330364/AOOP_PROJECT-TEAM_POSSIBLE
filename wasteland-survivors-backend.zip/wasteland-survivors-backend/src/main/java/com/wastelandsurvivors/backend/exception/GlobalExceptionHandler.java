package com.wastelandsurvivors.backend.exception;

import com.wastelandsurvivors.backend.dto.response.ErrorResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;

/**
 * Intercepts every exception thrown anywhere in the application and converts it
 * to a consistent ErrorResponse JSON object before it reaches Unity.
 *
 * Without this: Spring Boot returns HTML error pages or inconsistent JSON structures
 * that Unity cannot reliably parse.
 *
 * With this: Unity always receives the same shape regardless of what went wrong:
 *   { statusCode, error, message, timestamp }
 *
 * Unity should check the HTTP status code on every response and parse this
 * object on any non-2xx status.
 */
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    /**
     * Handles known game errors from Service methods.
     * Returns the correct HTTP status and a structured body Unity can parse.
     */
    @ExceptionHandler(GameException.class)
    public ResponseEntity<ErrorResponse> handleGameException(GameException ex) {
        log.error("[GlobalExceptionHandler] GameException: code={} message={}",
                ex.getErrorCode(), ex.getMessage());
        ErrorResponse errorResponse = ErrorResponse.builder()
                .statusCode(ex.getStatus().value())
                .error(ex.getErrorCode())
                .message(ex.getMessage())
                .timestamp(LocalDateTime.now().toString())
                .build();
        return ResponseEntity.status(ex.getStatus()).body(errorResponse);
    }

    /**
     * Fires when @Valid rejects a request body — e.g. empty username, short password.
     * Returns a 400 with the specific field validation message so Unity can show the correct error.
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidationException(MethodArgumentNotValidException ex) {
        // Triggered automatically by @Valid annotations in controllers — no extra code needed.
        String msg = ex.getBindingResult().getFieldErrors().get(0).getDefaultMessage();
        log.warn("[GlobalExceptionHandler] Validation failed: {}", msg);
        ErrorResponse errorResponse = ErrorResponse.builder()
                .statusCode(HttpStatus.BAD_REQUEST.value())
                .error("VALIDATION_FAILED")
                .message(msg)
                .timestamp(LocalDateTime.now().toString())
                .build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
    }

    /**
     * Safety net for anything not explicitly handled above.
     * Generic message is intentional — internal details must not reach the client in production.
     * Full stack trace is in the server log via the log.error call above.
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleUnexpectedException(Exception ex) {
        log.error("[GlobalExceptionHandler] Unhandled exception", ex);
        ErrorResponse errorResponse = ErrorResponse.builder()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
                .error("INTERNAL_SERVER_ERROR")
                .message("An unexpected error occurred. Please try again.")
                .timestamp(LocalDateTime.now().toString())
                .build();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
    }
}

