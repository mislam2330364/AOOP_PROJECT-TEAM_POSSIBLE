package com.wastelandsurvivors.backend.dto.game;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Carries the live position of a player during a multiplayer session.
 * Sent over WebSocket every 100ms wrapped inside a WebSocketMessage. (Both directions)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PositionDTO {

    // Which player is sending — matches the playerId stored in GameAPI.cs after login
    private long playerId;

    // Which multiplayer session this position belongs to — matches sessionId in GameAPI.cs
    private String sessionId;

    // The player's X coordinate in Unity world space — sourced from transform.position.x in player_movement.cs
    private float x;

    // The player's Y coordinate in Unity world space — sourced from transform.position.y in player_movement.cs
    private float y;

    // 1 = player is facing right, -1 = player is facing left. Sourced from facingDirection variable in player_movement.cs.
    // Used by the receiving client to flip the opponent's sprite.
    private int facingDirection;

    // Current scene name so the other player knows which scene we're in.
    private String sceneName;

    // Unix time in milliseconds when this was captured in Unity.
    private long timestamp;
}

