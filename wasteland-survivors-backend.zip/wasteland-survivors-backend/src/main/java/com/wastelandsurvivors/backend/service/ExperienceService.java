package com.wastelandsurvivors.backend.service;

import com.wastelandsurvivors.backend.entity.PlayerProgressionEntity;

/**
 * Declares experience and leveling management per world.
 * Handles EXP awarding, level-up logic, and progression persistence.
 */
public interface ExperienceService {

    /**
     * Returns the current progression (level, EXP, thresholds) for a player in a world.
     *
     * @param playerId The player
     * @param worldId  The world
     * @return PlayerProgressionEntity (created with defaults if none exists)
     */
    PlayerProgressionEntity getProgression(Long playerId, String worldId);

    /**
     * Adds EXP to the player and checks for level-up.
     * Level-up formula: when experience >= expToLevel → level++,
     * subtract threshold, multiply threshold by expGrowthMultiplier.
     *
     * @param playerId  The player gaining EXP
     * @param worldId   The world context
     * @param expAmount How much EXP to add (from enemy kill, quest reward, etc.)
     * @return Updated PlayerProgressionEntity with new level/EXP values
     */
    PlayerProgressionEntity addExperience(Long playerId, String worldId, long expAmount);
}
