package com.wastelandsurvivors.backend.controller;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.service.QuestService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST Controller for quest state management — multi-quest capable.
 *
 * <p><b>Backward-compatible endpoints</b> (default to "sara_village"):</p>
 * <pre>
 * GET  /api/v1/worlds/{worldId}/quest
 * POST /api/v1/worlds/{worldId}/quest/activate
 * POST /api/v1/worlds/{worldId}/quest/enemy-killed?isBoss=true|false
 * POST /api/v1/worlds/{worldId}/quest/hand-in
 * </pre>
 *
 * <p><b>Multi-quest endpoints</b> (Quest2 and future quests):</p>
 * <pre>
 * GET  /api/v1/worlds/{worldId}/quests/{questId}
 * POST /api/v1/worlds/{worldId}/quests/{questId}/activate
 * POST /api/v1/worlds/{worldId}/quests/{questId}/enemy-killed?isBoss=true|false
 * POST /api/v1/worlds/{worldId}/quests/{questId}/hand-in
 * </pre>
 */
@RestController
@RequestMapping(AppConstants.API_V1 + "/worlds")
@Slf4j
public class QuestController {

    private final QuestService questService;

    public QuestController(QuestService questService) {
        this.questService = questService;
    }

    // =========================================================================
    // Backward-compatible endpoints (default questId = "sara_village")
    // =========================================================================

    /**
     * Returns the default quest state (Sara's "Clear the Village").
     * GET /api/v1/worlds/{worldId}/quest
     */
    @GetMapping("/{worldId}/quest")
    public ResponseEntity<?> getQuestState(@PathVariable String worldId) {
        log.debug("[QuestController] GET /{}/quest (sara_village default)", worldId);
        return ResponseEntity.ok(questService.getQuestState(worldId));
    }

    /**
     * Activates the default quest — transitions state 0→1.
     * POST /api/v1/worlds/{worldId}/quest/activate
     */
    @PostMapping("/{worldId}/quest/activate")
    public ResponseEntity<?> activateQuest(@PathVariable String worldId) {
        log.info("[QuestController] POST /{}/quest/activate (sara_village default)", worldId);
        return ResponseEntity.ok(questService.activateQuest(worldId));
    }

    /**
     * Records an enemy kill against the default quest objectives.
     * POST /api/v1/worlds/{worldId}/quest/enemy-killed?isBoss=true|false
     */
    @PostMapping("/{worldId}/quest/enemy-killed")
    public ResponseEntity<?> recordEnemyKilled(@PathVariable String worldId,
                                               @RequestParam boolean isBoss) {
        log.info("[QuestController] POST /{}/quest/enemy-killed?isBoss={} (sara_village default)",
                worldId, isBoss);
        return ResponseEntity.ok(questService.recordEnemyKilled(worldId, isBoss));
    }

    /**
     * Hands in the default quest — transitions state 2→3.
     * POST /api/v1/worlds/{worldId}/quest/hand-in
     */
    @PostMapping("/{worldId}/quest/hand-in")
    public ResponseEntity<?> handInQuest(@PathVariable String worldId) {
        log.info("[QuestController] POST /{}/quest/hand-in (sara_village default)", worldId);
        return ResponseEntity.ok(questService.handInQuest(worldId));
    }

    // =========================================================================
    // Multi-quest endpoints (explicit questId)
    // =========================================================================

    /**
     * Returns quest state for a specific quest in a world.
     * GET /api/v1/worlds/{worldId}/quests/{questId}
     *
     * @param worldId The world
     * @param questId Quest discriminator — e.g., "sara_village", "quest2"
     */
    @GetMapping("/{worldId}/quests/{questId}")
    public ResponseEntity<?> getQuestState(@PathVariable String worldId,
                                           @PathVariable String questId) {
        log.debug("[QuestController] GET /{}/quests/{}", worldId, questId);
        return ResponseEntity.ok(questService.getQuestState(worldId, questId));
    }

    /**
     * Activates a specific quest — transitions state 0→1.
     * POST /api/v1/worlds/{worldId}/quests/{questId}/activate
     */
    @PostMapping("/{worldId}/quests/{questId}/activate")
    public ResponseEntity<?> activateQuest(@PathVariable String worldId,
                                           @PathVariable String questId) {
        log.info("[QuestController] POST /{}/quests/{}/activate", worldId, questId);
        return ResponseEntity.ok(questService.activateQuest(worldId, questId));
    }

    /**
     * Records an enemy kill against a specific quest's objectives.
     * POST /api/v1/worlds/{worldId}/quests/{questId}/enemy-killed?isBoss=true|false
     */
    @PostMapping("/{worldId}/quests/{questId}/enemy-killed")
    public ResponseEntity<?> recordEnemyKilled(@PathVariable String worldId,
                                               @PathVariable String questId,
                                               @RequestParam boolean isBoss) {
        log.info("[QuestController] POST /{}/quests/{}/enemy-killed?isBoss={}",
                worldId, questId, isBoss);
        return ResponseEntity.ok(questService.recordEnemyKilled(worldId, questId, isBoss));
    }

    /**
     * Hands in a specific quest — transitions state 2→3.
     * POST /api/v1/worlds/{worldId}/quests/{questId}/hand-in
     */
    @PostMapping("/{worldId}/quests/{questId}/hand-in")
    public ResponseEntity<?> handInQuest(@PathVariable String worldId,
                                         @PathVariable String questId) {
        log.info("[QuestController] POST /{}/quests/{}/hand-in", worldId, questId);
        return ResponseEntity.ok(questService.handInQuest(worldId, questId));
    }
}
