package com.wastelandsurvivors.backend.service.impl;

import com.wastelandsurvivors.backend.entity.EnemyInstanceEntity;
import com.wastelandsurvivors.backend.entity.EnemyTypeEntity;
import com.wastelandsurvivors.backend.exception.GameException;
import com.wastelandsurvivors.backend.repository.EnemyInstanceRepository;
import com.wastelandsurvivors.backend.repository.EnemyTypeRepository;
import com.wastelandsurvivors.backend.service.EnemyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Full implementation of {@link EnemyService}.
 *
 * <p>Enemy types are the template catalog (enemy_types table).
 * Enemy instances are runtime spawns in a world (enemy_instances table).
 * When an enemy is spawned, its type template stats are copied to the instance.</p>
 */
@Service
@Slf4j
public class EnemyServiceImpl implements EnemyService {

    private final EnemyTypeRepository enemyTypeRepository;
    private final EnemyInstanceRepository enemyInstanceRepository;

    public EnemyServiceImpl(EnemyTypeRepository enemyTypeRepository,
                             EnemyInstanceRepository enemyInstanceRepository) {
        this.enemyTypeRepository = enemyTypeRepository;
        this.enemyInstanceRepository = enemyInstanceRepository;
    }

    // -- Type catalog --

    @Override
    public List<EnemyTypeEntity> getAllEnemyTypes() {
        return enemyTypeRepository.findAll();
    }

    @Override
    public EnemyTypeEntity getEnemyType(String typeId) {
        return enemyTypeRepository.findById(typeId)
                .orElseThrow(() -> GameException.notFound("ENEMY_TYPE_NOT_FOUND",
                        "Enemy type '" + typeId + "' does not exist in the catalog"));
    }

    // -- Instance management --

    @Override
    public List<EnemyInstanceEntity> getAliveEnemies(String worldId) {
        return enemyInstanceRepository.findByWorldIdAndIsAlive(worldId, true);
    }

    @Override
    public List<EnemyInstanceEntity> getAllEnemies(String worldId) {
        return enemyInstanceRepository.findByWorldId(worldId);
    }

    @Override
    public EnemyInstanceEntity spawnEnemy(String worldId, String typeId, float x, float y) {
        // Validate the type exists
        EnemyTypeEntity type = enemyTypeRepository.findById(typeId)
                .orElseThrow(() -> GameException.notFound("ENEMY_TYPE_NOT_FOUND",
                        "Cannot spawn — enemy type '" + typeId + "' does not exist"));

        EnemyInstanceEntity instance = EnemyInstanceEntity.builder()
                .worldId(worldId)
                .typeId(typeId)
                .currentHealth(type.getBaseHealth())
                .positionX(x)
                .positionY(y)
                .facingDirection(type.getNativeSpriteFacingSign())
                .enemyState("IDLE")
                .isAlive(true)
                .build();

        EnemyInstanceEntity saved = enemyInstanceRepository.save(instance);

        log.info("[Enemy] Spawned: enemyId={} typeId={} worldId={} pos=({},{}) health={}",
                saved.getEnemyId(), typeId, worldId, x, y, type.getBaseHealth());

        return saved;
    }

    @Override
    public EnemyInstanceEntity damageEnemy(Long enemyId, int damage) {
        EnemyInstanceEntity enemy = enemyInstanceRepository.findById(enemyId)
                .orElseThrow(() -> GameException.notFound("ENEMY_NOT_FOUND",
                        "Enemy instance " + enemyId + " does not exist"));

        if (!enemy.isAlive()) {
            throw GameException.badRequest("ENEMY_ALREADY_DEAD",
                    "Enemy " + enemyId + " is already dead");
        }

        int newHealth = enemy.getCurrentHealth() - damage;
        enemy.setCurrentHealth(newHealth);

        if (newHealth <= 0) {
            enemy.setCurrentHealth(0);
            enemy.setAlive(false);
            log.info("[Enemy] Enemy died: enemyId={} typeId={} worldId={}",
                    enemyId, enemy.getTypeId(), enemy.getWorldId());
        }

        enemyInstanceRepository.save(enemy);
        return enemy;
    }
}
