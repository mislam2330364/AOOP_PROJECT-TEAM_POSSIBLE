package com.wastelandsurvivors.backend.service;

import com.wastelandsurvivors.backend.entity.PlayerWorldStateEntity;

/**
 * Declares player stats management per world.
 * Server is authoritative for player health, damage, speed, weapon range,
 * position, facing direction, and current scene.
 */
public interface PlayerStatsService {

    /**
     * Returns the full player state for a given world.
     *
     * @param playerId The player whose stats to retrieve
     * @param worldId  The world context
     * @return PlayerWorldStateEntity, or a new default state if none exists yet
     */
    PlayerWorldStateEntity getStats(Long playerId, String worldId);

    /**
     * Updates the player's runtime state for a world.
     * Creates the row if it doesn't exist yet.
     *
     * @param playerId The player whose stats to update
     * @param worldId  The world context
     * @param stats    Partial or full state to merge/overwrite
     * @return The updated PlayerWorldStateEntity
     */
    PlayerWorldStateEntity updateStats(Long playerId, String worldId, PlayerWorldStateEntity stats);
}
