package com.wastelandsurvivors.backend.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Returned by both /api/v1/auth/login and /api/v1/auth/register.
 * Unity must store the token field and include it in the Authorization header of every future REST request
 * and the WebSocket connection handshake. (Server to Unity)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuthResponse {

    // The JWT token — Unity stores this after login and sends it as: Authorization: Bearer {token}
    private String token;

    // The unique database ID for this player — stored in GameAPI.cs as localPlayerId
    private Long playerId;

    // The player's username — returned for convenience so Unity can display it
    private String username;

    // A human-readable status message, e.g. "Login successful" or "Registration successful"
    private String message;
}

