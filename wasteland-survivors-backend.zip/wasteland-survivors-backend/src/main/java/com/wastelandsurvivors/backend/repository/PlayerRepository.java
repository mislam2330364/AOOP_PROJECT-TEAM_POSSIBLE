package com.wastelandsurvivors.backend.repository;

import com.wastelandsurvivors.backend.entity.PlayerEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PlayerRepository extends JpaRepository<PlayerEntity, Long> {
    Optional<PlayerEntity> findByUsername(String username);
    boolean existsByUsername(String username);
}

