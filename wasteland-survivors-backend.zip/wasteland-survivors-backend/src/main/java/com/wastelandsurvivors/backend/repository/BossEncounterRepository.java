package com.wastelandsurvivors.backend.repository;

import com.wastelandsurvivors.backend.entity.BossEncounterEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Spring Data JPA repository for {@link BossEncounterEntity} (boss_encounters table).
 */
public interface BossEncounterRepository extends JpaRepository<BossEncounterEntity, Long> {

    /**
     * Finds the boss encounter record for a specific world.
     * Each world has exactly one boss encounter row (unique constraint).
     */
    Optional<BossEncounterEntity> findByWorldId(String worldId);
}
