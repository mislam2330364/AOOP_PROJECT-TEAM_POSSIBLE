package com.wastelandsurvivors.backend.controller;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.dto.request.GameSaveRequest;
import com.wastelandsurvivors.backend.service.GameSaveService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST Controller for unified game save/load.
 *
 * <p>These endpoints are called by Unity's MenuController when the player
 * presses "Save Game" or "Load Game" from the pause menu.</p>
 *
 * <h3>Unity → Backend mapping</h3>
 * <pre>
 * MenuController.OnSaveButtonPressed() → POST /api/v1/gamesave/save
 * MenuController.OnLoadButtonPressed() → GET  /api/v1/gamesave/load/{playerId}?worldId=...
 * </pre>
 *
 * <p>A single save/load call replaces what would otherwise be 6+ separate
 * REST calls (one per subsystem: stats, EXP, ammo, quest, boss, persistence).
 * This reduces latency and eliminates partial-save failure modes.</p>
 */
@RestController
@RequestMapping(AppConstants.API_V1 + "/gamesave")
@Slf4j
public class GameSaveController {

    private final GameSaveService gameSaveService;

    public GameSaveController(GameSaveService gameSaveService) {
        this.gameSaveService = gameSaveService;
    }

    /**
     * Saves the player's full game state.
     *
     * <p><b>Unity sends:</b> GameSaveRequest JSON</p>
     * <pre>
     * {
     *   "playerId": 1,
     *   "worldId": "WORLD_ABC123",
     *   "currentHealth": 18, "maxHealth": 20,
     *   "damage": 1.5, "weaponRange": 3.5, "speed": 5.0,
     *   "positionX": 12.3, "positionY": 4.7, "facingDirection": 1,
     *   "currentScene": "village_scene_1",
     *   "experience": 150, "level": 2, "expToLevel": 12, "expGrowthMultiplier": 1.2,
     *   "currentClip": 25, "maxClipSize": 30, "totalAmmoReserve": 55,
     *   "questState": 1, "zombiesRemaining": 8, "isBossAlive": true,
     *   "fightStarted": false, "isDefeated": false, "currentPhase": 1, "phase2Activated": false,
     *   "destroyedObjectIds": ["HealthPack_10_5", "GoldBar_3_2"]
     * }
     * </pre>
     *
     * <p><b>Unity receives (200 OK):</b></p>
     * <pre>
     * {
     *   "playerId": 1, "worldId": "WORLD_ABC123",
     *   "message": "Game saved successfully"
     * }
     * </pre>
     *
     * @param request The full game state to persist
     * @return 200 OK with confirmation
     */
    @PostMapping("/save")
    public ResponseEntity<?> save(@RequestBody GameSaveRequest request) {
        log.info("[GameSaveController] POST /save — playerId={} worldId={} currentScene={}",
                request.getPlayerId(), request.getWorldId(), request.getCurrentScene());
        log.debug("[GameSaveController] Save payload: health={}/{} damage={} pos=({},{}) exp={} lvl={} ammo={}/{} quest={}",
                request.getCurrentHealth(), request.getMaxHealth(),
                request.getDamage(), request.getPositionX(), request.getPositionY(),
                request.getExperience(), request.getLevel(),
                request.getCurrentClip(), request.getTotalAmmoReserve(),
                request.getQuestState());
        try {
            return ResponseEntity.ok(gameSaveService.save(request));
        } catch (Exception e) {
            log.error("[GameSaveController] Save failed with exception: {} — {}",
                    e.getClass().getSimpleName(), e.getMessage());
            throw e; // Let GlobalExceptionHandler format the response
        }
    }

    /**
     * Loads the player's full game state.
     *
     * <p><b>Unity sends:</b> Path variable + query param</p>
     * <pre>
     * GET /api/v1/gamesave/load/1?worldId=WORLD_ABC123
     * </pre>
     *
     * <p><b>Unity receives (200 OK):</b> Full GameSaveResponse JSON with all
     * nested state sections. See {@link com.wastelandsurvivors.backend.dto.response.GameSaveResponse}
     * for the complete structure.</p>
     *
     * <p><b>Error responses:</b>
     * <ul>
     *   <li>404 NOT_FOUND — Player does not exist</li>
     *   <li>400 BAD_REQUEST — Missing playerId or worldId</li>
     * </ul></p>
     *
     * @param playerId The player whose state to load
     * @param worldId  The world to load state for
     * @return 200 OK with full aggregated game state
     */
    @GetMapping("/load/{playerId}")
    public ResponseEntity<?> load(@PathVariable Long playerId,
                                   @RequestParam String worldId) {
        log.info("[GameSaveController] GET /load/{}?worldId={}", playerId, worldId);
        return ResponseEntity.ok(gameSaveService.load(playerId, worldId));
    }
}