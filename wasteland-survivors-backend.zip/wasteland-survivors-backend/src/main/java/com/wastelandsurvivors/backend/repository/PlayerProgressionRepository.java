package com.wastelandsurvivors.backend.repository;

import com.wastelandsurvivors.backend.entity.PlayerProgressionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Spring Data JPA repository for {@link PlayerProgressionEntity} (player_progression table).
 */
public interface PlayerProgressionRepository extends JpaRepository<PlayerProgressionEntity, Long> {

    /**
     * Finds the progression for a specific player in a specific world.
     */
    Optional<PlayerProgressionEntity> findByPlayerIdAndWorldId(Long playerId, String worldId);
}
