package com.wastelandsurvivors.backend.service.impl;

import com.wastelandsurvivors.backend.entity.EnemyInstanceEntity;
import com.wastelandsurvivors.backend.entity.PlayerWorldStateEntity;
import com.wastelandsurvivors.backend.exception.GameException;
import com.wastelandsurvivors.backend.repository.BossEncounterRepository;
import com.wastelandsurvivors.backend.repository.EnemyInstanceRepository;
import com.wastelandsurvivors.backend.repository.EnemyTypeRepository;
import com.wastelandsurvivors.backend.repository.PlayerWorldStateRepository;
import com.wastelandsurvivors.backend.service.AmmoService;
import com.wastelandsurvivors.backend.service.CombatService;
import com.wastelandsurvivors.backend.service.ExperienceService;
import com.wastelandsurvivors.backend.service.QuestService;
import com.wastelandsurvivors.backend.entity.PlayerAmmoEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Server-authoritative combat resolution.
 *
 * <p>The client sends an attack intent — the server validates cooldowns,
 * selects the target, computes damage, applies frenzy, and triggers
 * kill consequences (EXP, quest, boss). The client is NEVER trusted
 * with final damage numbers or hit confirmation.</p>
 *
 * <h3>Frenzy mechanic (matches Player_Combat.cs)</h3>
 * <ul>
 *   <li>Damage increases by +1 per successful hit</li>
 *   <li>Caps at maxDamage (default 5 over base)</li>
 *   <li>Once at max, a countdown starts</li>
 *   <li>When countdown expires, damage resets to base</li>
 * </ul>
 */
@Service
@Slf4j
public class CombatServiceImpl implements CombatService {

    private static final int FRENZY_MAX_BONUS = 4; // +4 = max 5 total when base is 1
    private static final long FRENZY_DURATION_MS = 10_000; // 10 seconds at max

    private final PlayerWorldStateRepository stateRepository;
    private final EnemyInstanceRepository enemyInstanceRepository;
    private final EnemyTypeRepository enemyTypeRepository;
    private final BossEncounterRepository bossEncounterRepository;
    private final ExperienceService experienceService;
    private final QuestService questService;
    private final AmmoService ammoService;

    // In-memory cooldown and frenzy tracking per player.
    // Key format: "playerId:worldId"
    private final Map<String, Long> lastAttackTime = new ConcurrentHashMap<>();
    private final Map<String, Integer> frenzyBonus = new ConcurrentHashMap<>();
    private final Map<String, Long> frenzyMaxActiveSince = new ConcurrentHashMap<>();

    private static final long ATTACK_COOLDOWN_MS = 500; // 500ms between attacks

    public CombatServiceImpl(PlayerWorldStateRepository stateRepository,
                              EnemyInstanceRepository enemyInstanceRepository,
                              EnemyTypeRepository enemyTypeRepository,
                              BossEncounterRepository bossEncounterRepository,
                              ExperienceService experienceService,
                              QuestService questService,
                              AmmoService ammoService) {
        this.stateRepository = stateRepository;
        this.enemyInstanceRepository = enemyInstanceRepository;
        this.enemyTypeRepository = enemyTypeRepository;
        this.bossEncounterRepository = bossEncounterRepository;
        this.experienceService = experienceService;
        this.questService = questService;
        this.ammoService = ammoService;
    }

    @Override
    public Map<String, Object> resolveAttack(Long playerId, String worldId,
                                              float attackPointX, float attackPointY,
                                              float weaponRange, String actionType,
                                              int meleeDamage) {
        boolean isMelee = "MELEE".equalsIgnoreCase(actionType);

        // 1. Validate cooldown
        String frenzyKey = playerId + ":" + worldId;
        long now = System.currentTimeMillis();
        Long lastAttack = lastAttackTime.getOrDefault(frenzyKey, 0L);
        if (now - lastAttack < ATTACK_COOLDOWN_MS) {
            return Map.of("hit", false, "reason", "cooldown",
                    "cooldownRemainingMs", ATTACK_COOLDOWN_MS - (now - lastAttack));
        }
        lastAttackTime.put(frenzyKey, now);

        // 2. Ammo check for gun attacks — consume a bullet before resolving
        PlayerAmmoEntity ammo = null;
        if (!isMelee) {
            try {
                ammo = ammoService.getAmmo(playerId, worldId);
                if (ammo.getCurrentClip() <= 0) {
                    return Map.of("hit", false, "reason", "no_ammo",
                            "currentClip", ammo.getCurrentClip(),
                            "totalAmmoReserve", ammo.getTotalAmmoReserve());
                }
                ammo = ammoService.consumeBullet(playerId, worldId);
                log.debug("[Combat] Ammo consumed: playerId={} clip={}/{}", playerId,
                        ammo.getCurrentClip(), ammo.getMaxClipSize());
            } catch (GameException e) {
                return Map.of("hit", false, "reason", "ammo_error",
                        "message", e.getMessage());
            }
        }

        // 3. Get player state (for damage and facing direction)
        PlayerWorldStateEntity playerState = stateRepository
                .findByPlayerIdAndWorldId(playerId, worldId)
                .orElseThrow(() -> GameException.notFound("PLAYER_STATE_NOT_FOUND",
                        "No state found for player " + playerId + " in world " + worldId));

        // 4. Find alive enemies in the world
        List<EnemyInstanceEntity> aliveEnemies = enemyInstanceRepository
                .findByWorldIdAndIsAlive(worldId, true);

        // 5. Select target based on attack type
        EnemyInstanceEntity bestTarget = null;
        float bestDistance = Float.MAX_VALUE;

        for (EnemyInstanceEntity enemy : aliveEnemies) {
            float dx = enemy.getPositionX() - attackPointX;
            float dy = enemy.getPositionY() - attackPointY;
            float distance = (float) Math.sqrt(dx * dx + dy * dy);

            if (distance > weaponRange) continue;

            if (isMelee) {
                // Melee: proximity-only — any enemy within melee range, regardless of facing
                if (distance < bestDistance) {
                    bestDistance = distance;
                    bestTarget = enemy;
                }
            } else {
                // Gun: dot-product check — enemy must be in front of the player
                float dirToEnemy = Math.signum(dx);
                if (playerState.getFacingDirection() != 0
                        && Math.signum(dirToEnemy) != Math.signum(playerState.getFacingDirection())) {
                    continue; // Enemy behind the player — skip
                }
                if (distance < bestDistance) {
                    bestDistance = distance;
                    bestTarget = enemy;
                }
            }
        }

        if (bestTarget == null) {
            return Map.of("hit", false, "reason", "no_target",
                    "enemiesInRange", aliveEnemies.size(),
                    "actionType", isMelee ? "MELEE" : "ATTACK");
        }

        // 6. Calculate damage
        int totalDamage;
        int currentFrenzyBonus = 0;

        if (isMelee) {
            // Melee: fixed damage, no frenzy scaling
            totalDamage = meleeDamage;
        } else {
            // Gun: base damage + frenzy bonus
            int baseDamage = (int) playerState.getDamage();
            currentFrenzyBonus = frenzyBonus.getOrDefault(frenzyKey, 0);

            // Check frenzy expiry
            Long maxSince = frenzyMaxActiveSince.get(frenzyKey);
            if (maxSince != null && currentFrenzyBonus >= FRENZY_MAX_BONUS
                    && (now - maxSince) > FRENZY_DURATION_MS) {
                currentFrenzyBonus = 0;
                frenzyBonus.put(frenzyKey, 0);
                frenzyMaxActiveSince.remove(frenzyKey);
                log.debug("[Combat] Frenzy expired for playerId={} — reset to base damage", playerId);
            }

            totalDamage = baseDamage + currentFrenzyBonus;
        }

        // 7. Apply damage to enemy
        int newHealth = bestTarget.getCurrentHealth() - totalDamage;
        bestTarget.setCurrentHealth(newHealth);

        boolean enemyDied = newHealth <= 0;
        if (enemyDied) {
            bestTarget.setCurrentHealth(0);
            bestTarget.setAlive(false);
        }
        enemyInstanceRepository.save(bestTarget);

        // 8. Advance frenzy state (gun only)
        if (!isMelee && currentFrenzyBonus < FRENZY_MAX_BONUS) {
            currentFrenzyBonus++;
            frenzyBonus.put(frenzyKey, currentFrenzyBonus);
            if (currentFrenzyBonus >= FRENZY_MAX_BONUS) {
                frenzyMaxActiveSince.put(frenzyKey, now);
                log.debug("[Combat] Frenzy at MAX for playerId={} — countdown started", playerId);
            }
        }

        // 9. Handle kill consequences
        final EnemyInstanceEntity killedTarget = bestTarget;
        if (enemyDied) {
            enemyTypeRepository.findById(killedTarget.getTypeId()).ifPresent(type -> {
                experienceService.addExperience(playerId, worldId, type.getExpReward());
            });

            boolean isBoss = bossEncounterRepository.findByWorldId(worldId)
                    .map(boss -> boss.getBossEnemyId() != null
                            && boss.getBossEnemyId().equals(killedTarget.getEnemyId()))
                    .orElse(false);

            questService.recordEnemyKilled(worldId, isBoss);

            log.info("[Combat] Enemy died: enemyId={} typeId={} isBoss={}",
                    killedTarget.getEnemyId(), killedTarget.getTypeId(), isBoss);
        }

        Map<String, Object> result = new java.util.LinkedHashMap<>();
        result.put("hit", true);
        result.put("targetEnemyId", bestTarget.getEnemyId());
        result.put("targetTypeId", bestTarget.getTypeId());
        result.put("damageDealt", totalDamage);
        result.put("enemyRemainingHealth", bestTarget.getCurrentHealth());
        result.put("enemyDied", enemyDied);
        result.put("actionType", isMelee ? "MELEE" : "ATTACK");

        if (isMelee) {
            // Knockback data for melee hits that don't kill
            if (!enemyDied) {
                float knockbackDirX = playerState.getFacingDirection();
                result.put("knockback", Map.of(
                        "directionX", knockbackDirX,
                        "directionY", 0.0f,
                        "force", 10.0f,
                        "duration", 0.2f
                ));
            }
        } else {
            result.put("frenzyDamage", currentFrenzyBonus);
            result.put("frenzyMaxed", currentFrenzyBonus >= FRENZY_MAX_BONUS);
            // Include ammo state so the client stays in sync
            if (ammo != null) {
                result.put("currentClip", ammo.getCurrentClip());
                result.put("totalAmmoReserve", ammo.getTotalAmmoReserve());
                result.put("maxClipSize", ammo.getMaxClipSize());
            }
        }

        return result;
    }

    @Override
    public Map<String, Object> getFrenzyState(Long playerId, String worldId) {
        String key = playerId + ":" + worldId;
        int bonus = frenzyBonus.getOrDefault(key, 0);
        Long maxSince = frenzyMaxActiveSince.get(key);
        long now = System.currentTimeMillis();

        boolean frenzyActive = bonus > 0;
        if (maxSince != null && bonus >= FRENZY_MAX_BONUS && (now - maxSince) > FRENZY_DURATION_MS) {
            frenzyActive = false;
            frenzyBonus.remove(key);
            frenzyMaxActiveSince.remove(key);
        }

        PlayerWorldStateEntity state = stateRepository
                .findByPlayerIdAndWorldId(playerId, worldId)
                .orElse(null);
        int baseDamage = state != null ? (int) state.getDamage() : 1;

        return Map.of(
                "frenzyActive", frenzyActive,
                "currentDamage", baseDamage + bonus,
                "baseDamage", baseDamage,
                "maxDamage", baseDamage + FRENZY_MAX_BONUS,
                "frenzyBonus", bonus
        );
    }

    @Override
    public Map<String, Object> reload(Long playerId, String worldId) {
        PlayerAmmoEntity ammo = ammoService.reload(playerId, worldId);
        log.info("[Combat] Reload: playerId={} clip={}/{} reserve={}",
                playerId, ammo.getCurrentClip(), ammo.getMaxClipSize(), ammo.getTotalAmmoReserve());

        return Map.of(
                "currentClip", ammo.getCurrentClip(),
                "maxClipSize", ammo.getMaxClipSize(),
                "totalAmmoReserve", ammo.getTotalAmmoReserve(),
                "bulletsLoaded", ammo.getCurrentClip()
        );
    }

    @Override
    public Map<String, Object> getAmmo(Long playerId, String worldId) {
        PlayerAmmoEntity ammo = ammoService.getAmmo(playerId, worldId);
        return Map.of(
                "currentClip", ammo.getCurrentClip(),
                "maxClipSize", ammo.getMaxClipSize(),
                "totalAmmoReserve", ammo.getTotalAmmoReserve()
        );
    }
}
