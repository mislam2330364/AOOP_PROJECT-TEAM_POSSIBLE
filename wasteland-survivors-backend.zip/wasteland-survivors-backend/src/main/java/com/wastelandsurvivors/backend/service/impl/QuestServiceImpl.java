package com.wastelandsurvivors.backend.service.impl;

import com.wastelandsurvivors.backend.entity.QuestEntity;
import com.wastelandsurvivors.backend.exception.GameException;
import com.wastelandsurvivors.backend.repository.QuestRepository;
import com.wastelandsurvivors.backend.service.QuestService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Full implementation of {@link QuestService} with multi-quest support.
 *
 * <p>Each world can now have multiple quests discriminated by questId.
 * The original "sara_village" quest retains its zombie/boss objective tracking.
 * Quest2 (and future quests) use the objectivesJson field for flexible objectives.</p>
 *
 * <p>State machine validation — every transition is checked against the rules
 * from SimpleQuestManager.cs and Quest2Manager.cs:
 * <ul>
 *   <li>activateQuest:  0 → 1 only</li>
 *   <li>recordEnemyKilled: only in state 1</li>
 *   <li>1 → 2 automatic when objectives are complete</li>
 *   <li>handInQuest: 2 → 3 only</li>
 * </ul></p>
 */
@Service
@Slf4j
public class QuestServiceImpl implements QuestService {

    private final QuestRepository questRepository;

    public QuestServiceImpl(QuestRepository questRepository) {
        this.questRepository = questRepository;
    }

    @Override
    public QuestEntity getQuestState(String worldId, String questId) {
        return questRepository.findByWorldIdAndQuestId(worldId, questId)
                .orElseGet(() -> {
                    QuestEntity defaults = QuestEntity.builder()
                            .worldId(worldId)
                            .questId(questId)
                            .build();
                    log.info("[Quest] Auto-created questId={} for worldId={}", questId, worldId);
                    return questRepository.save(defaults);
                });
    }

    @Override
    public QuestEntity activateQuest(String worldId, String questId) {
        QuestEntity quest = getOrCreate(worldId, questId);

        if (quest.getQuestState() != 0) {
            throw GameException.badRequest("QUEST_ALREADY_ACTIVE",
                    "Quest " + questId + " is already in state " + quest.getQuestState()
                    + " — can only activate from state 0 (Not Started)");
        }

        quest.setQuestState(1);

        // Reset objectives for Sara quest
        if ("sara_village".equals(questId)) {
            quest.setZombiesRemaining(12);
            quest.setBossAlive(true);
        }
        // Quest2 objectives are tracked in objectivesJson — reset as needed

        questRepository.save(quest);

        log.info("[Quest] Activated questId={} for worldId={} — state=1", questId, worldId);
        return quest;
    }

    @Override
    public QuestEntity recordEnemyKilled(String worldId, String questId, boolean isBoss) {
        QuestEntity quest = getOrCreate(worldId, questId);

        if (quest.getQuestState() != 1) {
            log.debug("[Quest] Kill ignored for worldId={} questId={} — state is {}, not 1 (Active)",
                    worldId, questId, quest.getQuestState());
            return quest;
        }

        if ("sara_village".equals(questId)) {
            // Sara quest: track zombies + boss
            if (isBoss) {
                quest.setBossAlive(false);
                log.info("[Quest] Boss killed in worldId={} questId={}", worldId, questId);
            } else {
                int remaining = Math.max(0, quest.getZombiesRemaining() - 1);
                quest.setZombiesRemaining(remaining);
                log.info("[Quest] Zombie killed in worldId={} questId={} — remaining={}", worldId, questId, remaining);
            }

            // Auto-transition when both objectives complete
            if (quest.getZombiesRemaining() <= 0 && !quest.isBossAlive()) {
                quest.setQuestState(2);
                log.info("[Quest] All objectives complete for worldId={} questId={} — state=2", worldId, questId);
            }
        } else {
            // Quest2 (and future quests): delegate to objectivesJson-based logic
            log.info("[Quest] Enemy kill recorded for worldId={} questId={} — isBoss={} (objectivesJson-based)",
                    worldId, questId, isBoss);
            // TODO: Parse objectivesJson and update counters when Quest2 schema is defined
        }

        questRepository.save(quest);
        return quest;
    }

    @Override
    public QuestEntity handInQuest(String worldId, String questId) {
        QuestEntity quest = getOrCreate(worldId, questId);

        if (quest.getQuestState() != 2) {
            throw GameException.badRequest("QUEST_NOT_COMPLETE",
                    "Quest " + questId + " is in state " + quest.getQuestState()
                    + " — can only hand in from state 2 (Objectives Complete)");
        }

        quest.setQuestState(3);
        questRepository.save(quest);

        log.info("[Quest] Handed in questId={} for worldId={} — state=3 (Handed In)", questId, worldId);
        return quest;
    }

    private QuestEntity getOrCreate(String worldId, String questId) {
        return questRepository.findByWorldIdAndQuestId(worldId, questId)
                .orElseGet(() -> questRepository.save(QuestEntity.builder()
                        .worldId(worldId)
                        .questId(questId)
                        .build()));
    }
}
