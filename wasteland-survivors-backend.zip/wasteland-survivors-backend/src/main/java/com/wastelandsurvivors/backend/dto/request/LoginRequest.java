package com.wastelandsurvivors.backend.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Sent by Unity to the /api/v1/auth/login endpoint when the player enters their credentials on the login screen.
 * Contains plain text password — the server hashes and compares it. (Unity to server)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoginRequest {

    // The player's unique username — must not be empty
    @NotBlank(message = "Username is required")
    private String username;

    // The player's password in plain text — only ever transmitted over HTTPS in production
    @NotBlank(message = "Password is required")
    private String password;
}

