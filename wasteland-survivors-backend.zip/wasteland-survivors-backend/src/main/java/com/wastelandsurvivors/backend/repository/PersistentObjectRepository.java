package com.wastelandsurvivors.backend.repository;

import com.wastelandsurvivors.backend.entity.PersistentObjectEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data JPA repository for {@link PersistentObjectEntity} (persistent_objects table).
 */
public interface PersistentObjectRepository extends JpaRepository<PersistentObjectEntity, Long> {

    /**
     * Returns all destroyed object records for a world.
     */
    List<PersistentObjectEntity> findByWorldId(String worldId);

    /**
     * Checks if a specific object has been destroyed in a world.
     */
    Optional<PersistentObjectEntity> findByWorldIdAndObjectUniqueId(String worldId, String objectUniqueId);

    /**
     * Returns true if at least one record exists for this world+object combo.
     */
    boolean existsByWorldIdAndObjectUniqueId(String worldId, String objectUniqueId);

    /**
     * Deletes ALL destroyed object records for a world.
     * Used by GameSaveServiceImpl.saveDestroyedObjects() to replace the entire
     * destroyed-object set on each save (instead of the old append-only behavior).
     *
     * Uses explicit @Query instead of derived method name for maximum compatibility
     * across Spring Data JPA versions.
     */
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Transactional
    @org.springframework.data.jpa.repository.Query("DELETE FROM PersistentObjectEntity p WHERE p.worldId = :worldId")
    void deleteAllByWorldId(@org.springframework.data.repository.query.Param("worldId") String worldId);
}
