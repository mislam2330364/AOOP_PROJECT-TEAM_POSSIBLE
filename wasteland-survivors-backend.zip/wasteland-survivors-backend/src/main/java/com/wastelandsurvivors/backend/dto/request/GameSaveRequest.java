package com.wastelandsurvivors.backend.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Unified game-save payload sent by Unity when the player presses "Save Game"
 * from the pause menu (MenuController.OnSaveButtonPressed).
 *
 * <p>This DTO aggregates all player state that should persist across sessions:
 * health/position/stats (player_world_state), EXP/level (player_progression),
 * ammo (player_ammo), quest progress, boss encounter state, and destroyed objects.</p>
 *
 * <h3>Unity source mapping</h3>
 * <pre>
 * MenuController.OnSaveButtonPressed()
 *   → builds GameSaveRequest JSON
 *   → POST /api/v1/gamesave/save
 * </pre>
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GameSaveRequest {

    /** Schema version — allows the backend to reject or migrate incompatible save formats. */
    private int schemaVersion = 1;

    /** The player's database ID — from PlayerPrefs.GetInt("PlayerId") */
    private Long playerId;

    /** The world ID the player is currently in */
    private String worldId;

    // -- Player World State --
    private Integer currentHealth;
    private Integer maxHealth;
    private Float damage;
    private Float weaponRange;
    private Float speed;
    private Float positionX;
    private Float positionY;
    private Integer facingDirection;
    private String currentScene;

    // -- Player Progression --
    private Long experience;
    private Integer level;
    private Long expToLevel;
    private Float expGrowthMultiplier;

    // -- Ammo --
    private Integer currentClip;
    private Integer maxClipSize;
    private Integer totalAmmoReserve;

    // -- Quest --
    private Integer questState;
    private Integer zombiesRemaining;
    private Boolean isBossAlive;
    private Boolean isElectricityFixed;

    // -- Quest2 --
    private Boolean quest2Started;
    private Integer quest2EnemiesRemaining;

    // -- Boss Encounter --
    @com.fasterxml.jackson.annotation.JsonProperty("fightStarted")
    private Boolean fightStarted;
    @com.fasterxml.jackson.annotation.JsonProperty("isDefeated")
    private Boolean isDefeated;
    @com.fasterxml.jackson.annotation.JsonProperty("currentPhase")
    private Integer currentPhase;
    @com.fasterxml.jackson.annotation.JsonProperty("phase2Activated")
    private Boolean phase2Activated;

    // -- Inventory --
    /** JSON-serialized inventory items array (List<SlotData>) */
    private String inventoryJson;

    // -- Persistence --
    /** List of unique IDs for objects that have been destroyed/collected */
    private List<String> destroyedObjectIds;
}