package com.wastelandsurvivors.backend.dto.game;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Carries the details of an enemy combat action during a multiplayer session.
 * Sent over WebSocket by the host client, wrapped inside a WebSocketMessage. (Both directions)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EnemyActionDTO {

    // Server-assigned enemy ID — unique within the session
    private long enemyId;

    // Which multiplayer session this action belongs to
    private String sessionId;

    // The damage value of this attack
    private int damage;

    // The radius of the attack hitbox (bitRange in Enemy_combat.cs)
    private float attackRange;

    // X coordinate of the attack origin point
    private float attackPointX;

    // Y coordinate of the attack origin point
    private float attackPointY;

    // Unix time in milliseconds when this was captured in Unity
    private long timestamp;
}
