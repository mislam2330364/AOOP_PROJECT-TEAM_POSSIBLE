package com.wastelandsurvivors.backend.service;

import com.wastelandsurvivors.backend.dto.request.GameSaveRequest;
import com.wastelandsurvivors.backend.dto.response.GameSaveResponse;

/**
 * Unified game save/load — aggregates all player state across multiple tables
 * into a single save or load operation.
 *
 * <p>This exists because MenuController in Unity has a single "Save Game" and
 * "Load Game" button. Making 6+ separate REST calls from Unity for each subsystem
 * (stats, EXP, ammo, quest, boss, persistence) would be fragile and slow.
 * Instead, one call bundles everything.</p>
 *
 * <p>Internally, this service delegates to the individual repositories for each
 * subsystem. It does NOT duplicate any persistence logic — it only coordinates
 * across the existing per-table repositories.</p>
 */
public interface GameSaveService {

    /**
     * Saves ALL player state for a world in one atomic operation.
     * Delegates to individual repositories (playerWorldState, playerProgression,
     * playerAmmo, quest, bossEncounter, persistentObject).
     *
     * @param request Aggregated save payload from Unity
     * @return Confirmation message
     */
    GameSaveResponse save(GameSaveRequest request);

    /**
     * Loads ALL player state for a world and returns it as a single response.
     * Queries all subsystem tables and assembles a complete GameSaveResponse.
     *
     * @param playerId The player whose state to load
     * @param worldId  The world whose state to load
     * @return Full aggregated game state, or a response with empty sections if no save exists yet
     */
    GameSaveResponse load(Long playerId, String worldId);
}