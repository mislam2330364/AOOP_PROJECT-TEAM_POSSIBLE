package com.wastelandsurvivors.backend.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Returned by POST /api/v1/friends/invite — contains the join code for the
 * player to share with their friend.
 * (Server to Unity)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InviteCodeResponse {

    /** The 6-character code the player shares with their friend */
    private String inviteCode;

    /** The session ID created for this invite */
    private String sessionId;

    /** Human-readable confirmation message */
    private String message;
}
