package com.wastelandsurvivors.backend.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Returned by all /api/v1/lobby endpoints.
 * Unity polls the status field every 2 seconds on the lobby waiting screen.
 * When status changes to ACTIVE (AppConstants.STATUS_ACTIVE), Unity loads the multiplayer world.
 * (Server to Unity)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LobbyResponse {

    // The unique ID for this multiplayer session — stored in GameAPI.cs and included in all WebSocket messages
    private String sessionId;

    // The 6-character code displayed to the owner so they can share it with the guest. Null if a guest is viewing this response.
    private String joinKey;

    // Current session state — one of: WAITING, ACTIVE, CLOSED. Always use AppConstants constants, never raw strings.
    private String status;

    // Database ID of the world owner
    private Long ownerId;

    // Database ID of the guest player. Null until the guest has joined.
    private Long guestId;

    // The world ID this session belongs to — from SessionEntity.worldId
    private String worldId;

    // The host's current Unity scene name — from SessionEntity.hostCurrentScene.
    // Used by the guest's PollForSessionStart fallback so the guest always loads
    // the SAME scene the host is in, even if the WebSocket SESSION_READY is delayed.
    private String hostScene;
}

