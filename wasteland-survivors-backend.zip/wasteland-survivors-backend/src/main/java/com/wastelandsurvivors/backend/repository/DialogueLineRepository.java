package com.wastelandsurvivors.backend.repository;

import com.wastelandsurvivors.backend.entity.DialogueLineEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Spring Data JPA repository for {@link DialogueLineEntity} (dialogue_lines table).
 */
public interface DialogueLineRepository extends JpaRepository<DialogueLineEntity, Long> {

    /**
     * Returns all lines for a dialogue tree, ordered by line_index (0 = first).
     */
    List<DialogueLineEntity> findByDialogueIdOrderByLineIndexAsc(String dialogueId);
}
