package com.wastelandsurvivors.backend.controller;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.entity.PlayerEntity;
import com.wastelandsurvivors.backend.entity.PlayerWorldStateEntity;
import com.wastelandsurvivors.backend.exception.GameException;
import com.wastelandsurvivors.backend.repository.PlayerRepository;
import com.wastelandsurvivors.backend.service.PlayerStatsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * REST Controller for player stats per world.
 * Server is authoritative — Unity sends updates, server validates and persists.
 */
@RestController
@RequestMapping(AppConstants.API_V1 + "/players")
@Slf4j
public class PlayerStatsController {

    private final PlayerStatsService playerStatsService;
    private final PlayerRepository playerRepository;

    public PlayerStatsController(PlayerStatsService playerStatsService,
                                  PlayerRepository playerRepository) {
        this.playerStatsService = playerStatsService;
        this.playerRepository = playerRepository;
    }

    /**
     * Returns all player stats for a given world.
     * GET /api/v1/players/{playerId}/stats?worldId=...
     */
    @GetMapping("/{playerId}/stats")
    public ResponseEntity<?> getStats(@PathVariable Long playerId,
                                      @RequestParam String worldId) {
        log.debug("[PlayerStatsController] GET /{}/stats?worldId={}", playerId, worldId);
        return ResponseEntity.ok(playerStatsService.getStats(playerId, worldId));
    }

    /**
     * Updates player stats for a world. Creates the state row if it doesn't exist.
     * POST /api/v1/players/{playerId}/stats/update?worldId=...
     */
    @PostMapping("/{playerId}/stats/update")
    public ResponseEntity<?> updateStats(@PathVariable Long playerId,
                                         @RequestParam String worldId,
                                         @RequestBody PlayerWorldStateEntity stats) {
        log.debug("[PlayerStatsController] POST /{}/stats/update?worldId={}", playerId, worldId);
        stats.setPlayerId(playerId);
        stats.setWorldId(worldId);
        return ResponseEntity.ok(playerStatsService.updateStats(playerId, worldId, stats));
    }

    // -- Intro Cutscene Tracking --

    /**
     * Returns whether the player has already seen the intro cutscene.
     * GET /api/v1/players/{playerId}/intro-played
     */
    @GetMapping("/{playerId}/intro-played")
    public ResponseEntity<?> hasPlayedIntro(@PathVariable Long playerId) {
        PlayerEntity player = playerRepository.findById(playerId)
                .orElseThrow(() -> GameException.notFound("PLAYER_NOT_FOUND",
                        "Player " + playerId + " does not exist"));
        return ResponseEntity.ok(Map.of(
                "playerId", playerId,
                "hasPlayedIntro", player.isHasPlayedIntro()
        ));
    }

    /**
     * Marks the intro cutscene as played for this player.
     * Once set, the IntroDialogueTrigger script self-destructs on future scene loads.
     * POST /api/v1/players/{playerId}/intro-played
     */
    @PostMapping("/{playerId}/intro-played")
    public ResponseEntity<?> markIntroPlayed(@PathVariable Long playerId) {
        PlayerEntity player = playerRepository.findById(playerId)
                .orElseThrow(() -> GameException.notFound("PLAYER_NOT_FOUND",
                        "Player " + playerId + " does not exist"));

        if (player.isHasPlayedIntro()) {
            log.debug("[PlayerStatsController] Intro already played for playerId={} — no-op", playerId);
        } else {
            player.setHasPlayedIntro(true);
            playerRepository.save(player);
            log.info("[PlayerStatsController] Intro marked as played for playerId={}", playerId);
        }

        return ResponseEntity.ok(Map.of(
                "playerId", playerId,
                "hasPlayedIntro", true,
                "message", "Intro marked as played"
        ));
    }
}
