package com.wastelandsurvivors.backend.websocket;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.dto.game.WebSocketMessage;
import com.wastelandsurvivors.backend.service.LobbyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;

/**
 * PHASE 7: Listens for STOMP WebSocket disconnect events and broadcasts
 * PLAYER_DISCONNECTED to the remaining player in the session.
 *
 * <p>When a Unity client's WebSocket connection drops:
 * <ol>
 *   <li>{@link SessionDisconnectEvent} fires</li>
 *   <li>This listener extracts the STOMP session ID</li>
 *   <li>It looks up the game session ID from {@link SessionSubscriptionInterceptor}</li>
 *   <li>It broadcasts a PLAYER_DISCONNECTED message to /topic/session/{gameSessionId}</li>
 *   <li>It calls {@link LobbyService#closeSession(String)} to close the game session</li>
 * </ol>
 *
 * <p>The remaining player's Unity client receives PLAYER_DISCONNECTED and
 * MultiplayerManager.HandleRemotePlayerDisconnect() cleans up the partner clone.</p>
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class WebSocketSessionLifecycleListener {

    private final SessionSubscriptionInterceptor sessionInterceptor;
    private final SimpMessagingTemplate messagingTemplate;
    private final LobbyService lobbyService;

    /**
     * Handles STOMP WebSocket disconnect events.
     * Fires when a Unity client's underlying WebSocket closes (intentionally or
     * due to network loss, crash, or application close).
     */
    @EventListener
    public void handleSessionDisconnect(SessionDisconnectEvent event) {
        StompHeaderAccessor accessor = StompHeaderAccessor.wrap(event.getMessage());
        String stompSessionId = accessor.getSessionId();

        if (stompSessionId == null) {
            log.warn("[LifecycleListener] Disconnect event with null STOMP session ID — ignoring");
            return;
        }

        // Look up the game session ID from our interceptor's mapping
        String gameSessionId = sessionInterceptor.removeGameSessionMapping(stompSessionId);
        if (gameSessionId == null) {
            log.debug("[LifecycleListener] STOMP session {} disconnected but no game session mapping found " +
                      "(may not have been a game client)", stompSessionId);
            return;
        }

        log.info("[LifecycleListener] STOMP session {} disconnected → game session {} — " +
                 "broadcasting PLAYER_DISCONNECTED and closing session",
                 stompSessionId, gameSessionId);

        try {
            // Broadcast PLAYER_DISCONNECTED to the remaining player(s) in the session
            WebSocketMessage disconnectMsg = WebSocketMessage.builder()
                    .type(AppConstants.MSG_PLAYER_DISCONNECTED)
                    .sessionId(gameSessionId)
                    .senderId(0) // 0 = server
                    .payload("")
                    .timestamp(System.currentTimeMillis())
                    .build();

            String topic = AppConstants.WS_TOPIC_SESSION + gameSessionId;
            messagingTemplate.convertAndSend(topic, disconnectMsg);
            log.info("[LifecycleListener] Broadcast PLAYER_DISCONNECTED to {}", topic);

            // Close the game session
            lobbyService.closeSession(gameSessionId);
            log.info("[LifecycleListener] Game session {} closed", gameSessionId);

            // Clean up player mapping
            sessionInterceptor.removePlayerMapping(gameSessionId);

        } catch (Exception e) {
            log.error("[LifecycleListener] Failed to handle disconnect for game session {}: {}",
                    gameSessionId, e.getMessage(), e);
        }
    }
}
