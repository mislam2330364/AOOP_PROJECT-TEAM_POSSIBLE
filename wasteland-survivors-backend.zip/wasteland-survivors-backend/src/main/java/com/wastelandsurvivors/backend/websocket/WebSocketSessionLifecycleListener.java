package com.wastelandsurvivors.backend.websocket;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.dto.game.WebSocketMessage;
import com.wastelandsurvivors.backend.dto.response.LobbyResponse;
import com.wastelandsurvivors.backend.service.LobbyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;
import org.springframework.web.socket.messaging.SessionSubscribeEvent;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks STOMP session → game session mapping and handles deterministic
 * multiplayer teardown when a websocket disconnect is detected.
 *
 * <h3>Phase 6 changes</h3>
 * <ul>
 *   <li>No longer auto-closes the session on disconnect — only broadcasts
 *       PLAYER_DISCONNECTED to the remaining player.</li>
 *   <li>Session closure is now the responsibility of explicit HOST_DIED
 *       messages (handled by GameSocketHandler) or session-timeout cleanup.</li>
 *   <li>This allows guest rejoin after accidental disconnect while keeping
 *       the session ACTIVE for the host.</li>
 *   <li>Tracks the connected simpSession count per game session so we know
 *       when both players have disconnected.</li>
 * </ul>
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class WebSocketSessionLifecycleListener {

    private final LobbyService lobbyService;
    private final SimpMessagingTemplate messagingTemplate;

    /** Maps STOMP simpSessionId → game sessionId. */
    private final Map<String, String> simpSessionToGameSession = new ConcurrentHashMap<>();

    /** Tracks connected simpSessionIds per game session. */
    private final Map<String, Set<String>> gameSessionConnections = new ConcurrentHashMap<>();

    @EventListener
    public void onSubscribe(SessionSubscribeEvent event) {
        SimpMessageHeaderAccessor sha = SimpMessageHeaderAccessor.wrap(event.getMessage());
        String destination = sha.getDestination();
        String simpSessionId = sha.getSessionId();

        if (destination == null || simpSessionId == null) return;
        if (!destination.startsWith(AppConstants.WS_TOPIC_SESSION)) return;

        String gameSessionId = destination.substring(AppConstants.WS_TOPIC_SESSION.length());
        if (gameSessionId.isBlank()) return;

        simpSessionToGameSession.put(simpSessionId, gameSessionId);
        gameSessionConnections
                .computeIfAbsent(gameSessionId, k -> ConcurrentHashMap.newKeySet())
                .add(simpSessionId);

        log.info("[WebSocketLifecycle] Bound simpSession={} -> gameSession={} (connections: {})",
                simpSessionId, gameSessionId,
                gameSessionConnections.getOrDefault(gameSessionId, Set.of()).size());
    }

    @EventListener
    public void onDisconnect(SessionDisconnectEvent event) {
        String simpSessionId = event.getSessionId();

        String gameSessionId = simpSessionToGameSession.remove(simpSessionId);
        if (gameSessionId == null || gameSessionId.isBlank()) return;

        // Remove this simpSession from the connection set
        Set<String> connections = gameSessionConnections.get(gameSessionId);
        if (connections != null) {
            connections.remove(simpSessionId);
            if (connections.isEmpty()) {
                gameSessionConnections.remove(gameSessionId);
            }
        }

        try {
            LobbyResponse status = lobbyService.getSessionStatus(gameSessionId);
            if (status == null || AppConstants.STATUS_CLOSED.equals(status.getStatus())) {
                log.info("[WebSocketLifecycle] Session {} already CLOSED — skipping disconnect broadcast",
                        gameSessionId);
                return;
            }

            // Phase 6: Broadcast PLAYER_DISCONNECTED so the remaining player
            // can clean up their opponent clone.  Do NOT close the session —
            // the disconnected player may reconnect (guest) or the host may
            // send HOST_DIED explicitly.
            WebSocketMessage msg = WebSocketMessage.builder()
                    .type(AppConstants.MSG_PLAYER_DISCONNECTED)
                    .sessionId(gameSessionId)
                    .senderId(0L)
                    .payload("disconnect")
                    .timestamp(System.currentTimeMillis())
                    .build();

            messagingTemplate.convertAndSend(AppConstants.WS_TOPIC_SESSION + gameSessionId, msg);

            int remaining = (connections != null) ? connections.size() : 0;
            log.info("[WebSocketLifecycle] Disconnect broadcast for session={} (simpSession={}). " +
                     "{} connection(s) remaining. Session stays ACTIVE for rejoin/timeout.",
                    gameSessionId, simpSessionId, remaining);

            // Phase 6: If NO connections remain (both players gone), close the
            // session — nobody is coming back.  This prevents orphan ACTIVE
            // sessions when both players crash/quit simultaneously.
            if (remaining == 0) {
                lobbyService.closeSession(gameSessionId);
                log.info("[WebSocketLifecycle] Session {} auto-closed — no remaining connections.",
                        gameSessionId);
            }
        } catch (Exception e) {
            log.warn("[WebSocketLifecycle] Disconnect handling failed for simpSession={} gameSession={}: {}",
                    simpSessionId, gameSessionId, e.getMessage());
        }
    }
}
