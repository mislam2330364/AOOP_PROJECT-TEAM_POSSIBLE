package com.wastelandsurvivors.backend.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Aggregated game state returned to Unity when the player presses "Load Game"
 * from the pause menu (MenuController.OnLoadButtonPressed).
 *
 * <p>This is the FULL restore payload — everything Unity needs to reconstruct
 * the player's state in the world. Unity parses this and applies each section
 * to the corresponding game system (StatsManager, ExpManager, InventoryManager, etc.).</p>
 *
 * <h3>Unity consumer</h3>
 * <pre>
 * MenuController.OnLoadButtonPressed()
 *   → GET /api/v1/gamesave/load/{playerId}?worldId=...
 *   → parses GameSaveResponse JSON
 *   → applies each section to the appropriate manager
 * </pre>
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GameSaveResponse {

    private int schemaVersion;
    private Long playerId;
    private String worldId;
    private String message;
    private String dataHash;

    private PlayerState playerState;
    private Progression progression;
    private AmmoState ammo;
    private QuestState quest;
    private Quest2State quest2;
    private BossState boss;
    private String inventoryJson;
    private List<String> destroyedObjectIds;

    // -- Nested state objects -------------------------------------------------

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class PlayerState {
        private int currentHealth;
        private int maxHealth;
        private float damage;
        private float weaponRange;
        private float speed;
        private float positionX;
        private float positionY;
        private int facingDirection;
        private String currentScene;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Progression {
        private long experience;
        private int level;
        private long expToLevel;
        private float expGrowthMultiplier;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class AmmoState {
        private int currentClip;
        private int maxClipSize;
        private int totalAmmoReserve;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class QuestState {
        @com.fasterxml.jackson.annotation.JsonProperty("questState")
        private int questState;
        @com.fasterxml.jackson.annotation.JsonProperty("zombiesRemaining")
        private int zombiesRemaining;
        @com.fasterxml.jackson.annotation.JsonProperty("isBossAlive")
        private boolean isBossAlive;
        @com.fasterxml.jackson.annotation.JsonProperty("isElectricityFixed")
        private boolean isElectricityFixed;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Quest2State {
        private boolean quest2Started;
        private int quest2EnemiesRemaining;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BossState {
        @com.fasterxml.jackson.annotation.JsonProperty("fightStarted")
        private boolean fightStarted;
        @com.fasterxml.jackson.annotation.JsonProperty("isDefeated")
        private boolean isDefeated;
        @com.fasterxml.jackson.annotation.JsonProperty("currentPhase")
        private int currentPhase;
        @com.fasterxml.jackson.annotation.JsonProperty("phase2Activated")
        private boolean phase2Activated;
    }
}