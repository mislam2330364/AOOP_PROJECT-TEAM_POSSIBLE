package com.wastelandsurvivors.backend.repository;

import com.wastelandsurvivors.backend.entity.EnemyTypeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Spring Data JPA repository for {@link EnemyTypeEntity} (enemy_types table).
 */
public interface EnemyTypeRepository extends JpaRepository<EnemyTypeEntity, String> {
}
