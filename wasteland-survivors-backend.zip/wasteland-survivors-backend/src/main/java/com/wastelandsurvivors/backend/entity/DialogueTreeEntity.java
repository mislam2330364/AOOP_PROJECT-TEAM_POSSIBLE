package com.wastelandsurvivors.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Dialogue tree definition — persisted in {@code dialogue_trees}.
 * Each tree is a sequence of lines followed by branching options.
 * Can be filtered by NPC actor and quest state so the same NPC
 * says different things depending on game progress.
 *
 * <h3>Unity source mapping</h3>
 * <ul>
 *   <li>{@code dialogueId} → DialogueSO asset name</li>
 *   <li>{@code npcActorId} → which NPC owns this dialogue</li>
 *   <li>{@code questStateFilter} → which QuestState this dialogue is for (0/1/2/3)</li>
 * </ul>
 */
@Entity
@Table(name = "dialogue_trees")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DialogueTreeEntity {

    /**
     * Unique dialogue identifier, e.g. "SARA_INTRO", "SARA_WAITING", "SARA_COMPLETE".
     * Maps to: DialogueSO asset name
     */
    @Id
    @Column(name = "dialogue_id", nullable = false, length = 64)
    private String dialogueId;

    /**
     * Which NPC owns this dialogue. FK to npc_actors.actor_id.
     * NULL for system/narrator dialogues.
     */
    @Column(name = "npc_actor_id", length = 64)
    private String npcActorId;

    /**
     * If not NULL, this dialogue is only used when the quest state matches.
     * 0 = Not Started, 1 = Active, 2 = Objectives Complete, 3 = Handed In.
     * Maps to: NPC_Talk routes by SimpleQuestManager.QuestState
     */
    @Column(name = "quest_state_filter")
    private Integer questStateFilter;

    /**
     * Human-readable note for developers, e.g. "Sara intro dialogue before quest accepted".
     */
    @Column(length = 255)
    private String description;
}
