package com.wastelandsurvivors.backend.dto.game;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Carries a player's full inventory for saving and loading.
 * Sent via REST (not WebSocket) — POST to /api/v1/inventory/{playerId} to save, GET from
 * /api/v1/inventory/{playerId} to load. Inventory is not yet implemented in Unity. (Both directions)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InventoryDTO {

    // The player who owns this inventory — matches the playerId stored in GameAPI.cs
    private long playerId;

    // The world this inventory belongs to — inventory is per-world, not global
    private String worldId;

    // The list of item stacks. Empty list means the inventory is empty — never null.
    private List<InventoryItemDTO> items;
}

