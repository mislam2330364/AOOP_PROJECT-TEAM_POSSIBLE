package com.wastelandsurvivors.backend.service.impl;

import com.wastelandsurvivors.backend.dto.request.GameSaveRequest;
import com.wastelandsurvivors.backend.dto.response.GameSaveResponse;
import com.wastelandsurvivors.backend.entity.BossEncounterEntity;
import com.wastelandsurvivors.backend.entity.PersistentObjectEntity;
import com.wastelandsurvivors.backend.entity.PlayerAmmoEntity;
import com.wastelandsurvivors.backend.entity.PlayerProgressionEntity;
import com.wastelandsurvivors.backend.entity.PlayerWorldStateEntity;
import com.wastelandsurvivors.backend.entity.QuestEntity;
import com.wastelandsurvivors.backend.entity.InventoryEntity;
import com.wastelandsurvivors.backend.entity.InventoryItemEntity;
import com.wastelandsurvivors.backend.entity.WorldEntity;
import com.wastelandsurvivors.backend.exception.GameException;
import com.wastelandsurvivors.backend.repository.BossEncounterRepository;
import com.wastelandsurvivors.backend.repository.InventoryRepository;
import com.wastelandsurvivors.backend.repository.PersistentObjectRepository;
import com.wastelandsurvivors.backend.repository.PlayerAmmoRepository;
import com.wastelandsurvivors.backend.repository.PlayerProgressionRepository;
import com.wastelandsurvivors.backend.repository.PlayerRepository;
import com.wastelandsurvivors.backend.repository.PlayerWorldStateRepository;
import com.wastelandsurvivors.backend.repository.QuestRepository;
import com.wastelandsurvivors.backend.repository.WorldRepository;
import com.wastelandsurvivors.backend.service.GameSaveService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Full implementation of {@link GameSaveService} backed by JPA repositories.
 *
 * <p>Save and load are both transactional — if any part of a save fails,
 * the entire operation rolls back. This prevents partial-save corruption
 * where, for example, the player's health was saved but their EXP wasn't.</p>
 *
 * <p>Each subsystem uses its own repository. This class ONLY coordinates —
 * it never contains raw SQL, JDBC, or entity-manager calls. All persistence
 * logic lives in the repositories and JPA entities.</p>
 */
@Service
@Slf4j
public class GameSaveServiceImpl implements GameSaveService {

    private final PlayerRepository playerRepository;
    private final WorldRepository worldRepository;
    private final PlayerWorldStateRepository playerWorldStateRepository;
    private final PlayerProgressionRepository playerProgressionRepository;
    private final PlayerAmmoRepository playerAmmoRepository;
    private final QuestRepository questRepository;
    private final BossEncounterRepository bossEncounterRepository;
    private final PersistentObjectRepository persistentObjectRepository;
    private final InventoryRepository inventoryRepository;

    public GameSaveServiceImpl(PlayerRepository playerRepository,
                               WorldRepository worldRepository,
                               PlayerWorldStateRepository playerWorldStateRepository,
                               PlayerProgressionRepository playerProgressionRepository,
                               PlayerAmmoRepository playerAmmoRepository,
                               QuestRepository questRepository,
                               BossEncounterRepository bossEncounterRepository,
                               PersistentObjectRepository persistentObjectRepository,
                               InventoryRepository inventoryRepository) {
        this.playerRepository = playerRepository;
        this.worldRepository = worldRepository;
        this.playerWorldStateRepository = playerWorldStateRepository;
        this.playerProgressionRepository = playerProgressionRepository;
        this.playerAmmoRepository = playerAmmoRepository;
        this.questRepository = questRepository;
        this.bossEncounterRepository = bossEncounterRepository;
        this.persistentObjectRepository = persistentObjectRepository;
        this.inventoryRepository = inventoryRepository;
    }

    /**
     * Creates the world if it doesn't exist yet, along with default bootstrap rows
     * (progression, quest, boss). This fixes the FK constraint violation when
     * Unity saves with a worldId that wasn't created via /worlds/create.
     */
    private void ensureWorldExists(String worldId, Long playerId) {
        if (worldRepository.existsById(worldId)) {
            return;
        }

        log.info("[GameSave] Auto-creating world: id={} ownerId={}", worldId, playerId);
        worldRepository.save(WorldEntity.builder()
                .id(worldId)
                .ownerId(playerId)
                .worldName("Auto-created on first save")
                .build());

        // Bootstrap default rows for subsystems that reference this world
        if (playerProgressionRepository.findByPlayerIdAndWorldId(playerId, worldId).isEmpty()) {
            playerProgressionRepository.save(PlayerProgressionEntity.builder()
                    .playerId(playerId).worldId(worldId).build());
        }
        if (questRepository.findByWorldIdAndQuestId(worldId, "sara_village").isEmpty()) {
            questRepository.save(QuestEntity.builder()
                    .worldId(worldId).questId("sara_village").build());
        }
        if (bossEncounterRepository.findByWorldId(worldId).isEmpty()) {
            bossEncounterRepository.save(BossEncounterEntity.builder()
                    .worldId(worldId).build());
        }
    }

    @Override
    @Transactional
    public GameSaveResponse save(GameSaveRequest request) {
        Long playerId = request.getPlayerId();
        String worldId = request.getWorldId();

        if (playerId == null || worldId == null) {
            throw GameException.badRequest("MISSING_IDS",
                    "playerId and worldId are required for game save");
        }

        if (!playerRepository.existsById(playerId)) {
            throw GameException.notFound("PLAYER_NOT_FOUND",
                    "Player " + playerId + " does not exist");
        }

        // Auto-create the world if it doesn't exist yet.
        // This handles the case where Unity sends "WORLD_DEFAULT" or a worldId
        // that wasn't previously created via /worlds/create (e.g., first save
        // after login without going through Start Game flow).
        ensureWorldExists(worldId, playerId);

        log.info("[GameSave] Saving full game state for playerId={} worldId={}", playerId, worldId);

        // 1. Save player world state (health, position, stats, scene)
        savePlayerWorldState(playerId, worldId, request);

        // 2. Save player progression (EXP, level)
        savePlayerProgression(playerId, worldId, request);

        // 3. Save ammo state
        saveAmmo(playerId, worldId, request);

        // 4. Save quest state (Sara's quest)
        saveQuest(worldId, request);

        // 5. Save Quest2 state
        saveQuest2(worldId, request);

        // 6. Save boss encounter state
        saveBoss(worldId, request);

        // 7. Save destroyed objects
        saveDestroyedObjects(worldId, request);

        // 8. Save inventory
        saveInventory(playerId, worldId, request);

        log.info("[GameSave] Full game state saved for playerId={} worldId={}", playerId, worldId);

        return GameSaveResponse.builder()
                .playerId(playerId)
                .worldId(worldId)
                .message("Game saved successfully")
                .build();
    }

    @Override
    public GameSaveResponse load(Long playerId, String worldId) {
        if (playerId == null || worldId == null) {
            throw GameException.badRequest("MISSING_IDS",
                    "playerId and worldId are required for game load");
        }

        if (!playerRepository.existsById(playerId)) {
            throw GameException.notFound("PLAYER_NOT_FOUND",
                    "Player " + playerId + " does not exist");
        }

        log.info("[GameSave] Loading full game state for playerId={} worldId={}", playerId, worldId);

        // 1. Load player world state
        GameSaveResponse.PlayerState playerState = loadPlayerWorldState(playerId, worldId);

        // 2. Load player progression
        GameSaveResponse.Progression progression = loadPlayerProgression(playerId, worldId);

        // 3. Load ammo state
        GameSaveResponse.AmmoState ammo = loadAmmo(playerId, worldId);

        // 4. Load quest state (Sara's quest)
        GameSaveResponse.QuestState quest = loadQuest(worldId);

        // 5. Load Quest2 state
        GameSaveResponse.Quest2State quest2 = loadQuest2(worldId);

        // 6. Load boss encounter state
        GameSaveResponse.BossState boss = loadBoss(worldId);

        // 7. Load destroyed objects
        List<String> destroyedIds = loadDestroyedObjects(worldId);

        // 8. Load inventory
        String inventoryJson = loadInventory(playerId, worldId);

        log.info("[GameSave] Full game state loaded for playerId={} worldId={}", playerId, worldId);

        return GameSaveResponse.builder()
                .playerId(playerId)
                .worldId(worldId)
                .message("Game loaded successfully")
                .playerState(playerState)
                .progression(progression)
                .ammo(ammo)
                .quest(quest)
                .quest2(quest2)
                .boss(boss)
                .inventoryJson(inventoryJson)
                .destroyedObjectIds(destroyedIds)
                .build();
    }

    // =========================================================================
    // Private save helpers — each saves one subsystem
    // =========================================================================

    private void savePlayerWorldState(Long playerId, String worldId, GameSaveRequest req) {
        PlayerWorldStateEntity state = playerWorldStateRepository
                .findByPlayerIdAndWorldId(playerId, worldId)
                .orElse(PlayerWorldStateEntity.builder()
                        .playerId(playerId)
                        .worldId(worldId)
                        .build());

        if (req.getCurrentHealth() != null) state.setCurrentHealth(req.getCurrentHealth());
        if (req.getMaxHealth() != null) state.setMaxHealth(req.getMaxHealth());
        if (req.getDamage() != null) state.setDamage(req.getDamage());
        if (req.getWeaponRange() != null) state.setWeaponRange(req.getWeaponRange());
        if (req.getSpeed() != null) state.setSpeed(req.getSpeed());
        if (req.getPositionX() != null) state.setPositionX(req.getPositionX());
        if (req.getPositionY() != null) state.setPositionY(req.getPositionY());
        if (req.getFacingDirection() != null) state.setFacingDirection(req.getFacingDirection());
        if (req.getCurrentScene() != null) state.setCurrentScene(req.getCurrentScene());

        playerWorldStateRepository.save(state);
    }

    private void savePlayerProgression(Long playerId, String worldId, GameSaveRequest req) {
        PlayerProgressionEntity prog = playerProgressionRepository
                .findByPlayerIdAndWorldId(playerId, worldId)
                .orElse(PlayerProgressionEntity.builder()
                        .playerId(playerId)
                        .worldId(worldId)
                        .build());

        if (req.getExperience() != null) prog.setExperience(req.getExperience());
        if (req.getLevel() != null) prog.setLevel(req.getLevel());
        if (req.getExpToLevel() != null) prog.setExpToLevel(req.getExpToLevel());
        if (req.getExpGrowthMultiplier() != null) prog.setExpGrowthMultiplier(req.getExpGrowthMultiplier());

        playerProgressionRepository.save(prog);
    }

    private void saveAmmo(Long playerId, String worldId, GameSaveRequest req) {
        PlayerAmmoEntity ammo = playerAmmoRepository
                .findByPlayerIdAndWorldId(playerId, worldId)
                .orElse(PlayerAmmoEntity.builder()
                        .playerId(playerId)
                        .worldId(worldId)
                        .build());

        if (req.getCurrentClip() != null) ammo.setCurrentClip(req.getCurrentClip());
        if (req.getMaxClipSize() != null) ammo.setMaxClipSize(req.getMaxClipSize());
        if (req.getTotalAmmoReserve() != null) ammo.setTotalAmmoReserve(req.getTotalAmmoReserve());

        playerAmmoRepository.save(ammo);
    }

    private void saveQuest(String worldId, GameSaveRequest req) {
        String questId = "sara_village";
        QuestEntity quest = questRepository.findByWorldIdAndQuestId(worldId, questId)
                .orElse(QuestEntity.builder()
                        .worldId(worldId)
                        .questId(questId)
                        .build());

        log.info("[GameSave] Quest BEFORE save: state={} remaining={} bossAlive={} (worldId={})",
                quest.getQuestState(), quest.getZombiesRemaining(), quest.isBossAlive(), worldId);

        if (req.getQuestState() != null) quest.setQuestState(req.getQuestState());
        if (req.getZombiesRemaining() != null) quest.setZombiesRemaining(req.getZombiesRemaining());
        if (req.getIsBossAlive() != null) quest.setBossAlive(req.getIsBossAlive());
        if (req.getIsElectricityFixed() != null) quest.setElectricityFixed(req.getIsElectricityFixed());

        log.info("[GameSave] Quest AFTER save: state={} remaining={} bossAlive={} elecFixed={} (worldId={})",
                quest.getQuestState(), quest.getZombiesRemaining(), quest.isBossAlive(), quest.isElectricityFixed(), worldId);

        questRepository.save(quest);
    }

    private void saveQuest2(String worldId, GameSaveRequest req) {
        // Quest2 uses a separate questId in the same quests table
        String questId = "quest2";
        QuestEntity quest = questRepository.findByWorldIdAndQuestId(worldId, questId)
                .orElse(QuestEntity.builder()
                        .worldId(worldId)
                        .questId(questId)
                        .build());

        // Map: quest2Started → questState (0=not started, 1=active, 2=complete)
        if (req.getQuest2Started() != null) {
            quest.setQuestState(req.getQuest2Started() ? 1 : 0);
        }
        // Map: quest2EnemiesRemaining → zombiesRemaining
        if (req.getQuest2EnemiesRemaining() != null) {
            quest.setZombiesRemaining(req.getQuest2EnemiesRemaining());
        }

        questRepository.save(quest);
    }

    private void saveBoss(String worldId, GameSaveRequest req) {
        BossEncounterEntity boss = bossEncounterRepository.findByWorldId(worldId)
                .orElse(BossEncounterEntity.builder()
                        .worldId(worldId)
                        .build());

        log.info("[GameSave] Boss BEFORE save: fightStarted={} isDefeated={} phase={} phase2={}",
                boss.isFightStarted(), boss.isDefeated(), boss.getCurrentPhase(), boss.isPhase2Activated());

        if (req.getFightStarted() != null) boss.setFightStarted(req.getFightStarted());
        if (req.getIsDefeated() != null) boss.setDefeated(req.getIsDefeated());
        if (req.getCurrentPhase() != null) boss.setCurrentPhase(req.getCurrentPhase());
        if (req.getPhase2Activated() != null) boss.setPhase2Activated(req.getPhase2Activated());

        bossEncounterRepository.save(boss);

        log.info("[GameSave] Boss AFTER save: fightStarted={} isDefeated={} phase={} phase2={} (worldId={})",
                boss.isFightStarted(), boss.isDefeated(), boss.getCurrentPhase(), boss.isPhase2Activated(), worldId);
    }

    private void saveDestroyedObjects(String worldId, GameSaveRequest req) {
        log.info("[GameSave] DestroyedObjects BEFORE: deleting all for worldId={}", worldId);
        persistentObjectRepository.deleteAllByWorldId(worldId);

        if (req.getDestroyedObjectIds() != null && !req.getDestroyedObjectIds().isEmpty()) {
            log.info("[GameSave] DestroyedObjects: saving {} new IDs for worldId={}", req.getDestroyedObjectIds().size(), worldId);
            for (String objectId : req.getDestroyedObjectIds()) {
                PersistentObjectEntity po = PersistentObjectEntity.builder()
                        .worldId(worldId)
                        .objectUniqueId(objectId)
                        .isDestroyed(true)
                        .build();
                persistentObjectRepository.save(po);
            }
        } else {
            log.info("[GameSave] DestroyedObjects: empty list, DB cleared for worldId={}", worldId);
        }
    }

    // -- Inventory save/load (reuses existing InventoryRepository) --

    private void saveInventory(Long playerId, String worldId, GameSaveRequest req) {
        String json = req.getInventoryJson();
        if (json == null || json.isEmpty() || json.equals("[]")) {
            // No inventory data — clear any existing inventory for this world
            inventoryRepository.findByPlayerIdAndWorldId(playerId, worldId)
                    .ifPresent(inv -> inventoryRepository.delete(inv));
            return;
        }

        // Parse the JSON array of slot data into inventory items
        InventoryEntity entity = inventoryRepository.findByPlayerIdAndWorldId(playerId, worldId)
                .orElseGet(() -> InventoryEntity.builder()
                        .playerId(playerId)
                        .worldId(worldId)
                        .items(new java.util.ArrayList<>())
                        .build());

        entity.getItems().clear();

        try {
            com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
            com.fasterxml.jackson.databind.JsonNode root = mapper.readTree(json);
            if (root.isArray()) {
                for (com.fasterxml.jackson.databind.JsonNode node : root) {
                    int qty = node.has("quantity") ? node.get("quantity").asInt() : 0;
                    if (qty <= 0) continue;

                    InventoryItemEntity item = InventoryItemEntity.builder()
                            .inventory(entity)
                            .itemId(node.has("itemName") ? node.get("itemName").asText() : "")
                            .itemName(node.has("itemName") ? node.get("itemName").asText() : "")
                            .quantity(qty)
                            .itemDescription(node.has("itemDescription") ? node.get("itemDescription").asText() : "")
                            .spriteName(node.has("itemSprite") ? node.get("itemSprite").asText() : "")
                            .build();
                    entity.getItems().add(item);
                }
            }
        } catch (Exception e) {
            log.error("[GameSave] Failed to parse inventory JSON: {}", e.getMessage());
            return;
        }

        inventoryRepository.save(entity);
        log.info("[GameSave] Inventory saved: {} items for playerId={} worldId={}",
                entity.getItems().size(), playerId, worldId);
    }

    private String loadInventory(Long playerId, String worldId) {
        return inventoryRepository.findByPlayerIdAndWorldId(playerId, worldId)
                .map(inv -> {
                    java.util.List<com.wastelandsurvivors.backend.dto.game.InventoryItemDTO> items = new java.util.ArrayList<>();
                    if (inv.getItems() != null) {
                        for (InventoryItemEntity item : inv.getItems()) {
                            items.add(com.wastelandsurvivors.backend.dto.game.InventoryItemDTO.builder()
                                    .itemId(item.getItemId())
                                    .itemName(item.getItemName())
                                    .quantity(item.getQuantity())
                                    .itemDescription(item.getItemDescription())
                                    .spriteName(item.getSpriteName())
                                    .build());
                        }
                    }
                    try {
                        return new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(items);
                    } catch (Exception e) {
                        log.error("[GameSave] Failed to serialize inventory: {}", e.getMessage());
                        return "[]";
                    }
                })
                .orElse("[]");
    }

    // =========================================================================
    // Private load helpers — each loads one subsystem
    // =========================================================================

    private GameSaveResponse.PlayerState loadPlayerWorldState(Long playerId, String worldId) {
        return playerWorldStateRepository.findByPlayerIdAndWorldId(playerId, worldId)
                .map(s -> {
                    log.info("[GameSave] LOAD playerState from DB: health={}/{} damage={} weaponRange={} pos=({},{}) scene={}",
                            s.getCurrentHealth(), s.getMaxHealth(), s.getDamage(), s.getWeaponRange(),
                            s.getPositionX(), s.getPositionY(), s.getCurrentScene());
                    return GameSaveResponse.PlayerState.builder()
                            .currentHealth(s.getCurrentHealth())
                            .maxHealth(s.getMaxHealth())
                            .damage(s.getDamage())
                            .weaponRange(s.getWeaponRange())
                            .speed(s.getSpeed())
                            .positionX(s.getPositionX())
                            .positionY(s.getPositionY())
                            .facingDirection(s.getFacingDirection())
                            .currentScene(s.getCurrentScene())
                            .build();
                })
                .orElseGet(() -> {
                    log.info("[GameSave] LOAD playerState: no row found for playerId={} worldId={} — using defaults", playerId, worldId);
                    return GameSaveResponse.PlayerState.builder()
                            .currentHealth(20).maxHealth(20)
                            .damage(1.0f).weaponRange(3.5f).speed(5.0f)
                            .positionX(0).positionY(0)
                            .facingDirection(1)
                            .currentScene(null)
                            .build();
                });
    }

    private GameSaveResponse.Progression loadPlayerProgression(Long playerId, String worldId) {
        return playerProgressionRepository.findByPlayerIdAndWorldId(playerId, worldId)
                .map(p -> GameSaveResponse.Progression.builder()
                        .experience(p.getExperience())
                        .level(p.getLevel())
                        .expToLevel(p.getExpToLevel())
                        .expGrowthMultiplier(p.getExpGrowthMultiplier())
                        .build())
                .orElse(GameSaveResponse.Progression.builder()
                        .experience(0).level(1)
                        .expToLevel(10).expGrowthMultiplier(1.2f)
                        .build());
    }

    private GameSaveResponse.AmmoState loadAmmo(Long playerId, String worldId) {
        return playerAmmoRepository.findByPlayerIdAndWorldId(playerId, worldId)
                .map(a -> GameSaveResponse.AmmoState.builder()
                        .currentClip(a.getCurrentClip())
                        .maxClipSize(a.getMaxClipSize())
                        .totalAmmoReserve(a.getTotalAmmoReserve())
                        .build())
                .orElse(GameSaveResponse.AmmoState.builder()
                        .currentClip(5).maxClipSize(5).totalAmmoReserve(25)
                        .build());
    }

    private GameSaveResponse.QuestState loadQuest(String worldId) {
        String questId = "sara_village";
        return questRepository.findByWorldIdAndQuestId(worldId, questId)
                .map(q -> GameSaveResponse.QuestState.builder()
                        .questState(q.getQuestState())
                        .zombiesRemaining(q.getZombiesRemaining())
                        .isBossAlive(q.isBossAlive())
                        .isElectricityFixed(q.isElectricityFixed())
                        .build())
                .orElse(GameSaveResponse.QuestState.builder()
                        .questState(0).zombiesRemaining(12).isBossAlive(true).isElectricityFixed(false)
                        .build());
    }

    private GameSaveResponse.Quest2State loadQuest2(String worldId) {
        String questId = "quest2";
        return questRepository.findByWorldIdAndQuestId(worldId, questId)
                .map(q -> GameSaveResponse.Quest2State.builder()
                        .quest2Started(q.getQuestState() >= 1)
                        .quest2EnemiesRemaining(q.getZombiesRemaining())
                        .build())
                .orElse(GameSaveResponse.Quest2State.builder()
                        .quest2Started(false).quest2EnemiesRemaining(0)
                        .build());
    }

    private GameSaveResponse.BossState loadBoss(String worldId) {
        GameSaveResponse.BossState result = bossEncounterRepository.findByWorldId(worldId)
                .map(b -> {
                    GameSaveResponse.BossState state = GameSaveResponse.BossState.builder()
                            .fightStarted(b.isFightStarted())
                            .isDefeated(b.isDefeated())
                            .currentPhase(b.getCurrentPhase())
                            .phase2Activated(b.isPhase2Activated())
                            .build();
                    log.info("[GameSave] Boss LOADED from DB: fightStarted={} isDefeated={} phase={} phase2={} (worldId={})",
                            state.isFightStarted(), state.isDefeated(), state.getCurrentPhase(), state.isPhase2Activated(), worldId);
                    return state;
                })
                .orElseGet(() -> {
                    log.info("[GameSave] Boss LOADED: no row found for worldId={} — returning defaults (all false).", worldId);
                    return GameSaveResponse.BossState.builder()
                            .fightStarted(false).isDefeated(false)
                            .currentPhase(1).phase2Activated(false)
                            .build();
                });
        return result;
    }

    private List<String> loadDestroyedObjects(String worldId) {
        return persistentObjectRepository.findByWorldId(worldId)
                .stream()
                .map(PersistentObjectEntity::getObjectUniqueId)
                .collect(Collectors.toList());
    }
}