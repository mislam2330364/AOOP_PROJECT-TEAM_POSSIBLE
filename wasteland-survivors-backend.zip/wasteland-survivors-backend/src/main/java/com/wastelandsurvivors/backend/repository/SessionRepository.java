package com.wastelandsurvivors.backend.repository;

import com.wastelandsurvivors.backend.entity.SessionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Spring Data JPA repository for {@link SessionEntity} (sessions table).
 */
public interface SessionRepository extends JpaRepository<SessionEntity, String> {

    /**
     * Finds a session by its 6-character join key.
     * Used when a guest player enters the key shared by the owner.
     */
    Optional<SessionEntity> findByJoinKey(String joinKey);
}
