package com.wastelandsurvivors.backend.service;

import com.wastelandsurvivors.backend.dto.request.LoginRequest;
import com.wastelandsurvivors.backend.dto.request.RegisterRequest;
import com.wastelandsurvivors.backend.dto.response.AuthResponse;

/**
 * Declares authentication capabilities for the Wasteland Survivors backend.
 *
 * <p>Implementations of this interface handle player registration, login, token
 * validation, and logout. Controllers depend on this interface — never on a
 * specific implementation. This means the authentication mechanism can be
 * swapped without any controller changing.</p>
 *
 * <p><b>Security note:</b> Tokens are JWTs signed with HMAC-SHA256. The signing
 * secret is configured in {@code application.properties} under
 * {@code app.jwt.secret} and must be at least 256 bits.</p>
 */
public interface AuthService {

    /**
     * Creates a new player account with the provided credentials.
     * The password is BCrypt-hashed before storage — plain text never touches the database.
     *
     * @param request Contains the desired username (3-20 chars) and password (min 6 chars).
     *                Validated by {@code @Valid} before this method is called.
     * @return AuthResponse containing the signed JWT token, the new player's database ID,
     *         their username, and a human-readable success message.
     * @throws com.wastelandsurvivors.backend.exception.GameException if the username is already taken
     */
    AuthResponse register(RegisterRequest request);

    /**
     * Validates player credentials and produces a signed JWT authentication token.
     * The returned token must be stored by the Unity client and included in the
     * {@code Authorization: Bearer {token}} header of every subsequent REST request
     * and the WebSocket connection handshake.
     *
     * @param request Contains the username and password to validate.
     * @return AuthResponse containing the signed JWT token if credentials are correct.
     * @throws com.wastelandsurvivors.backend.exception.GameException
     *         if the username does not exist or the password does not match
     */
    AuthResponse login(LoginRequest request);

    /**
     * Verifies that a JWT token is structurally valid, correctly signed, and has
     * not expired. Also checks that the token has not been revoked via {@link #logout}.
     *
     * <p>Used internally by the server to protect endpoints that require
     * authentication. Called before any protected controller method executes.</p>
     *
     * @param token The raw JWT token string to validate (without "Bearer " prefix).
     * @return true if the token is valid, unexpired, and not revoked; false otherwise
     */
    boolean validateToken(String token);

    /**
     * Revokes a player's current JWT token so it can no longer be used.
     * After this call, any request using the revoked token will fail
     * {@link #validateToken} checks.
     *
     * <p>The client should delete the stored token and return to the login screen.
     * This is a security-best-practice for complete logout — without it, a stolen
     * token remains usable until it naturally expires.</p>
     *
     * @param token The raw JWT token string to revoke.
     */
    void logout(String token);

    /**
     * Extracts the player ID from a JWT token without full validation.
     * Useful for identifying which player made a request after the token has
     * already been validated by an interceptor or filter.
     *
     * @param token The raw JWT token string (without "Bearer " prefix).
     * @return The player ID stored in the token's {@code sub} claim.
     */
    Long extractPlayerId(String token);
}

