package com.wastelandsurvivors.backend.websocket;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.dto.game.AmmoUpdateDTO;
import com.wastelandsurvivors.backend.dto.game.CombatActionDTO;
import com.wastelandsurvivors.backend.dto.game.EnemyActionDTO;
import com.wastelandsurvivors.backend.dto.game.EnemyHealthDTO;
import com.wastelandsurvivors.backend.dto.game.EnemyLifecycleDTO;
import com.wastelandsurvivors.backend.dto.game.EnemyPositionDTO;
import com.wastelandsurvivors.backend.dto.game.HealthDTO;
import com.wastelandsurvivors.backend.dto.game.PositionDTO;
import com.wastelandsurvivors.backend.dto.game.WebSocketMessage;
import com.wastelandsurvivors.backend.service.SyncService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

/**
 * Central handler for all incoming WebSocket messages during a multiplayer session.
 * Every message Unity sends arrives here first via @MessageMapping("/game").
 *
 * Message flow:
 *   1. Unity sends a WebSocketMessage JSON to /app/game
 *   2. This handler receives it
 *   3. The type field is read to determine the data kind
 *   4. Payload is deserialized to the correct DTO
 *   5. Appropriate SyncService method is called
 *   6. Message is broadcast to /topic/session/{sessionId}
 *      so the other player receives it
 *
 * Adding a new message type:
 *   1. Add constant to AppConstants.java AND NetworkConstants.cs
 *   2. Create DTO pair in dto/game/ and Assets/Scripts/Network/DTO/
 *   3. Add handler method to SyncService interface and its implementation
 *   4. Add one CASE to the switch in handleGameMessage() below
 */
@Controller
@Slf4j
@RequiredArgsConstructor
public class GameSocketHandler {

    // Processes each message type — stores state, validates, applies game logic.
    private final SyncService syncService;
    // Spring's tool for pushing messages TO connected clients.
    // Used to broadcast received messages to all session subscribers.
    private final SimpMessagingTemplate messagingTemplate;
    // Jackson deserializer. Converts the raw Object payload in WebSocketMessage
    // to a typed DTO based on the type field.
    private final ObjectMapper objectMapper;

    /**
     * Entry point for all WebSocket messages from Unity.
     * All messages arrive here — routing is done by the switch on message.type.
     * @param message The universal wrapper. type field determines how payload is processed.
     */
    @MessageMapping("/game")
    public void handleGameMessage(WebSocketMessage message) {
        log.info("[GameSocketHandler] type={} session={} sender={} payloadClass={}",
                message.getType(), message.getSessionId(), message.getSenderId(),
                message.getPayload() != null ? message.getPayload().getClass().getSimpleName() : "null");
        try {
            switch (message.getType()) {
                case AppConstants.MSG_POSITION: {
                    if (message.getPayload() == null) {
                        log.warn("[GameSocketHandler] POSITION with null payload — dropping");
                        break;
                    }
                    PositionDTO pos = convertPayload(message.getPayload(), PositionDTO.class);
                    if (pos != null) {
                        syncService.handlePositionUpdate(pos);
                    }
                    broadcastToSession(message);
                    break;
                }
                case AppConstants.MSG_ACTION: {
                    // Combat action. Store for replay log, broadcast to opponent.
                    CombatActionDTO action = convertPayload(message.getPayload(), CombatActionDTO.class);
                    syncService.handleCombatAction(action);
                    broadcastToSession(message);
                    break;
                }
                case AppConstants.MSG_HEALTH: {
                    // Health update. Update authoritative health value, broadcast to opponent.
                    HealthDTO health = convertPayload(message.getPayload(), HealthDTO.class);
                    syncService.handleHealthUpdate(health);
                    broadcastToSession(message);
                    break;
                }
                case AppConstants.MSG_ENEMY_POSITION: {
                    // Enemy position update. Store latest state, broadcast to all clients.
                    EnemyPositionDTO pos = convertPayload(message.getPayload(), EnemyPositionDTO.class);
                    syncService.handleEnemyPositionUpdate(pos);
                    broadcastToSession(message);
                    break;
                }
                case AppConstants.MSG_ENEMY_ACTION: {
                    // Enemy combat action. Store for replay log, broadcast to all clients.
                    EnemyActionDTO action = convertPayload(message.getPayload(), EnemyActionDTO.class);
                    syncService.handleEnemyAction(action);
                    broadcastToSession(message);
                    break;
                }
                case AppConstants.MSG_ENEMY_HEALTH: {
                    // Enemy health update. Update authoritative health value, broadcast to all clients.
                    EnemyHealthDTO health = convertPayload(message.getPayload(), EnemyHealthDTO.class);
                    syncService.handleEnemyHealthUpdate(health);
                    broadcastToSession(message);
                    break;
                }
                case AppConstants.MSG_ENEMY_SPAWN: {
                    // Enemy spawn event. Broadcast to all clients.
                    EnemyLifecycleDTO spawn = convertPayload(message.getPayload(), EnemyLifecycleDTO.class);
                    syncService.handleEnemySpawn(spawn);
                    broadcastToSession(message);
                    break;
                }
                case AppConstants.MSG_ENEMY_DESPAWN: {
                    // Enemy despawn event. Broadcast to all clients.
                    EnemyLifecycleDTO despawn = convertPayload(message.getPayload(), EnemyLifecycleDTO.class);
                    syncService.handleEnemyDespawn(despawn);
                    broadcastToSession(message);
                    break;
                }
                case AppConstants.MSG_SCENE_CHANGE: {
                    // Host changed scenes (walked through a door). Broadcast to
                    // the guest so they load the same scene and stay together.
                    // Payload is the scene name string (e.g. "village_scene_1").
                    broadcastToSession(message);
                    break;
                }
                case AppConstants.MSG_BOSS_PHASE: {
                    // Boss phase transition (Phase 1 → Phase 2 enraged mode).
                    // Broadcast to all clients so the guest can trigger the scream SFX,
                    // health restore, and stat buffs (damage +2, speed 1.5×).
                    syncService.handleBossPhase(message.getPayload());
                    broadcastToSession(message);
                    break;
                }
                case AppConstants.MSG_ENEMY_DAMAGE: {
                    // Guest-to-host enemy damage request.  The guest does NOT apply
                    // damage locally — the host receives this, applies damage to the
                    // authoritative enemy, and the resulting health sync broadcasts
                    // back to the guest.  Server just relays; no DB persistence needed
                    // for scene enemies (enemyId = 0).
                    broadcastToSession(message);
                    break;
                }
                case AppConstants.MSG_AMMO_UPDATE: {
                    // Ammo state update (fire, reload, pickup).
                    // Store latest ammo state, broadcast to opponent for UI sync.
                    AmmoUpdateDTO ammo = convertPayload(message.getPayload(), AmmoUpdateDTO.class);
                    syncService.handleAmmoUpdate(ammo);
                    broadcastToSession(message);
                    break;
                }
                case AppConstants.MSG_PING: {
                    // Keepalive check from Unity. Reply only to sender — do not broadcast.
                    // If Unity does not receive PONG within 5 seconds it should attempt reconnection.
                    WebSocketMessage pong = new WebSocketMessage();
                    pong.setType(AppConstants.MSG_PONG);
                    pong.setSessionId(message.getSessionId());
                    pong.setSenderId(message.getSenderId());
                    pong.setTimestamp(System.currentTimeMillis());
                    messagingTemplate.convertAndSendToUser(String.valueOf(message.getSenderId()), "/queue/pong", pong);
                    break;
                }
                default:
                    // Unknown message type — still broadcast to session so that
                    // custom/client-defined types (like ENEMY_HEALTH from
                    // EnemySyncManager) reach the other player even if the server
                    // doesn't explicitly handle them.
                    log.info("[GameSocketHandler] Unknown type '{}' — broadcasting to session anyway (passthrough mode).",
                            message.getType());
                    broadcastToSession(message);
            }
        } catch (Exception e) {
            log.error("[GameSocketHandler] Failed to process type: {}", message.getType(), e);
        }
    }

    /**
     * Broadcasts to all subscribers of /topic/session/{sessionId}.
     * Both players subscribe to this topic — the sender also receives their own message.
     * GameAPI.cs in Unity discards messages where senderId equals the local player's ID.
     * @param message The message to broadcast
     */
    private void broadcastToSession(WebSocketMessage message) {
        // Unity expects the payload as a JSON STRING, not a nested JSON object.
        // After convertPayload deserialized it to a DTO, we must re-serialize
        // it back to a string so Unity's JsonUtility (which has payload: string)
        // can parse it on the receiving end.
        if (message.getPayload() != null && !(message.getPayload() instanceof String)) {
            try {
                String jsonPayload = objectMapper.writeValueAsString(message.getPayload());
                message.setPayload(jsonPayload);
            } catch (Exception e) {
                log.error("[GameSocketHandler] Failed to re-serialize payload for broadcast: {}", e.getMessage());
            }
        }
        messagingTemplate.convertAndSend(AppConstants.WS_TOPIC_SESSION + message.getSessionId(), message);
        log.debug("[GameSocketHandler] Broadcast session={} type={}",
                message.getSessionId(), message.getType());
    }

    /**
     * Converts the raw Object payload to a typed DTO using Jackson.
     *
     * Unity sends the payload as a JSON STRING (e.g. "{\"playerId\":3,...}").
     * Jackson deserializes the outer WebSocketMessage and stores the payload
     * as a Java String.  We must first parse that string as JSON, then
     * convert to the target DTO class.
     *
     * If the payload is already a LinkedHashMap (from a non-Unity client),
     * convertValue() handles it directly.
     *
     * @param payload     Raw Object from WebSocketMessage.payload
     * @param targetClass DTO class to convert to, e.g. PositionDTO.class
     * @return Typed DTO instance
     * @throws Exception If conversion fails — caught by handleGameMessage
     */
    private <T> T convertPayload(Object payload, Class<T> targetClass) throws Exception {
        if (payload == null) {
            log.warn("[GameSocketHandler] convertPayload: null payload for {}", targetClass.getSimpleName());
            return null;
        }
        if (payload instanceof String jsonStr) {
            if (jsonStr.isEmpty()) {
                log.warn("[GameSocketHandler] convertPayload: empty string payload for {}", targetClass.getSimpleName());
                return null;
            }
            // Unity sends payload as a JSON string
            return objectMapper.readValue(jsonStr, targetClass);
        }
        // Non-Unity client — payload is already a deserialized Map
        return objectMapper.convertValue(payload, targetClass);
    }
}

