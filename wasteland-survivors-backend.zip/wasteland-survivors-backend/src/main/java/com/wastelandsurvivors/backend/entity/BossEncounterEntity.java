package com.wastelandsurvivors.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Boss encounter state per world — persisted in {@code boss_encounters}.
 * A world has at most one boss encounter. Tracks whether the fight has
 * started, which phase the boss is in, and whether the boss has been defeated.
 *
 * <h3>Boss Phase System (v2 update)</h3>
 * <p>The Mutated Boss now has a two-phase fight:</p>
 * <ol>
 *   <li><b>Phase 1</b> — Normal boss fight. Boss has base health/damage/speed.</li>
 *   <li><b>Phase 2</b> — Triggered when boss health first hits 0.
 *       Boss plays a scream ({@code Boss_Scream.mp3}), restores to phase2Health (100 HP),
 *       gains +2 damage, and moves at 1.5× speed.</li>
 * </ol>
 * <p>When the boss is defeated in phase 2, it dies permanently.</p>
 *
 * <h3>Unity source mapping</h3>
 * <ul>
 *   <li>{@code fightStarted} → BossManager.fightStarted</li>
 *   <li>{@code currentPhase} → Enemy_Health.phase2Activated (1 → 2 transition)</li>
 *   <li>{@code phase2Activated} → Enemy_Health.phase2Activated</li>
 *   <li>{@code phase2Health} → Enemy_Health.phase2Health (100 HP)</li>
 *   <li>{@code phase2SpeedMultiplier} → Enemy_Health.phase2SpeedMultiplier (1.5×)</li>
 *   <li>{@code isDefeated} → BossManager.BossDefeated()</li>
 *   <li>{@code bossEnemyId} → the enemy instance that IS the boss</li>
 * </ul>
 */
@Entity
@Table(name = "boss_encounters")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BossEncounterEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Which world this boss encounter belongs to.
     * Each world has exactly one boss encounter record (unique constraint).
     */
    @Column(name = "world_id", nullable = false, unique = true, length = 64)
    private String worldId;

    /**
     * The specific enemy instance that IS the boss. FK to enemy_instances.enemy_id.
     * NULL until the boss is spawned.
     */
    @Column(name = "boss_enemy_id")
    private Long bossEnemyId;

    /**
     * TRUE once the player enters the boss trigger zone.
     * Maps to: BossManager.fightStarted
     */
    @Column(name = "fight_started", nullable = false)
    @Builder.Default
    private boolean fightStarted = false;

    /**
     * Current boss phase: 1 = Phase 1 (normal), 2 = Phase 2 (enraged).
     * Starts at 1. Transitions to 2 when boss health first hits 0.
     * Maps to: Enemy_Health.isBoss + phase2Activated flag
     */
    @Column(name = "current_phase", nullable = false)
    @Builder.Default
    private int currentPhase = 1;

    /**
     * TRUE once the boss has entered Phase 2.
     * Prevents the phase transition from happening more than once.
     * Maps to: Enemy_Health.phase2Activated
     */
    @Column(name = "phase2_activated", nullable = false)
    @Builder.Default
    private boolean phase2Activated = false;

    /**
     * The health the boss restores to when entering Phase 2.
     * Maps to: Enemy_Health.phase2Health (default 100)
     */
    @Column(name = "phase2_health", nullable = false)
    @Builder.Default
    private int phase2Health = 100;

    /**
     * Speed multiplier applied when boss enters Phase 2.
     * Maps to: Enemy_Health.phase2SpeedMultiplier (default 1.5)
     */
    @Column(name = "phase2_speed_multiplier", nullable = false)
    @Builder.Default
    private double phase2SpeedMultiplier = 1.5;

    /**
     * TRUE once the boss has been killed.
     * Maps to: BossManager.BossDefeated() call
     */
    @Column(name = "is_defeated", nullable = false)
    @Builder.Default
    private boolean isDefeated = false;

    @Column(name = "updated_at", nullable = false, insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}
