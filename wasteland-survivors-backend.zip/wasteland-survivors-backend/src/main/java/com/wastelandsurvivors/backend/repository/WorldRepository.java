package com.wastelandsurvivors.backend.repository;

import com.wastelandsurvivors.backend.entity.WorldEntity;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Spring Data JPA repository for {@link WorldEntity} (worlds table).
 */
public interface WorldRepository extends JpaRepository<WorldEntity, String> {

    /**
     * Finds the first world owned by a player. Each player has at most one world.
     */
    java.util.Optional<WorldEntity> findFirstByOwnerId(Long ownerId);
}
