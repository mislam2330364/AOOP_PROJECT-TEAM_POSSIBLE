package com.wastelandsurvivors.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Represents a player account persisted in the {@code players} table.
 *
 * <p>This entity stores <b>account-level</b> data: authentication credentials,
 * profile flags, and timestamps. It does NOT store per-world runtime state
 * (health, position, stats) — those live in {@code player_world_state}
 * so a player can have different stats in different worlds.</p>
 *
 * <h3>Table mapping</h3>
 * <pre>
 * players
 *   id            BIGINT PK    → this.id
 *   username      VARCHAR(50)  → this.username (unique)
 *   password_hash VARCHAR(255) → this.passwordHash (BCrypt)
 *   has_played_intro BOOLEAN   → this.hasPlayedIntro
 *   created_at    TIMESTAMP    → auto-set by DB on insert
 *   last_login_at TIMESTAMP    → this.lastLoginAt
 * </pre>
 *
 * <h3>Unity source mapping</h3>
 * <ul>
 *   <li>{@code id} → GameAPI.LocalPlayerId, AuthResponse.playerId</li>
 *   <li>{@code username} → LoginRequest.username, AuthResponse.username</li>
 *   <li>{@code passwordHash} → NEVER sent to Unity — compared server-side only</li>
 *   <li>{@code hasPlayedIntro} → IntroDialogueTrigger.hasPlayedIntro (static)</li>
 *   <li>{@code lastLoginAt} → Display purposes only — "Last login: 2 hours ago"</li>
 * </ul>
 */
@Entity
@Table(name = "players")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PlayerEntity {

    /*
     * Primary key — auto-incremented by the database.
     * GenerationType.IDENTITY tells JPA: "let MySQL handle ID assignment."
     * This is the safest strategy for MySQL — no sequence tables needed.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /*
     * The player's unique login name. Chosen during registration.
     * unique=true creates a database constraint so no two players can share a username.
     * length=50 matches the schema definition.
     * → Maps to: LoginRequest.username, RegisterRequest.username, AuthResponse.username
     */
    @Column(nullable = false, unique = true, length = 50)
    private String username;

    /*
     * BCrypt-hashed password. BCrypt is a one-way hashing function:
     *   - Same input produces DIFFERENT output each time (random salt)
     *   - Cannot be reversed — you can never recover the original password
     *   - Login works by hashing the attempt and comparing hashes
     * NEVER expose this field in any API response.
     * → Maps to: RegisterRequest.password (AFTER hashing, never before)
     */
    @Column(nullable = false)
    private String passwordHash;

    /*
     * Whether the player has already seen the opening intro cutscene.
     * Once true, the IntroDialogueTrigger script self-destructs on scene entry
     * so the intro never replays on subsequent visits.
     * → Maps to: IntroDialogueTrigger.hasPlayedIntro (static bool in Unity)
     */
    @Column(nullable = false)
    @Builder.Default
    private boolean hasPlayedIntro = false;

    /*
     * When the player last successfully authenticated.
     * Updated on every POST /auth/login. NULL until first login.
     * Useful for admin dashboards, "last seen" UI, and purging inactive accounts.
     * Stored as Java LocalDateTime → JDBC maps to MySQL TIMESTAMP.
     */
    @Column(nullable = true)
    private LocalDateTime lastLoginAt;

    /*
     * Account creation timestamp.
     * Set by the database (DEFAULT CURRENT_TIMESTAMP), NOT by Java code.
     * insertable=false, updatable=false tells JPA: "never include this
     * column in INSERT or UPDATE statements — let the DB handle it."
     */
    @Column(nullable = false, insertable = false, updatable = false)
    private LocalDateTime createdAt;
}

