package com.wastelandsurvivors.backend.dto.game;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Carries the live position of an enemy during a multiplayer session.
 * Sent over WebSocket by the host client, wrapped inside a WebSocketMessage. (Both directions)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EnemyPositionDTO {

    // DEPRECATED (Phase 3): Server-assigned enemy ID. Always 0 for scene enemies.
    // Use enemyRuntimeId as the sole identity key.
    private long enemyId;

    // PRIMARY IDENTITY (Phase 3): ScenePersistentObject.runtimeUniqueID from Unity.
    // Sole key used across all enemy lookups, messages, and proxy references.
    private String enemyRuntimeId;

    // Which multiplayer session this enemy belongs to
    private String sessionId;

    // Enemy X coordinate in Unity world space
    private float x;

    // Enemy Y coordinate in Unity world space
    private float y;

    // Enemy facing direction (1 = right, -1 = left)
    private int facingDirection;

    // Unix time in milliseconds when this was captured in Unity
    private long timestamp;
}

