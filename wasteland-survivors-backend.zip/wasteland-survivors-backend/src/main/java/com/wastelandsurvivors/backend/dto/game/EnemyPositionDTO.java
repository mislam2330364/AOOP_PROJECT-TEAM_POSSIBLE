package com.wastelandsurvivors.backend.dto.game;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Carries the live position of an enemy during a multiplayer session.
 * Sent over WebSocket by the host client, wrapped inside a WebSocketMessage. (Both directions)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EnemyPositionDTO {

    // Server-assigned enemy ID — unique within the session (0 for scene enemies)
    private long enemyId;

    // Runtime-unique identifier for SCENE enemies (pre-placed in the Unity scene).
    // Matches ScenePersistentObject.runtimeUniqueID so the guest can find the
    // correct enemy to apply position updates to. Null/empty for server-spawned enemies.
    private String enemyRuntimeId;

    // Which multiplayer session this enemy belongs to
    private String sessionId;

    // Enemy X coordinate in Unity world space
    private float x;

    // Enemy Y coordinate in Unity world space
    private float y;

    // Enemy facing direction (1 = right, -1 = left)
    private int facingDirection;

    // Unix time in milliseconds when this was captured in Unity
    private long timestamp;
}

