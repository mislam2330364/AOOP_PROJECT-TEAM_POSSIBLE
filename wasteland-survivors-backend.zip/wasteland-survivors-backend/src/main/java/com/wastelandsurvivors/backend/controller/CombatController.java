package com.wastelandsurvivors.backend.controller;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.service.CombatService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * REST Controller for server-authoritative combat resolution.
 * Supports GUN (ranged, frenzy) and MELEE (proximity, knockback) attacks.
 */
@RestController
@RequestMapping(AppConstants.API_V1 + "/combat")
@Slf4j
public class CombatController {

    private final CombatService combatService;

    public CombatController(CombatService combatService) {
        this.combatService = combatService;
    }

    /**
     * Processes an attack from a player. Server validates cooldown,
     * selects target, computes damage, and handles kill consequences.
     *
     * POST /api/v1/combat/attack
     *   ?playerId=&worldId=&attackPointX=&attackPointY=&weaponRange=
     *   &actionType=ATTACK|MELEE
     *   &meleeDamage=2  (only used for MELEE)
     */
    @PostMapping("/attack")
    public ResponseEntity<?> attack(@RequestParam Long playerId,
                                    @RequestParam String worldId,
                                    @RequestParam float attackPointX,
                                    @RequestParam float attackPointY,
                                    @RequestParam float weaponRange,
                                    @RequestParam(defaultValue = "ATTACK") String actionType,
                                    @RequestParam(defaultValue = "2") int meleeDamage) {
        log.debug("[CombatController] POST /attack — playerId={} worldId={} type={}", playerId, worldId, actionType);
        Map<String, Object> result = combatService.resolveAttack(
                playerId, worldId, attackPointX, attackPointY, weaponRange, actionType, meleeDamage);
        return ResponseEntity.ok(result);
    }

    /**
     * Returns the current frenzy state for a player.
     * GET /api/v1/combat/frenzy-state/{playerId}?worldId=...
     */
    @GetMapping("/frenzy-state/{playerId}")
    public ResponseEntity<?> getFrenzyState(@PathVariable Long playerId,
                                            @RequestParam String worldId) {
        log.debug("[CombatController] GET /frenzy-state/{}?worldId={}", playerId, worldId);
        return ResponseEntity.ok(combatService.getFrenzyState(playerId, worldId));
    }

    /**
     * Reloads the player's weapon — moves bullets from reserve to clip.
     * Matches the reload logic in Player_Combat.cs (R key, WaitForSeconds(1.5f)).
     *
     * POST /api/v1/combat/reload?playerId=&worldId=
     */
    @PostMapping("/reload")
    public ResponseEntity<?> reload(@RequestParam Long playerId,
                                    @RequestParam String worldId) {
        log.info("[CombatController] POST /reload — playerId={} worldId={}", playerId, worldId);
        return ResponseEntity.ok(combatService.reload(playerId, worldId));
    }

    /**
     * Returns the current ammo state for a player.
     * GET /api/v1/combat/ammo/{playerId}?worldId=...
     */
    @GetMapping("/ammo/{playerId}")
    public ResponseEntity<?> getAmmo(@PathVariable Long playerId,
                                     @RequestParam String worldId) {
        log.debug("[CombatController] GET /ammo/{}?worldId={}", playerId, worldId);
        return ResponseEntity.ok(combatService.getAmmo(playerId, worldId));
    }
}
