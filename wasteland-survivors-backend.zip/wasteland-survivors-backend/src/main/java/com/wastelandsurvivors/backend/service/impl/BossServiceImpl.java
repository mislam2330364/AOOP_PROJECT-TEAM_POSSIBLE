package com.wastelandsurvivors.backend.service.impl;

import com.wastelandsurvivors.backend.entity.BossEncounterEntity;
import com.wastelandsurvivors.backend.exception.GameException;
import com.wastelandsurvivors.backend.repository.BossEncounterRepository;
import com.wastelandsurvivors.backend.service.BossService;
import com.wastelandsurvivors.backend.service.QuestService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Full implementation of {@link BossService}.
 *
 * <p>Manages the two-phase boss encounter lifecycle:
 * <ol>
 *   <li>Not started — boss trigger zone not yet entered</li>
 *   <li>Phase 1 — normal boss fight. Boss has base health/damage/speed.</li>
 *   <li>Phase 2 — enraged boss. Triggered when boss health first hits 0.
 *       Boss plays a scream (Boss_Scream.mp3), restores to phase2Health (100 HP),
 *       gains +2 damage, and moves at 1.5× speed.</li>
 *   <li>Defeated — isDefeated=true, arena unlocked, quest updated</li>
 * </ol></p>
 */
@Service
@Slf4j
public class BossServiceImpl implements BossService {

    private final BossEncounterRepository bossRepository;
    private final QuestService questService;

    public BossServiceImpl(BossEncounterRepository bossRepository,
                            QuestService questService) {
        this.bossRepository = bossRepository;
        this.questService = questService;
    }

    @Override
    public BossEncounterEntity getBossState(String worldId) {
        return bossRepository.findByWorldId(worldId)
                .orElseGet(() -> {
                    BossEncounterEntity defaults = BossEncounterEntity.builder()
                            .worldId(worldId)
                            .build();
                    log.info("[Boss] Auto-created default boss encounter for worldId={}", worldId);
                    return bossRepository.save(defaults);
                });
    }

    @Override
    public BossEncounterEntity startBossFight(String worldId, Long bossEnemyId) {
        BossEncounterEntity boss = getOrCreate(worldId);

        if (boss.isFightStarted()) {
            throw GameException.badRequest("BOSS_ALREADY_STARTED",
                    "Boss fight has already started for world " + worldId);
        }

        if (boss.isDefeated()) {
            throw GameException.badRequest("BOSS_ALREADY_DEFEATED",
                    "Boss has already been defeated in world " + worldId);
        }

        boss.setFightStarted(true);
        boss.setBossEnemyId(bossEnemyId);
        bossRepository.save(boss);

        log.info("[Boss] Fight started: worldId={} bossEnemyId={}", worldId, bossEnemyId);
        return boss;
    }

    @Override
    public BossEncounterEntity triggerPhase2(String worldId) {
        BossEncounterEntity boss = getOrCreate(worldId);

        if (!boss.isFightStarted()) {
            throw GameException.badRequest("BOSS_NOT_STARTED",
                    "Boss fight has not started in world " + worldId);
        }

        if (boss.isDefeated()) {
            throw GameException.badRequest("BOSS_ALREADY_DEFEATED",
                    "Boss has already been defeated in world " + worldId);
        }

        if (boss.isPhase2Activated()) {
            throw GameException.badRequest("BOSS_ALREADY_PHASE2",
                    "Boss is already in Phase 2 in world " + worldId);
        }

        boss.setCurrentPhase(2);
        boss.setPhase2Activated(true);
        bossRepository.save(boss);

        log.info("[Boss] Phase 2 triggered: worldId={} phase2Health={} phase2SpeedMultiplier={}",
                worldId, boss.getPhase2Health(), boss.getPhase2SpeedMultiplier());
        return boss;
    }

    @Override
    public BossEncounterEntity defeatBoss(String worldId) {
        BossEncounterEntity boss = getOrCreate(worldId);

        if (!boss.isFightStarted()) {
            throw GameException.badRequest("BOSS_NOT_STARTED",
                    "Boss fight has not started in world " + worldId);
        }

        boss.setDefeated(true);
        bossRepository.save(boss);

        // Notify the quest system
        questService.recordEnemyKilled(worldId, true);

        log.info("[Boss] Defeated: worldId={}", worldId);
        return boss;
    }

    private BossEncounterEntity getOrCreate(String worldId) {
        return bossRepository.findByWorldId(worldId)
                .orElseGet(() -> bossRepository.save(BossEncounterEntity.builder()
                        .worldId(worldId)
                        .build()));
    }
}
