package com.wastelandsurvivors.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Runtime enemy instance in a world — persisted in {@code enemy_instances}.
 * Dynamic state (health, position, AI state) is stored here.
 * Static template data is JOINed from {@link EnemyTypeEntity}.
 *
 * <h3>Unity source mapping</h3>
 * <ul>
 *   <li>{@code enemyId} → EnemyFollowPlayer.enemyId, EnemyPositionDTO.enemyId</li>
 *   <li>{@code currentHealth} → Enemy_Health.currentHealth</li>
 *   <li>{@code positionX/Y} → EnemyPositionDTO.x/y</li>
 *   <li>{@code enemyState} → EnemyFollowPlayer.EnemyState enum (IDLE/CHASING/ATTACKING)</li>
 * </ul>
 */
@Entity
@Table(name = "enemy_instances")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EnemyInstanceEntity {

    /**
     * Unique ID for this specific enemy instance. Assigned by the server on spawn.
     * Maps to: EnemyFollowPlayer.enemyId, EnemyPositionDTO.enemyId
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "enemy_id")
    private Long enemyId;

    /**
     * Which world this enemy exists in. FK to worlds.id.
     */
    @Column(name = "world_id", nullable = false, length = 64)
    private String worldId;

    /**
     * What kind of enemy this is. FK to enemy_types.type_id.
     */
    @Column(name = "type_id", nullable = false, length = 64)
    private String typeId;

    // -- Runtime values (change during gameplay) --

    @Column(name = "current_health", nullable = false)
    private int currentHealth;

    @Column(name = "position_x", nullable = false)
    @Builder.Default
    private float positionX = 0.0f;

    @Column(name = "position_y", nullable = false)
    @Builder.Default
    private float positionY = 0.0f;

    @Column(name = "facing_direction", nullable = false)
    @Builder.Default
    private int facingDirection = 1;

    /**
     * Current AI state: IDLE, CHASING, or ATTACKING.
     * Maps to: EnemyFollowPlayer.EnemyState enum
     */
    @Column(name = "enemy_state", nullable = false, length = 16)
    @Builder.Default
    private String enemyState = "IDLE";

    /**
     * FALSE once this enemy has been killed. Dead enemies remain in the table
     * for quest/boss reference but are excluded from active-spawn queries.
     */
    @Column(name = "is_alive", nullable = false)
    @Builder.Default
    private boolean isAlive = true;

    @Column(name = "created_at", nullable = false, insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false, insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}
