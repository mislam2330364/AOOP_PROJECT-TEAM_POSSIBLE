package com.wastelandsurvivors.backend.controller;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.dto.request.AddFriendRequest;
import com.wastelandsurvivors.backend.service.FriendService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST Controller for friend management.
 *
 * <p>These endpoints are called by Unity's FriendMenuManager when the player
 * interacts with the friend menu (add/remove friends, invite, join).</p>
 *
 * <h3>Unity → Backend mapping</h3>
 * <pre>
 * FriendMenuManager.ConfirmJoin()       → POST /api/v1/friends/join/{code}
 * FriendMenuManager.CopyCode()          → Invite code comes from POST /api/v1/friends/invite
 * </pre>
 */
@RestController
@RequestMapping(AppConstants.API_V1 + "/friends")
@Slf4j
public class FriendController {

    private final FriendService friendService;

    public FriendController(FriendService friendService) {
        this.friendService = friendService;
    }

    /**
     * Adds a friend for the authenticated player.
     *
     * <p><b>Unity sends:</b></p>
     * <pre>
     * POST /api/v1/friends/add
     * { "playerId": 1, "friendId": 2 }
     * </pre>
     *
     * <p><b>Unity receives (200 OK):</b></p>
     * <pre>
     * { "friendId": 2, "username": "PlayerTwo", "lastLoginAt": "2026-06-10T12:00:00" }
     * </pre>
     */
    @PostMapping("/add")
    public ResponseEntity<?> addFriend(@RequestBody @Valid AddFriendRequest request) {
        log.info("[FriendController] POST /add — playerId={} friendId={}",
                request.getPlayerId(), request.getFriendId());
        return ResponseEntity.ok(
                friendService.addFriend(request.getPlayerId(), request.getFriendId()));
    }

    /**
     * Removes a friend.
     *
     * <p><b>Unity sends:</b></p>
     * <pre>
     * DELETE /api/v1/friends/remove/2?playerId=1
     * </pre>
     */
    @DeleteMapping("/remove/{friendId}")
    public ResponseEntity<?> removeFriend(@PathVariable Long friendId,
                                          @RequestParam Long playerId) {
        log.info("[FriendController] DELETE /remove/{} — playerId={}", friendId, playerId);
        friendService.removeFriend(playerId, friendId);
        return ResponseEntity.ok().build();
    }

    /**
     * Returns the player's friends list.
     *
     * <p><b>Unity sends:</b></p>
     * <pre>
     * GET /api/v1/friends/list?playerId=1
     * </pre>
     *
     * <p><b>Unity receives (200 OK):</b> JSON array of FriendResponse</p>
     */
    @GetMapping("/list")
    public ResponseEntity<?> getFriends(@RequestParam Long playerId) {
        log.info("[FriendController] GET /list?playerId={}", playerId);
        return ResponseEntity.ok(friendService.getFriends(playerId));
    }

    /**
     * Generates an invite code for the player to share with a friend.
     *
     * <p><b>Unity sends:</b></p>
     * <pre>
     * POST /api/v1/friends/invite?playerId=1&worldId=WORLD_ABC123
     * </pre>
     *
     * <p><b>Unity receives (201 CREATED):</b></p>
     * <pre>
     * { "inviteCode": "A1B2C3", "sessionId": "SESS_ABC12345", "message": "..." }
     * </pre>
     */
    @PostMapping("/invite")
    public ResponseEntity<?> generateInviteCode(@RequestParam Long playerId,
                                                 @RequestParam(required = false) String worldId) {
        log.info("[FriendController] POST /invite — playerId={} worldId={}", playerId, worldId);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(friendService.generateInviteCode(playerId, worldId));
    }

    /**
     * Joins a friend's session using an invite code.
     *
     * <p><b>Unity sends:</b></p>
     * <pre>
     * POST /api/v1/friends/join/A1B2C3?playerId=2
     * </pre>
     *
     * <p><b>Unity receives (200 OK):</b></p>
     * <pre>
     * { "inviteCode": "A1B2C3", "sessionId": "SESS_ABC12345", "message": "Successfully joined..." }
     * </pre>
     */
    @PostMapping("/join/{code}")
    public ResponseEntity<?> joinFriend(@PathVariable String code,
                                         @RequestParam Long playerId) {
        log.info("[FriendController] POST /join/{} — playerId={}", code, playerId);
        return ResponseEntity.ok(friendService.joinFriend(playerId, code));
    }
}
