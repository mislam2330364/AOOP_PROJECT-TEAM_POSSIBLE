package com.wastelandsurvivors.backend.service.impl;

import com.wastelandsurvivors.backend.entity.PlayerWorldStateEntity;
import com.wastelandsurvivors.backend.exception.GameException;
import com.wastelandsurvivors.backend.repository.PlayerRepository;
import com.wastelandsurvivors.backend.repository.PlayerWorldStateRepository;
import com.wastelandsurvivors.backend.service.PlayerStatsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Full implementation of {@link PlayerStatsService} backed by the player_world_state table.
 */
@Service
@Slf4j
public class PlayerStatsServiceImpl implements PlayerStatsService {

    private final PlayerWorldStateRepository stateRepository;
    private final PlayerRepository playerRepository;

    public PlayerStatsServiceImpl(PlayerWorldStateRepository stateRepository,
                                  PlayerRepository playerRepository) {
        this.stateRepository = stateRepository;
        this.playerRepository = playerRepository;
    }

    @Override
    public PlayerWorldStateEntity getStats(Long playerId, String worldId) {
        if (!playerRepository.existsById(playerId)) {
            throw GameException.notFound("PLAYER_NOT_FOUND",
                    "Player " + playerId + " does not exist");
        }

        return stateRepository.findByPlayerIdAndWorldId(playerId, worldId)
                .orElseGet(() -> {
                    // Auto-create default state if none exists
                    PlayerWorldStateEntity defaultState = PlayerWorldStateEntity.builder()
                            .playerId(playerId)
                            .worldId(worldId)
                            .build();
                    log.info("[PlayerStats] Auto-created default state for playerId={} worldId={}",
                            playerId, worldId);
                    return stateRepository.save(defaultState);
                });
    }

    @Override
    public PlayerWorldStateEntity updateStats(Long playerId, String worldId,
                                               PlayerWorldStateEntity stats) {
        if (!playerRepository.existsById(playerId)) {
            throw GameException.notFound("PLAYER_NOT_FOUND",
                    "Player " + playerId + " does not exist");
        }

        PlayerWorldStateEntity existing = stateRepository
                .findByPlayerIdAndWorldId(playerId, worldId)
                .orElse(PlayerWorldStateEntity.builder()
                        .playerId(playerId)
                        .worldId(worldId)
                        .build());

        // Only overwrite fields that are non-default in the incoming stats
        if (stats.getCurrentHealth() != 0 || stats.getMaxHealth() != 0) {
            existing.setCurrentHealth(stats.getCurrentHealth());
            existing.setMaxHealth(stats.getMaxHealth());
        }
        if (stats.getDamage() > 0) existing.setDamage(stats.getDamage());
        if (stats.getWeaponRange() > 0) existing.setWeaponRange(stats.getWeaponRange());
        if (stats.getSpeed() > 0) existing.setSpeed(stats.getSpeed());
        existing.setPositionX(stats.getPositionX());
        existing.setPositionY(stats.getPositionY());
        existing.setFacingDirection(stats.getFacingDirection());
        if (stats.getCurrentScene() != null) existing.setCurrentScene(stats.getCurrentScene());

        PlayerWorldStateEntity saved = stateRepository.save(existing);
        log.debug("[PlayerStats] Updated stats for playerId={} worldId={}", playerId, worldId);
        return saved;
    }
}
