package com.wastelandsurvivors.backend.controller;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.dto.request.LoginRequest;
import com.wastelandsurvivors.backend.dto.request.RegisterRequest;
import com.wastelandsurvivors.backend.service.AuthService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * REST Controller for authentication — registration, login, and logout.
 *
 * <p>Endpoint signatures are the contract between Unity and the server.
 * Every method signature, URL path, and response shape declared here must
 * exactly match what the Unity client (MockLoginManager.cs / GameAPI.cs)
 * expects. If you change a path or field name here, change it in Unity too.</p>
 *
 * <p><b>RULE:</b> This class handles HTTP routing only. All business logic
 * (password hashing, JWT creation, token validation) belongs in AuthService.
 * Controllers translate HTTP concepts (headers, status codes, request bodies)
 * to plain Java method calls and back.</p>
 *
 * <h3>How these endpoints map to Unity</h3>
 * <pre>
 * Unity MockLoginManager.cs  →  POST /api/v1/auth/register  →  AuthService.register()
 * Unity MockLoginManager.cs  →  POST /api/v1/auth/login      →  AuthService.login()
 * Unity GameAPI.cs           →  POST /api/v1/auth/logout     →  AuthService.logout()
 * </pre>
 */
@RestController
@RequestMapping(AppConstants.API_V1 + "/auth")
@Slf4j
public class AuthController {

    /*
     * The authentication service — injected by Spring via constructor.
     * Points to the AuthService INTERFACE, never to AuthServiceImpl directly.
     * This means the implementation can be swapped (e.g., for testing with a
     * mock service) without changing a single line in this controller.
     */
    private final AuthService authService;

    /**
     * Explicit constructor for dependency injection.
     * Spring automatically finds the AuthService bean and passes it here.
     *
     * @param authService The authentication service implementation
     */
    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    /**
     * Registers a new player account and returns a JWT on success.
     *
     * <p><b>Unity sends:</b> RegisterRequest JSON</p>
     * <pre>
     * {
     *   "username": "player123",    // 3-20 characters, unique
     *   "password": "secret123"     // minimum 6 characters
     * }
     * </pre>
     *
     * <p><b>Unity receives (201 CREATED):</b> AuthResponse JSON</p>
     * <pre>
     * {
     *   "token": "eyJhbGciOiJIUzI1NiJ9...",   // Signed JWT — store this
     *   "playerId": 1,                           // Database ID for this account
     *   "username": "player123",                 // Echoed back for UI display
     *   "message": "Registration successful"     // Human-readable status
     * }
     * </pre>
     *
     * <p><b>Error responses:</b>
     * <ul>
     *   <li>400 BAD_REQUEST — Username already taken, or validation failed (too short/long)</li>
     * </ul></p>
     *
     * @param request Validated registration data. @Valid triggers jakarta.validation
     *                checks (@NotBlank, @Size) BEFORE this method runs. If validation
     *                fails, GlobalExceptionHandler returns a 400 automatically.
     * @return 201 CREATED with AuthResponse containing the signed JWT
     */
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody @Valid RegisterRequest request) {
        log.info("[AuthController] POST /register — username: {}", request.getUsername());
        return ResponseEntity.status(HttpStatus.CREATED).body(authService.register(request));
    }

    /**
     * Authenticates a player and returns a JWT.
     *
     * <p><b>Unity sends:</b> LoginRequest JSON</p>
     * <pre>
     * {
     *   "username": "player123",
     *   "password": "secret123"
     * }
     * </pre>
     *
     * <p><b>Unity receives (200 OK):</b> AuthResponse JSON (same shape as register).
     * The token must be stored by GameAPI.cs and included as:
     * {@code Authorization: Bearer <token>} in all future REST and WebSocket requests.</p>
     *
     * <p><b>Error responses:</b>
     * <ul>
     *   <li>401 UNAUTHORIZED — Username not found or password incorrect (same message for both, to prevent account enumeration)</li>
     * </ul></p>
     *
     * @param request Validated login credentials
     * @return 200 OK with AuthResponse containing the signed JWT
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody @Valid LoginRequest request) {
        log.info("[AuthController] POST /login — username: {}", request.getUsername());
        return ResponseEntity.ok(authService.login(request));
    }

    /**
     * Logs a player out by revoking their current JWT token.
     *
     * <p>After this call:
     * <ul>
     *   <li>The token is added to a server-side blacklist</li>
     *   <li>Any future request using this token will be rejected with 401</li>
     *   <li>The Unity client should delete the stored token and return to the login screen</li>
     * </ul></p>
     *
     * <p><b>Unity sends:</b> The JWT in the Authorization header</p>
     * <pre>
     * Authorization: Bearer eyJhbGciOiJIUzI1NiJ9...
     * </pre>
     *
     * <p><b>Unity receives (200 OK):</b></p>
     * <pre>
     * {
     *   "message": "Logged out successfully"
     * }
     * </pre>
     *
     * <p><b>Security note:</b> JWTs are stateless — they cannot be destroyed server-side.
     * Instead, this endpoint adds the token to a blacklist. The blacklist is checked
     * on every authenticated request. This is the standard pattern for JWT logout.</p>
     *
     * @param authHeader The full Authorization header value, e.g. "Bearer eyJ..."
     * @return 200 OK with confirmation message
     */
    @PostMapping("/logout")
    public ResponseEntity<?> logout(@RequestHeader(value = "Authorization", required = false) String authHeader) {
        // Extract the raw token from the Authorization header.
        // The header format is: "Bearer <token>"
        // We strip the "Bearer " prefix (7 characters) to get the raw JWT.
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);
            authService.logout(token);
            log.info("[AuthController] POST /logout — token revoked");
        } else {
            // No token provided — the player might already be logged out client-side.
            // We don't treat this as an error; the intent (logout) is still fulfilled.
            log.debug("[AuthController] POST /logout — no Bearer token in request, nothing to revoke");
        }

        return ResponseEntity.ok(Map.of("message", "Logged out successfully"));
    }
}

