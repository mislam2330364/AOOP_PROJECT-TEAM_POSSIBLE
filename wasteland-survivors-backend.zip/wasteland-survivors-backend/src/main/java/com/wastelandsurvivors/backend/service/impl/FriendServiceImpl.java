package com.wastelandsurvivors.backend.service.impl;

import com.wastelandsurvivors.backend.dto.request.CreateLobbyRequest;
import com.wastelandsurvivors.backend.dto.request.JoinLobbyRequest;
import com.wastelandsurvivors.backend.dto.response.FriendResponse;
import com.wastelandsurvivors.backend.dto.response.InviteCodeResponse;
import com.wastelandsurvivors.backend.dto.response.LobbyResponse;
import com.wastelandsurvivors.backend.entity.FriendEntity;
import com.wastelandsurvivors.backend.entity.PlayerEntity;
import com.wastelandsurvivors.backend.exception.GameException;
import com.wastelandsurvivors.backend.repository.FriendRepository;
import com.wastelandsurvivors.backend.repository.PlayerRepository;
import com.wastelandsurvivors.backend.service.FriendService;
import com.wastelandsurvivors.backend.service.LobbyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Full implementation of {@link FriendService} backed by the friends table.
 *
 * <p>Friendship is bidirectional — adding creates two rows (A→B and B→A)
 * so both players see each other. Removing deletes both rows.</p>
 *
 * <p>Invite/join delegates to {@link LobbyService} for session management,
 * reusing the 6-character join key system.</p>
 */
@Service
@Slf4j
public class FriendServiceImpl implements FriendService {

    private final FriendRepository friendRepository;
    private final PlayerRepository playerRepository;
    private final LobbyService lobbyService;

    public FriendServiceImpl(FriendRepository friendRepository,
                             PlayerRepository playerRepository,
                             LobbyService lobbyService) {
        this.friendRepository = friendRepository;
        this.playerRepository = playerRepository;
        this.lobbyService = lobbyService;
    }

    @Override
    @Transactional
    public FriendResponse addFriend(Long playerId, Long friendId) {
        if (playerId.equals(friendId)) {
            throw GameException.badRequest("SELF_FRIEND",
                    "You cannot add yourself as a friend");
        }

        // Verify the friend exists
        PlayerEntity friend = playerRepository.findById(friendId)
                .orElseThrow(() -> GameException.notFound("PLAYER_NOT_FOUND",
                        "Player " + friendId + " does not exist"));

        // Check if friendship already exists
        if (friendRepository.existsByPlayerIdAndFriendId(playerId, friendId)) {
            throw GameException.badRequest("ALREADY_FRIENDS",
                    "You are already friends with player " + friendId);
        }

        // Create bidirectional friendship
        friendRepository.save(FriendEntity.builder()
                .playerId(playerId)
                .friendId(friendId)
                .build());

        friendRepository.save(FriendEntity.builder()
                .playerId(friendId)
                .friendId(playerId)
                .build());

        log.info("[Friend] Friendship created: playerId={} friendId={}", playerId, friendId);

        return FriendResponse.builder()
                .friendId(friend.getId())
                .username(friend.getUsername())
                .lastLoginAt(friend.getLastLoginAt())
                .build();
    }

    @Override
    @Transactional
    public void removeFriend(Long playerId, Long friendId) {
        if (!friendRepository.existsByPlayerIdAndFriendId(playerId, friendId)) {
            throw GameException.notFound("FRIENDSHIP_NOT_FOUND",
                    "No friendship exists between player " + playerId + " and player " + friendId);
        }

        // Remove both directions
        friendRepository.deleteByPlayerIdAndFriendId(playerId, friendId);
        friendRepository.deleteByPlayerIdAndFriendId(friendId, playerId);

        log.info("[Friend] Friendship removed: playerId={} friendId={}", playerId, friendId);
    }

    @Override
    public List<FriendResponse> getFriends(Long playerId) {
        List<FriendEntity> friendships = friendRepository.findByPlayerId(playerId);

        return friendships.stream()
                .map(f -> {
                    PlayerEntity friend = playerRepository.findById(f.getFriendId()).orElse(null);
                    return FriendResponse.builder()
                            .friendId(f.getFriendId())
                            .username(friend != null ? friend.getUsername() : "Unknown")
                            .lastLoginAt(friend != null ? friend.getLastLoginAt() : null)
                            .build();
                })
                .collect(Collectors.toList());
    }

    @Override
    public InviteCodeResponse generateInviteCode(Long playerId, String worldId) {
        // Verify the player exists
        if (!playerRepository.existsById(playerId)) {
            throw GameException.notFound("PLAYER_NOT_FOUND",
                    "Player " + playerId + " does not exist");
        }

        // Create a lobby session — the join key IS the invite code
        CreateLobbyRequest lobbyRequest = CreateLobbyRequest.builder()
                .ownerId(playerId)
                .worldId(worldId != null ? worldId : "WORLD_DEFAULT")
                .build();

        LobbyResponse lobby = lobbyService.createSession(lobbyRequest);

        log.info("[Friend] Invite code generated: playerId={} code={} sessionId={}",
                playerId, lobby.getJoinKey(), lobby.getSessionId());

        return InviteCodeResponse.builder()
                .inviteCode(lobby.getJoinKey())
                .sessionId(lobby.getSessionId())
                .message("Invite code generated — share this with your friend")
                .build();
    }

    @Override
    public InviteCodeResponse joinFriend(Long playerId, String inviteCode) {
        // Verify the player exists
        if (!playerRepository.existsById(playerId)) {
            throw GameException.notFound("PLAYER_NOT_FOUND",
                    "Player " + playerId + " does not exist");
        }

        JoinLobbyRequest joinRequest = JoinLobbyRequest.builder()
                .joinKey(inviteCode)
                .guestId(playerId)
                .build();

        LobbyResponse lobby = lobbyService.joinSession(joinRequest);

        log.info("[Friend] Player joined via invite: playerId={} code={} sessionId={}",
                playerId, inviteCode, lobby.getSessionId());

        return InviteCodeResponse.builder()
                .inviteCode(inviteCode)
                .sessionId(lobby.getSessionId())
                .message("Successfully joined friend's session")
                .build();
    }
}
