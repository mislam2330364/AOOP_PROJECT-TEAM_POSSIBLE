package com.wastelandsurvivors.backend.service.impl;

import com.wastelandsurvivors.backend.dto.request.LoginRequest;
import com.wastelandsurvivors.backend.dto.request.RegisterRequest;
import com.wastelandsurvivors.backend.dto.response.AuthResponse;
import com.wastelandsurvivors.backend.entity.PlayerEntity;
import com.wastelandsurvivors.backend.exception.GameException;
import com.wastelandsurvivors.backend.repository.PlayerRepository;
import com.wastelandsurvivors.backend.service.AuthService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.security.SignatureException;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Full JWT-backed implementation of {@link AuthService} using JJWT 0.12.x.
 *
 * <h3>What this service does</h3>
 * <ul>
 *   <li><b>Registration:</b> Hashes password with BCrypt, saves player to DB,
 *       returns a signed JWT so the player is logged in immediately.</li>
 *   <li><b>Login:</b> Validates credentials against the database, returns a
 *       signed JWT on success.</li>
 *   <li><b>Token validation:</b> Verifies the JWT signature, checks expiry,
 *       and confirms the token hasn't been revoked via logout.</li>
 *   <li><b>Logout:</b> Adds the token to an in-memory blacklist so it cannot
 *       be reused. In a distributed deployment, replace this with a Redis
 *       blacklist shared across all server instances.</li>
 * </ul>
 *
 * <h3>JWT structure</h3>
 * <pre>
 * Header:  { "alg": "HS256" }
 * Payload: {
 *   "sub": "playerId",       // who this token belongs to
 *   "iat": 1717800000,        // issued-at (Unix seconds)
 *   "exp": 1717886400         // expiration (issued-at + 24 hours)
 * }
 * Signature: HMAC-SHA256(header.payload, secretKey)
 * </pre>
 *
 * <h3>How Unity uses this</h3>
 * <ol>
 *   <li>Unity calls POST /auth/login or /auth/register</li>
 *   <li>Receives AuthResponse with the token field populated</li>
 *   <li>Stores token and sends it as HTTP header:
 *       {@code Authorization: Bearer <token>}</li>
 *   <li>On logout, Unity calls POST /auth/logout with the token,
 *       then deletes it from local storage</li>
 * </ol>
 *
 * <h3>JJWT 0.12.x API notes</h3>
 * <p>This code uses the fluent builder API introduced in JJWT 0.12.0:
 * <ul>
 *   <li>{@code Jwts.parser()} replaces {@code Jwts.parserBuilder()}</li>
 *   <li>{@code verifyWith(key)} replaces {@code setSigningKey(key)}</li>
 *   <li>{@code parseSignedClaims(token)} replaces {@code parseClaimsJws(token)}</li>
 *   <li>{@code signWith(key)} auto-detects the algorithm — no need to
 *       specify {@code SignatureAlgorithm.HS256} separately</li>
 *   <li>Builder setters drop the "set" prefix: {@code subject()} not
 *       {@code setSubject()}, {@code issuedAt()} not {@code setIssuedAt()}</li>
 * </ul></p>
 *
 * @see AuthService
 * @see AuthResponse
 */
@Service
@Slf4j
public class AuthServiceImpl implements AuthService {

    // -- Configuration values injected from application.properties --

    /*
     * The secret key used to sign JWTs. Must be at least 256 bits (32 chars)
     * for the HS256 algorithm. Set via JWT_SECRET environment variable or
     * defaults to the value in application.properties.
     *
     * HOW IT WORKS (beginner-friendly):
     * Think of this secret like a wax seal on a letter. The server stamps
     * the token with this secret when creating it. When the token comes back
     * in a request, the server checks the seal. If anyone tampered with the
     * token (e.g., changed the playerId), the seal won't match and the
     * server rejects it. Only servers that know the secret can create or
     * verify tokens. This is why you must keep this value private.
     *
     * Generate a production secret with: openssl rand -base64 32
     */
    @Value("${app.jwt.secret}")
    private String jwtSecret;

    /*
     * How long a token lives before the player must log in again.
     * Default: 86,400,000 ms = 24 hours.
     * Short lifetimes are more secure but require more frequent re-login.
     */
    @Value("${app.jwt.expiration-ms}")
    private long jwtExpirationMs;

    // -- Dependencies injected by Spring --

    /*
     * Spring Data JPA repository for the players table.
     * Provides save(), findById(), findByUsername(), existsByUsername().
     * We never write SQL manually — Spring generates it from method names.
     */
    private final PlayerRepository playerRepository;

    /*
     * BCrypt is a one-way password hashing function designed specifically
     * for storing passwords. Key properties:
     *   - Same input ALWAYS produces a different hash (random salt each time)
     *   - Cannot be reversed — you can never "decrypt" a BCrypt hash
     *   - Intentionally slow — makes brute-force attacks impractical
     * Login works by hashing the submitted password and comparing hashes,
     * NOT by decrypting the stored hash.
     */
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    // -- Runtime state --

    /*
     * In-memory set of revoked tokens. When a player logs out, their token
     * is added here. Every validateToken() call checks this set first.
     *
     * Why ConcurrentHashMap? Multiple players can log out simultaneously.
     * ConcurrentHashMap.newKeySet() creates a thread-safe Set backed by
     * ConcurrentHashMap — safe for concurrent reads and writes.
     *
     * IMPORTANT LIMITATION: This blacklist lives in server memory only.
     * If the server restarts, the blacklist is wiped and all previously
     * revoked tokens become valid again (until they expire naturally).
     * For production with multiple server instances, replace this with a
     * shared Redis cache so all instances see the same blacklist.
     */
    private final Set<String> tokenBlacklist = ConcurrentHashMap.newKeySet();

    /*
     * The cryptographic key derived from the secret string.
     * Initialised in init() after Spring injects jwtSecret.
     * Keys.hmacShaKeyFor() ensures the key meets the minimum length
     * required by the HS256 algorithm (256 bits / 32 bytes).
     */
    private SecretKey signingKey;

    // -- Constructor --

    /**
     * Constructor-based dependency injection.
     * Spring automatically passes the PlayerRepository bean.
     *
     * @param playerRepository JPA repository for player accounts
     */
    public AuthServiceImpl(PlayerRepository playerRepository) {
        this.playerRepository = playerRepository;
    }

    // -- Initialisation --

    /**
     * Called by Spring AFTER the constructor and AFTER all @Value fields
     * are injected. Derives the HMAC signing key from the configured secret.
     *
     * Why @PostConstruct instead of the constructor?
     * Spring fills @Value fields AFTER the constructor runs. If we tried
     * to read jwtSecret in the constructor, it would be null. @PostConstruct
     * guarantees all injections are complete before this runs.
     */
    @PostConstruct
    public void init() {
        // Keys.hmacShaKeyFor() requires at least 256 bits (32 bytes) for HS256.
        // If the secret is shorter, Spring Boot will fail to start with a
        // WeakKeyException — this is intentional to prevent weak keys in production.
        this.signingKey = Keys.hmacShaKeyFor(jwtSecret.getBytes(StandardCharsets.UTF_8));
        log.info("[Auth] JWT signing key initialised. Algorithm: HS256. Token lifetime: {} ms", jwtExpirationMs);
    }

    // -- Public API: AuthService implementation --

    /**
     * {@inheritDoc}
     *
     * <p>Implementation details:
     * <ol>
     *   <li>Check if the username is already taken — reject with 400 if so</li>
     *   <li>BCrypt-hash the password (NEVER store plain text)</li>
     *   <li>Persist the new player row to the database</li>
     *   <li>Generate and return a signed JWT so the player is logged in immediately</li>
     * </ol></p>
     */
    @Override
    public AuthResponse register(RegisterRequest request) {
        // Step 1: Uniqueness check.
        // existsByUsername() generates: SELECT COUNT(*) FROM players WHERE username = ?
        if (playerRepository.existsByUsername(request.getUsername())) {
            throw GameException.badRequest("USERNAME_TAKEN", "Username is already in use");
        }

        // Step 2: Build the entity.
        // The password is hashed BEFORE it reaches the database.
        // Even if the database is compromised, attackers cannot recover the original passwords.
        PlayerEntity player = PlayerEntity.builder()
                .username(request.getUsername())
                .passwordHash(passwordEncoder.encode(request.getPassword()))
                .hasPlayedIntro(false)
                .build();

        // Step 3: Persist.
        // Spring Data JPA generates: INSERT INTO players (...) VALUES (...)
        PlayerEntity saved = playerRepository.save(player);

        // Step 4: Generate token. The player is automatically logged in after registration
        // so they don't need to type credentials again on the next screen.
        String token = generateToken(saved.getId());

        log.info("[Auth] New player registered: id={} username={}", saved.getId(), saved.getUsername());

        return AuthResponse.builder()
                .token(token)
                .playerId(saved.getId())
                .username(saved.getUsername())
                .message("Registration successful")
                .build();
    }

    /**
     * {@inheritDoc}
     *
     * <p>Implementation details:
     * <ol>
     *   <li>Look up the player by username in the database</li>
     *   <li>Use BCrypt.matches() to compare the submitted password against the stored hash</li>
     *   <li>If either step fails, return the SAME generic error message.
     *       This is intentional — never reveal whether the username exists or the
     *       password is wrong, as that helps attackers enumerate valid accounts.</li>
     *   <li>Update last_login_at timestamp</li>
     *   <li>Generate and return a signed JWT</li>
     * </ol></p>
     */
    @Override
    public AuthResponse login(LoginRequest request) {
        // Step 1: Find the player.
        PlayerEntity player = playerRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> GameException.unauthorized("Invalid username or password"));

        // Step 2: Verify password.
        // BCrypt.matches() takes the plain-text attempt, hashes it with the SAME SALT
        // that was used when storing the original hash, and compares the two hashes.
        if (!passwordEncoder.matches(request.getPassword(), player.getPasswordHash())) {
            throw GameException.unauthorized("Invalid username or password");
        }

        // Step 3: Update last login time.
        player.setLastLoginAt(java.time.LocalDateTime.now());
        playerRepository.save(player);

        // Step 4: Generate JWT.
        String token = generateToken(player.getId());

        log.info("[Auth] Player logged in: id={} username={}", player.getId(), player.getUsername());

        return AuthResponse.builder()
                .token(token)
                .playerId(player.getId())
                .username(player.getUsername())
                .message("Login successful")
                .build();
    }

    /**
     * {@inheritDoc}
     *
     * <p>Validation steps:
     * <ol>
     *   <li>Reject null/blank tokens immediately (no DB lookup needed)</li>
     *   <li>Check the blacklist — if the token was revoked via logout, reject it</li>
     *   <li>Parse the JWT and verify its cryptographic signature using the signing key</li>
     *   <li>Check the expiration time — expired tokens are rejected</li>
     *   <li>Extract the player ID and verify the player still exists in the database</li>
     * </ol></p>
     *
     * <p>Why check the database on every validation? If a player account is deleted
     * after a token is issued, the token should stop working immediately, not
     * continue granting access until it expires naturally.</p>
     */
    @Override
    public boolean validateToken(String token) {
        // Quick rejection: null or blank tokens are never valid.
        if (token == null || token.isBlank()) {
            return false;
        }

        // Blacklist check: if the player logged out, the token is in this set.
        // This is an O(1) operation — extremely fast regardless of blacklist size.
        if (tokenBlacklist.contains(token)) {
            log.debug("[Auth] Token rejected: present in blacklist (user logged out)");
            return false;
        }

        try {
            // Parse the token. Jwts.parser().verifyWith()...parseSignedClaims() does:
            //   1. Splits the token into header.payload.signature
            //   2. Verifies the signature against our signingKey
            //   3. Decodes the payload (claims) as a JSON object
            //   4. Checks that the exp claim is not in the past
            // If the token was tampered with, the signature won't match and this throws.
            //
            // JJWT 0.12.x API: parser() replaces parserBuilder(),
            // verifyWith() replaces setSigningKey(),
            // parseSignedClaims() replaces parseClaimsJws(),
            // getPayload() replaces getBody().
            Claims claims = Jwts.parser()
                    .verifyWith(signingKey)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();

            // Extract the subject claim (playerId as a string, convert to Long).
            Long playerId = Long.parseLong(claims.getSubject());

            // Verify the player still exists in the database.
            return playerRepository.existsById(playerId);

        } catch (ExpiredJwtException e) {
            // Token is structurally valid but the exp claim is in the past.
            log.debug("[Auth] Token rejected: expired at {}", e.getClaims().getExpiration());
            return false;
        } catch (SignatureException e) {
            // The token's signature doesn't match what we compute with our key.
            // This means either: the token was tampered with, OR it was signed
            // with a different secret (e.g., from a different server instance).
            log.warn("[Auth] Token rejected: invalid signature (possible tampering)");
            return false;
        } catch (MalformedJwtException e) {
            // The token is not a valid JWT at all — wrong format, not 3 parts, etc.
            log.debug("[Auth] Token rejected: malformed JWT");
            return false;
        } catch (JwtException | IllegalArgumentException e) {
            // Catch-all for any other JWT parsing issues.
            log.debug("[Auth] Token rejected: {}", e.getMessage());
            return false;
        }
    }

    /**
     * {@inheritDoc}
     *
     * <p>Adds the token to the in-memory blacklist. Subsequent calls to
     * {@link #validateToken} with this token will return false.</p>
     *
     * <p>Note: This does NOT delete the token — JWTs are stateless and cannot
     * be destroyed. It simply marks it as unusable. The token's data still
     * exists, but this server will reject it.</p>
     */
    @Override
    public void logout(String token) {
        if (token != null && !token.isBlank()) {
            tokenBlacklist.add(token);
            log.info("[Auth] Token blacklisted (logout): {}...", token.substring(0, Math.min(10, token.length())));
        }
    }

    /**
     * {@inheritDoc}
     *
     * <p>Only extracts the player ID — does NOT validate the token signature
     * or expiry. Always call {@link #validateToken} first to verify the token
     * is legitimate before using the extracted player ID.</p>
     */
    @Override
    public Long extractPlayerId(String token) {
        Claims claims = Jwts.parser()
                .verifyWith(signingKey)
                .build()
                .parseSignedClaims(token)
                .getPayload();
        return Long.parseLong(claims.getSubject());
    }

    // -- Private helpers --

    /**
     * Creates a signed JWT for the given player using JJWT 0.12.x API.
     *
     * <p>The resulting token is a three-part Base64-encoded string:
     * {@code header.payload.signature}. It can be verified by any server
     * that knows the secret key, without a database lookup.</p>
     *
     * <p><b>JJWT 0.12.x:</b> {@code signWith(key)} auto-detects the algorithm
     * from the key type — for an HMAC key it uses HS256. No need to pass
     * {@code SignatureAlgorithm.HS256} explicitly.</p>
     *
     * @param playerId The database ID to embed as the token subject.
     * @return A compact, URL-safe JWT string ready to send to the client.
     */
    private String generateToken(Long playerId) {
        // Capture the current time so both issued-at and expiration are
        // based on the same clock tick — avoids off-by-one issues.
        Date now = new Date();
        Date expiry = new Date(now.getTime() + jwtExpirationMs);

        // Build the JWT using JJWT 0.12.x fluent API.
        // subject() stores the player ID — the "who" of the token.
        // issuedAt() records when the token was created.
        // expiration() sets the hard expiry time after which the token is invalid.
        // signWith(signingKey) cryptographically signs the token (HS256 auto-detected).
        //
        // Note: 0.12.x drops the "set" prefix — subject() not setSubject(),
        // issuedAt() not setIssuedAt(), expiration() not setExpiration().
        return Jwts.builder()
                .subject(playerId.toString())
                .issuedAt(now)
                .expiration(expiry)
                .signWith(signingKey)
                .compact();
    }
}
