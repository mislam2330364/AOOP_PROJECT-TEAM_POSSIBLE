package com.wastelandsurvivors.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Enemy type catalog entry — persisted in {@code enemy_types}.
 * Template/definition data for each enemy variant. Runtime state lives in
 * {@link EnemyInstanceEntity}, which references this type.
 *
 * <h3>Unity source mapping</h3>
 * <ul>
 *   <li>Prefabs: Zombie_variant_01, Zombie_variant_01_Type_02, ZombieType03, Walk1, Boss</li>
 *   <li>Stats → EnemyFollowPlayer.cs, Enemy_combat.cs (Ene), Enemy_Health.cs</li>
 * </ul>
 */
@Entity
@Table(name = "enemy_types")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EnemyTypeEntity {

    /**
     * Unique enemy type code, e.g. "ZOMBIE_VARIANT_01", "BOSS_MUTATED".
     * Maps to: EnemyLifecycleDTO.enemyType
     */
    @Id
    @Column(name = "type_id", nullable = false, length = 64)
    private String typeId;

    /**
     * Human-readable name shown in quest HUD, e.g. "Mutated Boss".
     */
    @Column(name = "display_name", nullable = false, length = 100)
    private String displayName;

    // -- Template stats (copied to enemy_instances on spawn) --

    @Column(name = "base_health", nullable = false)
    private int baseHealth;

    @Column(name = "base_damage", nullable = false)
    private int baseDamage;

    @Column(name = "base_speed", nullable = false)
    private float baseSpeed;

    @Column(name = "base_attack_range", nullable = false)
    private float baseAttackRange;

    @Column(name = "base_detect_range", nullable = false)
    private float baseDetectRange;

    @Column(name = "base_attack_cooldown", nullable = false)
    private float baseAttackCooldown;

    // -- Meta --

    /**
     * EXP granted when this enemy type is killed.
     * Maps to: Enemy_Health.expReward
     */
    @Column(name = "exp_reward", nullable = false)
    @Builder.Default
    private int expReward = 3;

    /**
     * TRUE if this enemy type is a boss. Bosses have special behaviour
     * (nativeSpriteFacingSign=-1, trigger BossManager).
     */
    @Column(name = "is_boss", nullable = false)
    @Builder.Default
    private boolean isBoss = false;

    /**
     * 1 = sprite faces right natively (standard). -1 = sprite faces left (boss).
     * Maps to: EnemyFollowPlayer.nativeSpriteFacingSign
     */
    @Column(name = "native_sprite_facing_sign", nullable = false)
    @Builder.Default
    private int nativeSpriteFacingSign = 1;

    /**
     * Unity prefab asset name for spawning.
     * Maps to: EnemyLifecycleDTO spawn reference
     */
    @Column(name = "prefab_name", length = 100)
    private String prefabName;

    /**
     * Relative probability of this type being chosen for random spawns.
     * Higher = more common.
     */
    @Column(name = "spawn_weight", nullable = false)
    @Builder.Default
    private int spawnWeight = 1;
}
