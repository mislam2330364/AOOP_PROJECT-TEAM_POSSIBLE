package com.wastelandsurvivors.backend.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Sent by Unity to /api/v1/lobby/create when the world owner opens the multiplayer lobby.
 * The server creates a session and returns a 6-character join key for the owner to share with their friend.
 * (Unity to server)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreateLobbyRequest {

    // The ID of the world being opened for multiplayer — must already exist in the database
    @NotBlank(message = "World ID is required")
    private String worldId;

    // The database ID of the player who owns this world and is hosting the session
    @NotNull(message = "Owner ID is required")
    private Long ownerId;

    // The host's current Unity scene name (e.g. "Interior_02").  Used so the
    // guest loads the correct scene — the DB value may be stale from a
    // previous save.
    private String currentScene;
}

