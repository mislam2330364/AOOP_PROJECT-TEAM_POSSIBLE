package com.wastelandsurvivors.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * A branching choice within a dialogue tree — persisted in {@code dialogue_options}.
 * Each option appears as a button at the end of a dialogue. Choosing one
 * can lead to another dialogue tree or end the conversation.
 *
 * <h3>Unity source mapping</h3>
 * <ul>
 *   <li>{@code optionIndex} → DialogueManager.choicesButtons[i]</li>
 *   <li>{@code optionText} → DialogueOption.optionText (button label)</li>
 *   <li>{@code nextDialogueId} → DialogueOption.nextDialogue (null = end)</li>
 * </ul>
 */
@Entity
@Table(name = "dialogue_options")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DialogueOptionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Which dialogue tree these options belong to. FK to dialogue_trees.dialogue_id.
     */
    @Column(name = "dialogue_id", nullable = false, length = 64)
    private String dialogueId;

    /**
     * Order of this option button. 0 = first button.
     * Unique per dialogue (dialogue_id + option_index).
     */
    @Column(name = "option_index", nullable = false)
    private int optionIndex;

    /**
     * The text shown on the choice button.
     * Maps to: DialogueOption.optionText
     */
    @Column(name = "option_text", nullable = false, length = 255)
    private String optionText;

    /**
     * The dialogue tree to start if this option is chosen.
     * NULL = end the conversation.
     * Maps to: DialogueOption.nextDialogue
     */
    @Column(name = "next_dialogue_id", length = 64)
    private String nextDialogueId;
}
