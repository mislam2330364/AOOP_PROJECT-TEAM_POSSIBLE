package com.wastelandsurvivors.backend.dto.game;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Carries enemy spawn/despawn information for a multiplayer session.
 * Sent over WebSocket by the host client, wrapped inside a WebSocketMessage. (Both directions)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EnemyLifecycleDTO {

    // Server-assigned enemy ID — unique within the session (0 for scene enemies)
    private long enemyId;

    // Runtime-unique identifier for SCENE enemies (pre-placed in the Unity scene).
    // Matches ScenePersistentObject.runtimeUniqueID so the guest can find the
    // correct enemy to despawn. Null/empty for server-spawned enemies.
    private String enemyRuntimeId;

    // Which multiplayer session this enemy belongs to
    private String sessionId;

    // Enemy prefab/type identifier (e.g., ZOMBIE_VARIANT_01)
    private String enemyType;

    // X coordinate for spawn/despawn position
    private float x;

    // Y coordinate for spawn/despawn position
    private float y;

    // Unix time in milliseconds when this was captured in Unity
    private long timestamp;
}

