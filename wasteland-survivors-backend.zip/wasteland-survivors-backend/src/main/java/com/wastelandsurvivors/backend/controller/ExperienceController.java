package com.wastelandsurvivors.backend.controller;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.service.ExperienceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * REST Controller for EXP and leveling.
 */
@RestController
@RequestMapping(AppConstants.API_V1 + "/players")
@Slf4j
public class ExperienceController {

    private final ExperienceService experienceService;

    public ExperienceController(ExperienceService experienceService) {
        this.experienceService = experienceService;
    }

    /**
     * Returns current level and EXP for a player in a world.
     * GET /api/v1/players/{playerId}/exp?worldId=...
     */
    @GetMapping("/{playerId}/exp")
    public ResponseEntity<?> getProgression(@PathVariable Long playerId,
                                            @RequestParam String worldId) {
        log.debug("[ExpController] GET /{}/exp?worldId={}", playerId, worldId);
        return ResponseEntity.ok(experienceService.getProgression(playerId, worldId));
    }

    /**
     * Adds EXP to the player. Level-up is checked automatically.
     * POST /api/v1/players/{playerId}/exp/add?worldId=...&amount=...
     */
    @PostMapping("/{playerId}/exp/add")
    public ResponseEntity<?> addExperience(@PathVariable Long playerId,
                                           @RequestParam String worldId,
                                           @RequestParam long amount) {
        log.info("[ExpController] POST /{}/exp/add?worldId={}&amount={}", playerId, worldId, amount);
        return ResponseEntity.ok(experienceService.addExperience(playerId, worldId, amount));
    }
}
