package com.wastelandsurvivors.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Destruction/collection record per world — persisted in {@code persistent_objects}.
 * Tracks which destructible/collectible objects have been removed so they
 * don't respawn when the player leaves and re-enters a scene.
 *
 * <h3>Unity source mapping</h3>
 * <ul>
 *   <li>{@code objectUniqueId} → ScenePersistentObject.uniqueID</li>
 *   <li>{@code isDestroyed} → checked by ScenePersistentObject.Start() on scene load</li>
 *   <li>Destroyed set → SimpleQuestManager.destroyedObjectIDs (HashSet)</li>
 * </ul>
 */
@Entity
@Table(name = "persistent_objects",
       uniqueConstraints = @jakarta.persistence.UniqueConstraint(columnNames = {"world_id", "object_unique_id"}))
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PersistentObjectEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Which world this destruction record belongs to. FK to worlds.id.
     */
    @Column(name = "world_id", nullable = false, length = 64)
    private String worldId;

    /**
     * The unique ID from ScenePersistentObject.uniqueID.
     * Auto-generated as name_x_y if not manually set in Unity.
     */
    @Column(name = "object_unique_id", nullable = false, length = 255)
    private String objectUniqueId;

    /**
     * TRUE = object has been destroyed or collected.
     * Currently only destroyed objects are tracked (always true on insert).
     */
    @Column(name = "is_destroyed", nullable = false)
    @Builder.Default
    private boolean isDestroyed = true;

    /**
     * When this object was destroyed or collected.
     * Set by the database (DEFAULT CURRENT_TIMESTAMP).
     */
    @Column(name = "destroyed_at", nullable = false, insertable = false, updatable = false)
    private LocalDateTime destroyedAt;
}
