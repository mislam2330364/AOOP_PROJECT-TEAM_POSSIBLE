package com.wastelandsurvivors.backend.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Sent by Unity to POST /api/v1/friends/add when a player adds a friend.
 * (Unity to server)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AddFriendRequest {

    @NotNull(message = "Player ID is required")
    private Long playerId;

    @NotNull(message = "Friend ID is required")
    private Long friendId;
}
