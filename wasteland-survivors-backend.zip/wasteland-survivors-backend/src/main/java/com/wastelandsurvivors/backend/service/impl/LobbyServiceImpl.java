package com.wastelandsurvivors.backend.service.impl;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.dto.game.WebSocketMessage;
import com.wastelandsurvivors.backend.dto.request.CreateLobbyRequest;
import com.wastelandsurvivors.backend.dto.request.JoinLobbyRequest;
import com.wastelandsurvivors.backend.dto.response.LobbyResponse;
import com.wastelandsurvivors.backend.entity.BossEncounterEntity;
import com.wastelandsurvivors.backend.entity.PlayerProgressionEntity;
import com.wastelandsurvivors.backend.entity.QuestEntity;
import com.wastelandsurvivors.backend.entity.SessionEntity;
import com.wastelandsurvivors.backend.entity.WorldEntity;
import com.wastelandsurvivors.backend.exception.GameException;
import com.wastelandsurvivors.backend.entity.PlayerWorldStateEntity;
import com.wastelandsurvivors.backend.repository.BossEncounterRepository;
import com.wastelandsurvivors.backend.repository.PlayerProgressionRepository;
import com.wastelandsurvivors.backend.repository.PlayerWorldStateRepository;
import com.wastelandsurvivors.backend.repository.QuestRepository;
import com.wastelandsurvivors.backend.repository.SessionRepository;
import com.wastelandsurvivors.backend.repository.WorldRepository;
import com.wastelandsurvivors.backend.service.LobbyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.util.Set;
import java.util.UUID;

/**
 * Full implementation of {@link LobbyService} backed by the sessions table.
 *
 * <h3>Session lifecycle</h3>
 * <ol>
 *   <li>Owner calls create → WAITING row inserted, 6-char join key generated</li>
 *   <li>Guest calls join with the key → guestId set, still WAITING</li>
 *   <li>Owner calls start → status → ACTIVE, SESSION_READY broadcast</li>
 *   <li>Either player disconnects → status → CLOSED</li>
 * </ol>
 */
@Service
@Slf4j
public class LobbyServiceImpl implements LobbyService {

    private static final String ALPHANUMERIC = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final int JOIN_KEY_LENGTH = 6;
    private static final SecureRandom RANDOM = new SecureRandom();

    private final SessionRepository sessionRepository;
    private final WorldRepository worldRepository;
    private final PlayerWorldStateRepository playerStateRepository;
    private final PlayerProgressionRepository playerProgressionRepository;
    private final QuestRepository questRepository;
    private final BossEncounterRepository bossEncounterRepository;
    private final EnemySessionManager enemySessionManager;
    private final SimpMessagingTemplate messagingTemplate;

    public LobbyServiceImpl(SessionRepository sessionRepository,
                            WorldRepository worldRepository,
                            PlayerWorldStateRepository playerStateRepository,
                            PlayerProgressionRepository playerProgressionRepository,
                            QuestRepository questRepository,
                            BossEncounterRepository bossEncounterRepository,
                            EnemySessionManager enemySessionManager,
                            SimpMessagingTemplate messagingTemplate) {
        this.sessionRepository = sessionRepository;
        this.worldRepository = worldRepository;
        this.playerStateRepository = playerStateRepository;
        this.playerProgressionRepository = playerProgressionRepository;
        this.questRepository = questRepository;
        this.bossEncounterRepository = bossEncounterRepository;
        this.enemySessionManager = enemySessionManager;
        this.messagingTemplate = messagingTemplate;
    }

    @Override
    public LobbyResponse createSession(CreateLobbyRequest request) {
        // Auto-create the world if it doesn't exist yet.
        // Unity may send "WORLD_DEFAULT" before the first save — this ensures
        // the lobby can be created without requiring a prior world save.
        ensureWorldExists(request.getWorldId(), request.getOwnerId());

        // Generate a unique join key (retry if collision — extremely unlikely)
        String joinKey;
        int attempts = 0;
        do {
            joinKey = generateJoinKey();
            attempts++;
            if (attempts > 10) {
                throw GameException.badRequest("JOIN_KEY_EXHAUSTED",
                        "Could not generate a unique join key — please try again");
            }
        } while (sessionRepository.findByJoinKey(joinKey).isPresent());

        String sessionId = "SESS_" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        SessionEntity session = SessionEntity.builder()
                .sessionId(sessionId)
                .joinKey(joinKey)
                .status(AppConstants.STATUS_WAITING)
                .ownerId(request.getOwnerId())
                .worldId(request.getWorldId())
                .hostCurrentScene(request.getCurrentScene())
                .build();

        sessionRepository.save(session);

        log.info("[Lobby] Session created: id={} joinKey={} ownerId={} worldId={}",
                sessionId, joinKey, request.getOwnerId(), request.getWorldId());

        return toResponse(session);
    }

    @Override
    public LobbyResponse joinSession(JoinLobbyRequest request) {
        SessionEntity session = sessionRepository.findByJoinKey(request.getJoinKey())
                .orElseThrow(() -> GameException.notFound("JOIN_KEY_INVALID",
                        "No session found with join key: " + request.getJoinKey()));

        if (!AppConstants.STATUS_WAITING.equals(session.getStatus())) {
            // Phase 6: If the session is already ACTIVE and THIS guest is the
            // registered guest, allow re-join after verifying the host is still
            // alive (recent activity within last 60 seconds).
            if (AppConstants.STATUS_ACTIVE.equals(session.getStatus())
                    && request.getGuestId().equals(session.getGuestId())) {
                // Verify host liveness: if the host hasn't sent any message in
                // the last 60 seconds, the host is probably gone (crash, quit
                // without HOST_DIED). Reject rejoin so the guest doesn't enter
                // a dead world.
                if (session.getLastActivity() != null) {
                    long secondsSinceActivity = java.time.Duration.between(
                            session.getLastActivity(), java.time.LocalDateTime.now()).getSeconds();
                    if (secondsSinceActivity > 60) {
                        log.warn("[Lobby] Guest {} rejoin REJECTED for session {} — host inactive for {}s",
                                request.getGuestId(), session.getSessionId(), secondsSinceActivity);
                        throw GameException.badRequest("HOST_INACTIVE",
                                "The host appears to be disconnected. Please try creating a new session.");
                    }
                }
                log.info("[Lobby] Guest {} re-joining ACTIVE session {} — host active, rejoin allowed",
                        request.getGuestId(), session.getSessionId());
                return toResponse(session);
            }
            throw GameException.badRequest("SESSION_NOT_WAITING",
                    "Session is not accepting join requests. Current status: " + session.getStatus());
        }

        if (session.getGuestId() != null) {
            // Idempotent: if the SAME guest is retrying (e.g. after a WebSocket
            // reconnect), return success instead of an error.  Only reject if a
            // DIFFERENT player already occupies the guest slot.
            if (session.getGuestId().equals(request.getGuestId())) {
                log.info("[Lobby] Guest {} re-joining session {} — already registered, returning success",
                        request.getGuestId(), session.getSessionId());
                return toResponse(session);
            }
            throw GameException.badRequest("SESSION_FULL",
                    "This session already has a guest player");
        }

        if (session.getOwnerId().equals(request.getGuestId())) {
            throw GameException.badRequest("SELF_JOIN",
                    "You cannot join your own session");
        }

        session.setGuestId(request.getGuestId());
        sessionRepository.save(session);

        log.info("[Lobby] Guest joined: sessionId={} guestId={}", session.getSessionId(), request.getGuestId());

        return toResponse(session);
    }

    @Override
    public LobbyResponse getSessionStatus(String sessionId) {
        SessionEntity session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> GameException.notFound("SESSION_NOT_FOUND",
                        "Session " + sessionId + " does not exist"));

        return toResponse(session);
    }

    @Override
    public LobbyResponse startSession(String sessionId, Long ownerId) {
        SessionEntity session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> GameException.notFound("SESSION_NOT_FOUND",
                        "Session " + sessionId + " does not exist"));

        if (!session.getOwnerId().equals(ownerId)) {
            throw GameException.badRequest("NOT_OWNER",
                    "Only the session owner can start the session");
        }

        if (!AppConstants.STATUS_WAITING.equals(session.getStatus())) {
            throw GameException.badRequest("ALREADY_ACTIVE",
                    "Session is already " + session.getStatus() + " — cannot start");
        }

        session.setStatus(AppConstants.STATUS_ACTIVE);
        sessionRepository.save(session);

        log.info("[Lobby] Session started: sessionId={} status=ACTIVE", sessionId);

        // Start server-side enemy management for this session
        Set<Long> playerIds = new java.util.HashSet<>();
        playerIds.add(session.getOwnerId());
        if (session.getGuestId() != null) playerIds.add(session.getGuestId());
        enemySessionManager.onSessionActive(sessionId, session.getWorldId(), playerIds);

        // Broadcast SESSION_READY with the host's ACTUAL current scene
        // (from the CreateLobby request, stored in the session) rather than
        // the DB value which may be stale from a previous save.
        String hostScene = session.getHostCurrentScene();
        if (hostScene == null || hostScene.isEmpty()) {
            hostScene = playerStateRepository
                    .findByPlayerIdAndWorldId(session.getOwnerId(), session.getWorldId())
                    .map(PlayerWorldStateEntity::getCurrentScene)
                    .orElse("Interior_02");
        }

        WebSocketMessage readyMsg = WebSocketMessage.builder()
                .type(AppConstants.MSG_SESSION_READY)
                .sessionId(sessionId)
                .senderId(0L) // 0 = server
                .payload(hostScene) // scene name the guest should load
                .timestamp(System.currentTimeMillis())
                .build();
        messagingTemplate.convertAndSend(
                AppConstants.WS_TOPIC_SESSION + sessionId, readyMsg);
        log.info("[Lobby] SESSION_READY broadcast to /topic/session/{} with hostScene={}", sessionId, hostScene);

        return toResponse(session);
    }

    @Override
    public void closeSession(String sessionId) {
        SessionEntity session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> GameException.notFound("SESSION_NOT_FOUND",
                        "Session " + sessionId + " does not exist"));

        session.setStatus(AppConstants.STATUS_CLOSED);
        sessionRepository.save(session);

        // Stop server-side enemy management for this session
        enemySessionManager.onSessionClosed(sessionId, session.getWorldId());

        log.info("[Lobby] Session closed: sessionId={}", sessionId);
    }

    // -- Helpers --

    /**
     * Auto-creates a world and its dependent rows if they don't exist yet.
     * Mirrors {@link GameSaveServiceImpl#ensureWorldExists} so the lobby
     * flow works even when Unity sends "WORLD_DEFAULT" before the first save.
     */
    private void ensureWorldExists(String worldId, Long ownerId) {
        if (worldRepository.existsById(worldId)) {
            return;
        }

        log.info("[Lobby] Auto-creating world: id={} ownerId={}", worldId, ownerId);
        worldRepository.save(WorldEntity.builder()
                .id(worldId)
                .ownerId(ownerId)
                .worldName("Auto-created on lobby create")
                .build());

        // Bootstrap default rows for subsystems that reference this world
        if (playerStateRepository.findByPlayerIdAndWorldId(ownerId, worldId).isEmpty()) {
            playerStateRepository.save(PlayerWorldStateEntity.builder()
                    .playerId(ownerId).worldId(worldId).build());
        }
        if (playerProgressionRepository.findByPlayerIdAndWorldId(ownerId, worldId).isEmpty()) {
            playerProgressionRepository.save(PlayerProgressionEntity.builder()
                    .playerId(ownerId).worldId(worldId).build());
        }
        if (questRepository.findByWorldIdAndQuestId(worldId, "sara_village").isEmpty()) {
            questRepository.save(QuestEntity.builder()
                    .worldId(worldId).questId("sara_village").build());
        }
        if (questRepository.findByWorldIdAndQuestId(worldId, "quest2").isEmpty()) {
            questRepository.save(QuestEntity.builder()
                    .worldId(worldId).questId("quest2")
                    .questState(0).zombiesRemaining(0).isBossAlive(false).build());
        }
        if (bossEncounterRepository.findByWorldId(worldId).isEmpty()) {
            bossEncounterRepository.save(BossEncounterEntity.builder()
                    .worldId(worldId).build());
        }
    }

    private String generateJoinKey() {
        StringBuilder sb = new StringBuilder(JOIN_KEY_LENGTH);
        for (int i = 0; i < JOIN_KEY_LENGTH; i++) {
            sb.append(ALPHANUMERIC.charAt(RANDOM.nextInt(ALPHANUMERIC.length())));
        }
        return sb.toString();
    }

    private LobbyResponse toResponse(SessionEntity session) {
        return LobbyResponse.builder()
                .sessionId(session.getSessionId())
                .joinKey(session.getJoinKey())
                .status(session.getStatus())
                .ownerId(session.getOwnerId())
                .guestId(session.getGuestId())
                .worldId(session.getWorldId())
                .hostScene(session.getHostCurrentScene())
                .build();
    }
}
