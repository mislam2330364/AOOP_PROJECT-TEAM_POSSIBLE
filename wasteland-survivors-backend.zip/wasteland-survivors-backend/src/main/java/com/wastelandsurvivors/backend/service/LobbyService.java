package com.wastelandsurvivors.backend.service;

import com.wastelandsurvivors.backend.dto.request.CreateLobbyRequest;
import com.wastelandsurvivors.backend.dto.request.JoinLobbyRequest;
import com.wastelandsurvivors.backend.dto.response.LobbyResponse;

/**
 * Declares multiplayer lobby management capabilities.
 * A session has a defined lifecycle: WAITING -> ACTIVE -> CLOSED.
 * WAITING: session exists, guest has not yet joined.
 * ACTIVE:  both players confirmed, game world is running.
 * CLOSED:  session ended, world state should already be saved.
 * Implementations of this interface enforce this lifecycle.
 */
public interface LobbyService {

    /**
     * Creates a new multiplayer session for the given world.
     * Generates a unique 6-character alphanumeric join key for the owner to share.
     * @param request Contains worldId of the world to open and ownerId of the hosting player
     * @return LobbyResponse containing the new sessionId, the generated joinKey, and WAITING status
     */
    LobbyResponse createSession(CreateLobbyRequest request);

    /**
     * Registers a guest player into an existing session using the shared join key.
     * The session must be in WAITING status for this to succeed.
     * @param request Contains the joinKey and the guestId of the joining player
     * @return LobbyResponse with updated session state including the guest's ID
     */
    LobbyResponse joinSession(JoinLobbyRequest request);

    /**
     * Returns the current status of a session without modifying it.
     * Unity polls this every 2 seconds on the lobby waiting screen.
     * When the returned status equals AppConstants.STATUS_ACTIVE, Unity loads the game world.
     * @param sessionId The unique ID of the session to query
     * @return LobbyResponse with the current status, owner ID, and guest ID
     */
    LobbyResponse getSessionStatus(String sessionId);

    /**
     * Transitions a session from WAITING to ACTIVE status.
     * Only the session owner is permitted to call this.
     * Both players detect the ACTIVE status on their next poll and load the game world.
     * @param sessionId The session to start
     * @param ownerId   The ID of the owner — used to verify the caller has permission
     * @return LobbyResponse with ACTIVE status
     */
    LobbyResponse startSession(String sessionId, Long ownerId);

    /**
     * Transitions a session to CLOSED status.
     * World state must be saved before calling this method.
     * Called when a player disconnects or both players exit the game.
     * @param sessionId The session to close
     */
    void closeSession(String sessionId);
}

