package com.wastelandsurvivors.backend.service;

import com.wastelandsurvivors.backend.dto.game.InventoryDTO;

/**
 * Declares inventory persistence capabilities.
 * Implementation stores and loads inventory data for a player and world.
 */
public interface InventoryService {

    /**
     * Loads a player's inventory for the given world.
     * @param playerId Player ID
     * @param worldId  World ID
     * @return InventoryDTO containing items (empty list if none)
     */
    InventoryDTO getInventory(Long playerId, String worldId);

    /**
     * Saves a player's inventory for the given world.
     * @param playerId Player ID
     * @param inventory Inventory payload
     * @return Saved InventoryDTO
     */
    InventoryDTO saveInventory(Long playerId, InventoryDTO inventory);

    /**
     * Removes a specific quantity of an item from the player's inventory.
     * If the quantity reaches 0 or below, the item is fully removed.
     * Called when a player drops an item from their inventory (Q key / right-click).
     *
     * @param playerId Player ID
     * @param worldId  World ID
     * @param itemName The item name to remove
     * @param quantity How many to remove (typically 1 for a drop)
     * @return Updated InventoryDTO after removal
     */
    InventoryDTO removeItem(Long playerId, String worldId, String itemName, int quantity);
}

