package com.wastelandsurvivors.backend.repository;

import com.wastelandsurvivors.backend.entity.FriendEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * JPA repository for {@link FriendEntity} — friend relationship persistence.
 */
@Repository
public interface FriendRepository extends JpaRepository<FriendEntity, Long> {

    /**
     * Returns all friends for a player.
     * @param playerId The player whose friends to retrieve
     * @return List of friend relationships (may be empty)
     */
    List<FriendEntity> findByPlayerId(Long playerId);

    /**
     * Finds a specific friendship by both player IDs.
     * @param playerId The player who added the friend
     * @param friendId The friend who was added
     * @return The friendship if it exists
     */
    Optional<FriendEntity> findByPlayerIdAndFriendId(Long playerId, Long friendId);

    /**
     * Checks whether a friendship exists.
     * @param playerId The player
     * @param friendId The friend
     * @return true if the friendship exists
     */
    boolean existsByPlayerIdAndFriendId(Long playerId, Long friendId);

    /**
     * Deletes a specific friendship.
     * @param playerId The player
     * @param friendId The friend to remove
     */
    @Transactional
    void deleteByPlayerIdAndFriendId(Long playerId, Long friendId);
}
