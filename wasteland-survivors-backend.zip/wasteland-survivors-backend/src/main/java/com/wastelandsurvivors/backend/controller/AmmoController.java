package com.wastelandsurvivors.backend.controller;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.service.AmmoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST Controller for player ammunition management.
 * Tracks clip ammo and reserve per player per world.
 */
@RestController
@RequestMapping(AppConstants.API_V1 + "/players")
@Slf4j
public class AmmoController {

    private final AmmoService ammoService;

    public AmmoController(AmmoService ammoService) {
        this.ammoService = ammoService;
    }

    /**
     * Returns current ammo state for a player in a world.
     * GET /api/v1/players/{playerId}/ammo?worldId=...
     */
    @GetMapping("/{playerId}/ammo")
    public ResponseEntity<?> getAmmo(@PathVariable Long playerId,
                                      @RequestParam String worldId) {
        log.debug("[AmmoController] GET /{}/ammo?worldId={}", playerId, worldId);
        return ResponseEntity.ok(ammoService.getAmmo(playerId, worldId));
    }

    /**
     * Consumes one bullet from the clip (fired a shot).
     * POST /api/v1/players/{playerId}/ammo/consume?worldId=...
     */
    @PostMapping("/{playerId}/ammo/consume")
    public ResponseEntity<?> consumeBullet(@PathVariable Long playerId,
                                            @RequestParam String worldId) {
        log.debug("[AmmoController] POST /{}/ammo/consume?worldId={}", playerId, worldId);
        return ResponseEntity.ok(ammoService.consumeBullet(playerId, worldId));
    }

    /**
     * Reloads the clip from reserve.
     * POST /api/v1/players/{playerId}/ammo/reload?worldId=...
     */
    @PostMapping("/{playerId}/ammo/reload")
    public ResponseEntity<?> reload(@PathVariable Long playerId,
                                     @RequestParam String worldId) {
        log.info("[AmmoController] POST /{}/ammo/reload?worldId={}", playerId, worldId);
        return ResponseEntity.ok(ammoService.reload(playerId, worldId));
    }

    /**
     * Adds bullets to the player's reserve (ammo pickup).
     * POST /api/v1/players/{playerId}/ammo/add?worldId=...&amount=...
     */
    @PostMapping("/{playerId}/ammo/add")
    public ResponseEntity<?> addAmmo(@PathVariable Long playerId,
                                      @RequestParam String worldId,
                                      @RequestParam int amount) {
        log.info("[AmmoController] POST /{}/ammo/add?worldId={}&amount={}", playerId, worldId, amount);
        return ResponseEntity.ok(ammoService.addAmmo(playerId, worldId, amount));
    }
}
