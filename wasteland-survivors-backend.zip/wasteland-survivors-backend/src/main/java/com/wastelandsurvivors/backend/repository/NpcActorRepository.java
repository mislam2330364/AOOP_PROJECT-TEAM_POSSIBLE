package com.wastelandsurvivors.backend.repository;

import com.wastelandsurvivors.backend.entity.NpcActorEntity;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Spring Data JPA repository for {@link NpcActorEntity} (npc_actors table).
 */
public interface NpcActorRepository extends JpaRepository<NpcActorEntity, String> {
}
