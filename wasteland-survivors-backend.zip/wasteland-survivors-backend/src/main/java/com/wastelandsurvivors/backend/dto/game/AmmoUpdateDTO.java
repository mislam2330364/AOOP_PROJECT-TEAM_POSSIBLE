package com.wastelandsurvivors.backend.dto.game;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Carries a player's ammunition state update during a multiplayer session.
 * Sent over WebSocket when the player fires, reloads, or picks up ammo,
 * wrapped inside a WebSocketMessage with type {@code AMMO_UPDATE}.
 * (Both directions)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AmmoUpdateDTO {

    /** The player whose ammo state is being reported */
    private long playerId;

    /** The session this update belongs to */
    private String sessionId;

    /** Current bullets in the magazine */
    private int currentClip;

    /** Maximum magazine capacity */
    private int maxClipSize;

    /** Total bullets in reserve (not in magazine) */
    private int totalAmmoReserve;

    /** Unix time in milliseconds when this update was captured in Unity */
    private long timestamp;
}
