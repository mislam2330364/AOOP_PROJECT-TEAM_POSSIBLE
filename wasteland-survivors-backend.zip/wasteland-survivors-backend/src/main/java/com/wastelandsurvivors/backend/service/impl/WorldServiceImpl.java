package com.wastelandsurvivors.backend.service.impl;

import com.wastelandsurvivors.backend.entity.BossEncounterEntity;
import com.wastelandsurvivors.backend.entity.PlayerProgressionEntity;
import com.wastelandsurvivors.backend.entity.PlayerWorldStateEntity;
import com.wastelandsurvivors.backend.entity.QuestEntity;
import com.wastelandsurvivors.backend.entity.WorldEntity;
import com.wastelandsurvivors.backend.exception.GameException;
import com.wastelandsurvivors.backend.repository.BossEncounterRepository;
import com.wastelandsurvivors.backend.repository.PlayerProgressionRepository;
import com.wastelandsurvivors.backend.repository.PlayerRepository;
import com.wastelandsurvivors.backend.repository.PlayerWorldStateRepository;
import com.wastelandsurvivors.backend.repository.QuestRepository;
import com.wastelandsurvivors.backend.repository.WorldRepository;
import com.wastelandsurvivors.backend.service.WorldService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.UUID;

/**
 * Full implementation of {@link WorldService} backed by JPA.
 *
 * <p>Creating a world also bootstraps all dependent state rows:
 * player_world_state, player_progression, quests, and boss_encounters.
 * This ensures the world is immediately ready for gameplay.</p>
 */
@Service
@Slf4j
public class WorldServiceImpl implements WorldService {

    private final WorldRepository worldRepository;
    private final PlayerRepository playerRepository;
    private final PlayerWorldStateRepository playerWorldStateRepository;
    private final PlayerProgressionRepository playerProgressionRepository;
    private final QuestRepository questRepository;
    private final BossEncounterRepository bossEncounterRepository;

    public WorldServiceImpl(WorldRepository worldRepository,
                            PlayerRepository playerRepository,
                            PlayerWorldStateRepository playerWorldStateRepository,
                            PlayerProgressionRepository playerProgressionRepository,
                            QuestRepository questRepository,
                            BossEncounterRepository bossEncounterRepository) {
        this.worldRepository = worldRepository;
        this.playerRepository = playerRepository;
        this.playerWorldStateRepository = playerWorldStateRepository;
        this.playerProgressionRepository = playerProgressionRepository;
        this.questRepository = questRepository;
        this.bossEncounterRepository = bossEncounterRepository;
    }

    @Override
    public String createWorld(Long ownerId, String worldName) {
        if (!playerRepository.existsById(ownerId)) {
            throw GameException.notFound("PLAYER_NOT_FOUND",
                    "Player " + ownerId + " does not exist");
        }

        // ONE WORLD PER PLAYER: if the player already has a world, return it
        // instead of creating a new one. This prevents world proliferation
        // (18 rows in the DB from repeated "Start Game" clicks) and ensures
        // every save/load always targets the same world.
        var existingWorld = worldRepository.findFirstByOwnerId(ownerId);
        if (existingWorld.isPresent()) {
            String existingId = existingWorld.get().getId();
            log.info("[World] Player {} already has world {} — reusing existing world.", ownerId, existingId);
            return existingId;
        }

        // Generate a unique world ID
        String worldId = "WORLD_" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        // 1. Create the world
        WorldEntity world = WorldEntity.builder()
                .id(worldId)
                .ownerId(ownerId)
                .worldName(worldName)
                .build();
        worldRepository.save(world);

        // 2. Create default player world state
        PlayerWorldStateEntity defaultState = PlayerWorldStateEntity.builder()
                .playerId(ownerId)
                .worldId(worldId)
                .build();
        playerWorldStateRepository.save(defaultState);

        // 3. Create default player progression
        PlayerProgressionEntity progression = PlayerProgressionEntity.builder()
                .playerId(ownerId)
                .worldId(worldId)
                .build();
        playerProgressionRepository.save(progression);

        // 4. Create default quest record
        QuestEntity quest = QuestEntity.builder()
                .worldId(worldId)
                .build();
        questRepository.save(quest);

        // 5. Create default boss encounter record
        BossEncounterEntity boss = BossEncounterEntity.builder()
                .worldId(worldId)
                .build();
        bossEncounterRepository.save(boss);

        log.info("[World] Created new world: id={} name='{}' ownerId={}", worldId, worldName, ownerId);

        return worldId;
    }

    @Override
    public Map<String, Object> getWorld(String worldId, Long playerId) {
        WorldEntity world = worldRepository.findById(worldId)
                .orElseThrow(() -> GameException.notFound("WORLD_NOT_FOUND",
                        "World " + worldId + " does not exist"));

        PlayerWorldStateEntity state = playerWorldStateRepository
                .findByPlayerIdAndWorldId(playerId, worldId)
                .orElse(null);

        QuestEntity quest = questRepository.findByWorldIdAndQuestId(worldId, "sara_village").orElse(null);
        BossEncounterEntity boss = bossEncounterRepository.findByWorldId(worldId).orElse(null);

        return Map.of(
                "worldId", world.getId(),
                "worldName", world.getWorldName(),
                "ownerId", world.getOwnerId(),
                "playerState", state != null ? state : "not found",
                "quest", quest != null ? quest : "not found",
                "boss", boss != null ? boss : "not found"
        );
    }

    @Override
    public void saveWorld(String worldId, Long playerId, Map<String, Object> worldData) {
        if (!worldRepository.existsById(worldId)) {
            throw GameException.notFound("WORLD_NOT_FOUND",
                    "World " + worldId + " does not exist");
        }

        // Save player world state if present in the payload
        PlayerWorldStateEntity state = playerWorldStateRepository
                .findByPlayerIdAndWorldId(playerId, worldId)
                .orElse(PlayerWorldStateEntity.builder()
                        .playerId(playerId)
                        .worldId(worldId)
                        .build());

        if (worldData.containsKey("currentHealth")) {
            state.setCurrentHealth((int) worldData.get("currentHealth"));
        }
        if (worldData.containsKey("maxHealth")) {
            state.setMaxHealth((int) worldData.get("maxHealth"));
        }
        if (worldData.containsKey("damage")) {
            state.setDamage(((Number) worldData.get("damage")).floatValue());
        }
        if (worldData.containsKey("weaponRange")) {
            state.setWeaponRange(((Number) worldData.get("weaponRange")).floatValue());
        }
        if (worldData.containsKey("speed")) {
            state.setSpeed(((Number) worldData.get("speed")).floatValue());
        }
        if (worldData.containsKey("positionX")) {
            state.setPositionX(((Number) worldData.get("positionX")).floatValue());
        }
        if (worldData.containsKey("positionY")) {
            state.setPositionY(((Number) worldData.get("positionY")).floatValue());
        }
        if (worldData.containsKey("facingDirection")) {
            state.setFacingDirection((int) worldData.get("facingDirection"));
        }
        if (worldData.containsKey("currentScene")) {
            state.setCurrentScene((String) worldData.get("currentScene"));
        }

        playerWorldStateRepository.save(state);
        log.info("[World] Saved world state: worldId={} playerId={}", worldId, playerId);
    }
}
