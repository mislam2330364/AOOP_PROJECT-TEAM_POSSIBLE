package com.wastelandsurvivors.backend.dto.game;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Represents a single item stack in a player's inventory. This is a child object nested inside InventoryDTO.
 * Inventory is not yet built in Unity — this DTO is defined now so the contract exists and no changes are needed
 * when inventory is implemented. (Both directions)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InventoryItemDTO {

    // A unique identifier for the item type, e.g. MEDKIT, AMMO_PISTOL, SCRAP_METAL.
    private String itemId;

    // Human-readable display name, e.g. "Med Kit", "Pistol Ammo".
    private String itemName;

    // Description text shown in the inventory UI
    private String itemDescription;

    // Sprite identifier used by Unity to render the item
    private String spriteName;

    // How many of this item the player is carrying
    private int quantity;
}

