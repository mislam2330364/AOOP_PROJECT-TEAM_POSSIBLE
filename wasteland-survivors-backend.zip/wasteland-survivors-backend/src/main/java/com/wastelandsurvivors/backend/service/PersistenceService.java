package com.wastelandsurvivors.backend.service;

import java.util.List;

/**
 * Declares persistent object tracking capabilities.
 * Tracks which destructible/collectible objects have been removed
 * in a world so they don't respawn on scene reload.
 */
public interface PersistenceService {

    /**
     * Returns all destroyed object IDs for a world.
     *
     * @param worldId The world
     * @return List of unique object IDs that have been destroyed
     */
    List<String> getDestroyedObjects(String worldId);

    /**
     * Checks whether a specific object has been destroyed in a world.
     *
     * @param worldId        The world
     * @param objectUniqueId The object's unique ID (from ScenePersistentObject)
     * @return true if the object is marked as destroyed
     */
    boolean isObjectDestroyed(String worldId, String objectUniqueId);

    /**
     * Marks an object as destroyed in a world.
     * Idempotent — calling this on an already-destroyed object is a no-op.
     *
     * @param worldId        The world
     * @param objectUniqueId The object's unique ID
     */
    void markObjectDestroyed(String worldId, String objectUniqueId);
}
