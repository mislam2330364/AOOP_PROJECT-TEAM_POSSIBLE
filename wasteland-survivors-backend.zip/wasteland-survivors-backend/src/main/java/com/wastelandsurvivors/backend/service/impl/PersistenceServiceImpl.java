package com.wastelandsurvivors.backend.service.impl;

import com.wastelandsurvivors.backend.entity.PersistentObjectEntity;
import com.wastelandsurvivors.backend.repository.PersistentObjectRepository;
import com.wastelandsurvivors.backend.service.PersistenceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Full implementation of {@link PersistenceService}.
 * Tracks destroyed/collected objects per world so they don't respawn.
 */
@Service
@Slf4j
public class PersistenceServiceImpl implements PersistenceService {

    private final PersistentObjectRepository persistentObjectRepository;

    public PersistenceServiceImpl(PersistentObjectRepository persistentObjectRepository) {
        this.persistentObjectRepository = persistentObjectRepository;
    }

    @Override
    public List<String> getDestroyedObjects(String worldId) {
        return persistentObjectRepository.findByWorldId(worldId).stream()
                .map(PersistentObjectEntity::getObjectUniqueId)
                .collect(Collectors.toList());
    }

    @Override
    public boolean isObjectDestroyed(String worldId, String objectUniqueId) {
        return persistentObjectRepository.existsByWorldIdAndObjectUniqueId(worldId, objectUniqueId);
    }

    @Override
    public void markObjectDestroyed(String worldId, String objectUniqueId) {
        if (persistentObjectRepository.existsByWorldIdAndObjectUniqueId(worldId, objectUniqueId)) {
            log.debug("[Persistence] Object already marked destroyed: worldId={} objectId={}",
                    worldId, objectUniqueId);
            return; // Idempotent — already destroyed
        }

        PersistentObjectEntity record = PersistentObjectEntity.builder()
                .worldId(worldId)
                .objectUniqueId(objectUniqueId)
                .isDestroyed(true)
                .build();
        persistentObjectRepository.save(record);

        log.info("[Persistence] Object marked destroyed: worldId={} objectId={}",
                worldId, objectUniqueId);
    }
}
