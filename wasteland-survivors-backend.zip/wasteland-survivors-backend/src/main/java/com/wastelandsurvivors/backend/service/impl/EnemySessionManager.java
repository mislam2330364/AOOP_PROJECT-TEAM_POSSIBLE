package com.wastelandsurvivors.backend.service.impl;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.dto.game.*;
import com.wastelandsurvivors.backend.entity.EnemyInstanceEntity;
import com.wastelandsurvivors.backend.entity.EnemyTypeEntity;
import com.wastelandsurvivors.backend.entity.PlayerWorldStateEntity;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.dto.game.*;
import com.wastelandsurvivors.backend.entity.EnemyInstanceEntity;
import com.wastelandsurvivors.backend.entity.EnemyTypeEntity;
import com.wastelandsurvivors.backend.entity.PlayerWorldStateEntity;
import com.wastelandsurvivors.backend.repository.EnemyInstanceRepository;
import com.wastelandsurvivors.backend.repository.EnemyTypeRepository;
import com.wastelandsurvivors.backend.repository.PlayerWorldStateRepository;
import com.wastelandsurvivors.backend.service.EnemyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.*;

/**
 * Server-side enemy authority per multiplayer session.
 *
 * <p>When a session becomes ACTIVE, this manager spawns a wave of enemies
 * and runs a simple AI loop: enemies target the closest player, move toward
 * them, and attack when in range. State is broadcast to both clients via
 * the session topic so all players see the same enemies.</p>
 *
 * <p>This replaces the host-authoritative model where the host client ran
 * enemy AI independently. With this manager, the server is the single
 * source of truth for enemy lifecycle, targeting, and damage.</p>
 */
@Service
@Slf4j
public class EnemySessionManager {

    private final EnemyService enemyService;
    private final EnemyTypeRepository enemyTypeRepository;
    private final EnemyInstanceRepository enemyInstanceRepository;
    private final PlayerWorldStateRepository playerStateRepository;
    private final SimpMessagingTemplate messagingTemplate;
    private final ObjectMapper objectMapper;

    /** Per-session scheduled executor for the AI loop. */
    private final Map<String, ScheduledFuture<?>> sessionLoops = new ConcurrentHashMap<>();
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(4);

    /** How many enemies to spawn when a session starts.
     * Set to 0 for now — server-side enemy AI needs proper client prefab
     * integration before it can spawn visible, fair enemies.  The host's
     * local enemies (from the game world) handle combat. */
    private static final int INITIAL_ENEMY_COUNT = 0;
    /** Delay before first enemy spawn (ms) — gives players time to orient. */
    private static final long INITIAL_SPAWN_DELAY_MS = 5000;
    /** AI tick interval in milliseconds. */
    private static final long AI_TICK_MS = 250;
    /** How close an enemy must be to attack a player. */
    private static final float ATTACK_RANGE = 1.5f;
    /** Cooldown between enemy attacks in milliseconds. */
    private static final long ATTACK_COOLDOWN_MS = 3000;

    public EnemySessionManager(EnemyService enemyService,
                               EnemyTypeRepository enemyTypeRepository,
                               EnemyInstanceRepository enemyInstanceRepository,
                               PlayerWorldStateRepository playerStateRepository,
                               SimpMessagingTemplate messagingTemplate,
                               ObjectMapper objectMapper) {
        this.enemyService = enemyService;
        this.enemyTypeRepository = enemyTypeRepository;
        this.enemyInstanceRepository = enemyInstanceRepository;
        this.playerStateRepository = playerStateRepository;
        this.messagingTemplate = messagingTemplate;
        this.objectMapper = objectMapper;
    }

    /**
     * Called when a session transitions to ACTIVE.
     * Spawns initial enemies and starts the AI loop.
     */
    public void onSessionActive(String sessionId, String worldId, Set<Long> playerIds) {
        log.info("[EnemySessionManager] Session {} ACTIVE — spawning {} enemies for world {}",
                sessionId, INITIAL_ENEMY_COUNT, worldId);

        // Spawn initial wave
        List<EnemyTypeEntity> types = enemyTypeRepository.findAll();
        if (types.isEmpty()) {
            log.warn("[EnemySessionManager] No enemy types in catalog — cannot spawn enemies");
            return;
        }

        // Filter to non-boss types for initial wave
        List<EnemyTypeEntity> normalTypes = types.stream()
                .filter(t -> !t.isBoss())
                .toList();

        if (normalTypes.isEmpty()) normalTypes = types;

        Random rng = new Random();
        for (int i = 0; i < INITIAL_ENEMY_COUNT; i++) {
            EnemyTypeEntity type = normalTypes.get(rng.nextInt(normalTypes.size()));
            float x = -5f + rng.nextFloat() * 10f;  // spread across -5 to +5
            float y = -2f + rng.nextFloat() * 4f;    // spread across -2 to +2
            EnemyInstanceEntity enemy = enemyService.spawnEnemy(worldId, type.getTypeId(), x, y);

            // Broadcast spawn to all session subscribers
            broadcastEnemySpawn(sessionId, enemy, type.getTypeId());
        }

        // Start AI loop only if enemies were actually spawned.
        if (INITIAL_ENEMY_COUNT > 0) {
            ScheduledFuture<?> loop = scheduler.scheduleAtFixedRate(
                    () -> aiTick(sessionId, worldId, playerIds),
                    INITIAL_SPAWN_DELAY_MS, AI_TICK_MS, TimeUnit.MILLISECONDS);
            sessionLoops.put(sessionId, loop);
            log.info("[EnemySessionManager] AI loop started for session {}", sessionId);
        } else {
            log.info("[EnemySessionManager] AI loop SKIPPED for session {} (INITIAL_ENEMY_COUNT=0)", sessionId);
        }
    }

    /**
     * Called when a session ends (CLOSED or player disconnects).
     * Stops the AI loop and cleans up enemies.
     */
    public void onSessionClosed(String sessionId, String worldId) {
        log.info("[EnemySessionManager] Session {} CLOSED — stopping AI loop", sessionId);

        ScheduledFuture<?> loop = sessionLoops.remove(sessionId);
        if (loop != null) {
            loop.cancel(false);
        }

        // Mark all alive enemies in this world as dead
        List<EnemyInstanceEntity> alive = enemyInstanceRepository.findByWorldIdAndIsAlive(worldId, true);
        for (EnemyInstanceEntity enemy : alive) {
            enemy.setAlive(false);
            enemyInstanceRepository.save(enemy);

            // Broadcast despawn
            EnemyLifecycleDTO despawn = EnemyLifecycleDTO.builder()
                    .enemyId(enemy.getEnemyId())
                    .sessionId(sessionId)
                    .enemyType(enemy.getTypeId())
                    .x(enemy.getPositionX())
                    .y(enemy.getPositionY())
                    .timestamp(System.currentTimeMillis())
                    .build();
            broadcast(sessionId, AppConstants.MSG_ENEMY_DESPAWN, despawn);
        }

        log.info("[EnemySessionManager] Cleaned up {} enemies for session {}", alive.size(), sessionId);
    }

    // =========================================================================
    // AI Tick
    // =========================================================================

    private void aiTick(String sessionId, String worldId, Set<Long> playerIds) {
        try {
            // If no AI loop was scheduled (INITIAL_ENEMY_COUNT=0) but this
            // method is somehow called, exit cleanly.
            if (!sessionLoops.containsKey(sessionId)) return;

            List<EnemyInstanceEntity> enemies = enemyInstanceRepository.findByWorldIdAndIsAlive(worldId, true);
            if (enemies.isEmpty()) return;

            // Get all player positions for this session
            Map<Long, PlayerWorldStateEntity> players = new HashMap<>();
            for (Long pid : playerIds) {
                playerStateRepository.findByPlayerIdAndWorldId(pid, worldId)
                        .ifPresent(state -> players.put(pid, state));
            }

            if (players.isEmpty()) return;

            // Last attack time per enemy (in-memory, keyed by enemyId)
            // For production this should be a ConcurrentHashMap field.
            // For now we use a simple approach: enemies attack if a player is in range.

            for (EnemyInstanceEntity enemy : enemies) {
                // Find closest player
                PlayerWorldStateEntity closestPlayer = null;
                float closestDist = Float.MAX_VALUE;

                for (PlayerWorldStateEntity player : players.values()) {
                    float dx = enemy.getPositionX() - player.getPositionX();
                    float dy = enemy.getPositionY() - player.getPositionY();
                    float dist = (float) Math.sqrt(dx * dx + dy * dy);
                    if (dist < closestDist) {
                        closestDist = dist;
                        closestPlayer = player;
                    }
                }

                if (closestPlayer == null) continue;

                // Move toward closest player
                float dx2 = closestPlayer.getPositionX() - enemy.getPositionX();
                float dy2 = closestPlayer.getPositionY() - enemy.getPositionY();
                float dist2 = (float) Math.sqrt(dx2 * dx2 + dy2 * dy2);

                EnemyTypeEntity type = enemyTypeRepository.findById(enemy.getTypeId()).orElse(null);
                float speed = (type != null) ? type.getBaseSpeed() : 2f;
                float moveAmount = speed * (AI_TICK_MS / 1000f);

                if (dist2 > ATTACK_RANGE && dist2 > 0.01f) {
                    // Move toward player
                    float newX = enemy.getPositionX() + (dx2 / dist2) * moveAmount;
                    float newY = enemy.getPositionY() + (dy2 / dist2) * moveAmount;
                    enemy.setPositionX(newX);
                    enemy.setPositionY(newY);

                    // Update facing direction
                    int facing = (dx2 > 0) ? 1 : -1;
                    enemy.setFacingDirection(facing);
                    enemy.setEnemyState("CHASING");
                } else if (dist2 <= ATTACK_RANGE) {
                    // In attack range — broadcast the attack so clients apply
                    // damage locally.  The server does NOT modify player health
                    // directly — that caused players to die silently at spawn.
                    enemy.setEnemyState("ATTACKING");

                    int damage = (type != null) ? type.getBaseDamage() : 2;
                    EnemyActionDTO action = EnemyActionDTO.builder()
                            .enemyId(enemy.getEnemyId())
                            .sessionId(sessionId)
                            .damage(damage)
                            .attackRange(ATTACK_RANGE)
                            .attackPointX(enemy.getPositionX())
                            .attackPointY(enemy.getPositionY())
                            .timestamp(System.currentTimeMillis())
                            .build();
                    broadcast(sessionId, AppConstants.MSG_ENEMY_ACTION, action);

                    log.debug("[EnemySessionManager] Enemy {} attacking player {} — {} damage (broadcast only)",
                            enemy.getEnemyId(), closestPlayer.getPlayerId(), damage);
                } else {
                    enemy.setEnemyState("IDLE");
                }

                enemyInstanceRepository.save(enemy);

                // Broadcast position
                EnemyPositionDTO pos = EnemyPositionDTO.builder()
                        .enemyId(enemy.getEnemyId())
                        .sessionId(sessionId)
                        .x(enemy.getPositionX())
                        .y(enemy.getPositionY())
                        .facingDirection(enemy.getFacingDirection())
                        .timestamp(System.currentTimeMillis())
                        .build();
                broadcast(sessionId, AppConstants.MSG_ENEMY_POSITION, pos);
            }
        } catch (Exception e) {
            log.error("[EnemySessionManager] AI tick error for session {}: {}", sessionId, e.getMessage(), e);
        }
    }

    // =========================================================================
    // Broadcasting
    // =========================================================================

    private void broadcastEnemySpawn(String sessionId, EnemyInstanceEntity enemy, String typeId) {
        EnemyLifecycleDTO spawn = EnemyLifecycleDTO.builder()
                .enemyId(enemy.getEnemyId())
                .sessionId(sessionId)
                .enemyType(typeId)
                .x(enemy.getPositionX())
                .y(enemy.getPositionY())
                .timestamp(System.currentTimeMillis())
                .build();
        broadcast(sessionId, AppConstants.MSG_ENEMY_SPAWN, spawn);
    }

    private void broadcast(String sessionId, String type, Object payload) {
        // Serialize the DTO payload to a JSON string BEFORE wrapping it.
        // Unity's WebSocketMessage.payload is a string field; if we pass
        // the raw DTO object, Jackson serializes it as a nested JSON object
        // which Unity's JsonUtility cannot deserialize into a string field.
        String payloadJson;
        try {
            payloadJson = objectMapper.writeValueAsString(payload);
        } catch (Exception e) {
            log.error("[EnemySessionManager] Failed to serialize {} payload: {}", type, e.getMessage());
            return;
        }
        WebSocketMessage message = WebSocketMessage.builder()
                .type(type)
                .sessionId(sessionId)
                .senderId(0) // 0 = server
                .payload(payloadJson)
                .timestamp(System.currentTimeMillis())
                .build();
        messagingTemplate.convertAndSend(AppConstants.WS_TOPIC_SESSION + sessionId, message);
    }
}
