package com.wastelandsurvivors.backend.dto.game;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Carries a player's current and maximum health.
 * Sent over WebSocket when the player takes damage or heals, wrapped inside a WebSocketMessage. (Both directions)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HealthDTO {

    // The playerId of who this health belongs to — matches the playerId stored in GameAPI.cs
    private long playerId;

    // The session this health belongs to — matches sessionId in GameAPI.cs
    private String sessionId;

    // The player's current HP — sourced from currentHealth in Player_Health.cs. Send this whenever the value changes.
    private int currentHealth;

    // The player's maximum HP — sourced from maxHealth in Player_Health.cs.
    private int maxHealth;

    // Unix time in milliseconds when this health value was captured in Unity
    private long timestamp;
}
