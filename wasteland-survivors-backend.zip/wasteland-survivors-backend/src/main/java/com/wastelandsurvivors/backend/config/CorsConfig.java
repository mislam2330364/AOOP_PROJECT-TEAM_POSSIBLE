package com.wastelandsurvivors.backend.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Configures Cross-Origin Resource Sharing (CORS) for the REST layer.
 * CORS is a security rule that blocks requests from origins the server has not
 * explicitly permitted. Unity's UnityWebRequest is subject to CORS.
 * During development all origins are permitted so local testing works freely.
 * Before releasing: replace the wildcard with the specific address of your
 * deployed server — wildcard in production is a security vulnerability.
 */
@Configuration
public class CorsConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("*")
                // TODO: Replace "*" with your production server domain before release
                // Example: .allowedOrigins("https://wastelandsurvivors.yourdomain.com")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .maxAge(3600);
        // maxAge caches the CORS preflight response for 1 hour,
        // avoiding an OPTIONS request before every single API call
    }
}

