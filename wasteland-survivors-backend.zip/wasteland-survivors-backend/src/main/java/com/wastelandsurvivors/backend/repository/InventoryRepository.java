package com.wastelandsurvivors.backend.repository;

import com.wastelandsurvivors.backend.entity.InventoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface InventoryRepository extends JpaRepository<InventoryEntity, Long> {
    Optional<InventoryEntity> findByPlayerIdAndWorldId(Long playerId, String worldId);
}

