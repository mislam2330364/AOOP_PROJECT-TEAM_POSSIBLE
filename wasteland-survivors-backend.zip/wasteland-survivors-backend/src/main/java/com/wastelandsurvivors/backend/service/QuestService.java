package com.wastelandsurvivors.backend.service;

import com.wastelandsurvivors.backend.entity.QuestEntity;

/**
 * Declares quest state management per world with multi-quest support.
 * Manages the 4-state machine: 0=NotStarted → 1=Active → 2=Complete → 3=HandedIn.
 *
 * <p>Each method accepts a questId parameter to support multiple quests per world
 * (e.g., "sara_village", "quest2"). The original single-parameter overloads
 * default to "sara_village" for backward compatibility.</p>
 */
public interface QuestService {

    /**
     * Returns the current quest state for a world and quest.
     *
     * @param worldId The world
     * @param questId The quest discriminator (e.g., "sara_village", "quest2")
     * @return QuestEntity (created with defaults if none exists)
     */
    QuestEntity getQuestState(String worldId, String questId);

    /**
     * Backward-compatible overload — defaults to "sara_village".
     */
    default QuestEntity getQuestState(String worldId) {
        return getQuestState(worldId, "sara_village");
    }

    /**
     * Activates the quest — transitions state from 0 (NotStarted) to 1 (Active).
     * Only valid from state 0.
     *
     * @param worldId The world
     * @param questId The quest discriminator
     * @return Updated QuestEntity in state 1
     * @throws com.wastelandsurvivors.backend.exception.GameException if not in state 0
     */
    QuestEntity activateQuest(String worldId, String questId);

    /**
     * Backward-compatible overload — defaults to "sara_village".
     */
    default QuestEntity activateQuest(String worldId) {
        return activateQuest(worldId, "sara_village");
    }

    /**
     * Records an enemy kill against the quest objectives.
     * For Sara quest: decrements zombiesRemaining or sets isBossAlive=false.
     * For Quest2: behavior defined by objectivesJson.
     * Only processed in state 1 (Active).
     *
     * @param worldId  The world
     * @param questId  The quest discriminator
     * @param isBoss   Whether the killed enemy was a boss
     * @return Updated QuestEntity
     */
    QuestEntity recordEnemyKilled(String worldId, String questId, boolean isBoss);

    /**
     * Backward-compatible overload — defaults to "sara_village".
     */
    default QuestEntity recordEnemyKilled(String worldId, boolean isBoss) {
        return recordEnemyKilled(worldId, "sara_village", isBoss);
    }

    /**
     * Hands in the quest — transitions state from 2 (Complete) to 3 (HandedIn).
     * Only valid from state 2.
     *
     * @param worldId The world
     * @param questId The quest discriminator
     * @return Updated QuestEntity in state 3
     * @throws com.wastelandsurvivors.backend.exception.GameException if not in state 2
     */
    QuestEntity handInQuest(String worldId, String questId);

    /**
     * Backward-compatible overload — defaults to "sara_village".
     */
    default QuestEntity handInQuest(String worldId) {
        return handInQuest(worldId, "sara_village");
    }
}
