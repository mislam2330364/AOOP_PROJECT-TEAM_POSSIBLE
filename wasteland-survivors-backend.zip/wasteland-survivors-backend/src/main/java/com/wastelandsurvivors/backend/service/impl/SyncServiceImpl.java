package com.wastelandsurvivors.backend.service.impl;

import com.wastelandsurvivors.backend.dto.game.AmmoUpdateDTO;
import com.wastelandsurvivors.backend.dto.game.CombatActionDTO;
import com.wastelandsurvivors.backend.dto.game.EnemyActionDTO;
import com.wastelandsurvivors.backend.dto.game.EnemyHealthDTO;
import com.wastelandsurvivors.backend.dto.game.EnemyLifecycleDTO;
import com.wastelandsurvivors.backend.dto.game.EnemyPositionDTO;
import com.wastelandsurvivors.backend.dto.game.HealthDTO;
import com.wastelandsurvivors.backend.dto.game.PositionDTO;
import com.wastelandsurvivors.backend.entity.EnemyInstanceEntity;
import com.wastelandsurvivors.backend.entity.EnemyTypeEntity;
import com.wastelandsurvivors.backend.entity.PlayerAmmoEntity;
import com.wastelandsurvivors.backend.entity.PlayerWorldStateEntity;
import com.wastelandsurvivors.backend.entity.SessionEntity;
import com.wastelandsurvivors.backend.repository.EnemyInstanceRepository;
import com.wastelandsurvivors.backend.repository.EnemyTypeRepository;
import com.wastelandsurvivors.backend.repository.PlayerAmmoRepository;
import com.wastelandsurvivors.backend.repository.PlayerWorldStateRepository;
import com.wastelandsurvivors.backend.repository.SessionRepository;
import com.wastelandsurvivors.backend.service.SyncService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Full implementation of {@link SyncService} backed by the database.
 *
 * <p>Each method stores the latest game state to the appropriate table.
 * The caller (GameSocketHandler) handles WebSocket broadcasting — this
 * service only does persistence. This separation means:
 * <ul>
 *   <li>State survives server restarts (reconnecting players get their last state)</li>
 *   <li>Sync logic is testable without a WebSocket connection</li>
 *   <li>New sync methods can be added without touching WebSocket config</li>
 * </ul></p>
 *
 * <h3>Player state → player_world_state table</h3>
 * <h3>Enemy state → enemy_instances table</h3>
 */
@Service
@Slf4j
public class SyncServiceImpl implements SyncService {

    private final PlayerWorldStateRepository playerStateRepository;
    private final EnemyInstanceRepository enemyInstanceRepository;
    private final EnemyTypeRepository enemyTypeRepository;
    private final PlayerAmmoRepository playerAmmoRepository;
    private final SessionRepository sessionRepository;

    public SyncServiceImpl(PlayerWorldStateRepository playerStateRepository,
                            EnemyInstanceRepository enemyInstanceRepository,
                            EnemyTypeRepository enemyTypeRepository,
                            PlayerAmmoRepository playerAmmoRepository,
                            SessionRepository sessionRepository) {
        this.playerStateRepository = playerStateRepository;
        this.enemyInstanceRepository = enemyInstanceRepository;
        this.enemyTypeRepository = enemyTypeRepository;
        this.playerAmmoRepository = playerAmmoRepository;
        this.sessionRepository = sessionRepository;
    }

    /**
     * Resolves a sessionId to the actual worldId by looking up the session.
     * The DTOs carry sessionId (for message routing) but the database uses
     * worldId as the foreign key. Without this, inserts fail with FK
     * constraint violations.
     */
    private String resolveWorldId(String sessionId) {
        if (sessionId == null) return "WORLD_DEFAULT";
        return sessionRepository.findById(sessionId)
                .map(SessionEntity::getWorldId)
                .orElse("WORLD_DEFAULT");
    }

    // ========================================================================
    // PLAYER SYNC
    // ========================================================================

    /**
     * Stores the latest player position to player_world_state.
     * Creates the row if this is the first position update for this player+world.
     */
    @Override
    public void handlePositionUpdate(PositionDTO position) {
        String worldId = resolveWorldId(position.getSessionId());
        PlayerWorldStateEntity state = playerStateRepository
                .findByPlayerIdAndWorldId(position.getPlayerId(), worldId)
                .orElseGet(() -> PlayerWorldStateEntity.builder()
                        .playerId(position.getPlayerId())
                        .worldId(worldId)
                        .build());

        state.setPositionX(position.getX());
        state.setPositionY(position.getY());
        state.setFacingDirection(position.getFacingDirection());

        playerStateRepository.save(state);
        log.trace("[Sync] Position saved: playerId={} pos=({},{}) facing={}",
                position.getPlayerId(), position.getX(), position.getY(),
                position.getFacingDirection());
    }

    /**
     * Records a combat action for session replay and validation.
     * Currently logs the action; future: validate cooldown/target here too.
     */
    @Override
    public void handleCombatAction(CombatActionDTO action) {
        // Store combat action metadata for replay/debugging.
        // The authoritative combat resolution is handled by CombatService.
        // This method exists so GameSocketHandler can broadcast the action
        // to the other player in the session without duplicating logic.
        log.debug("[Sync] Combat action: playerId={} damage={} weaponRange={} pos=({},{})",
                action.getPlayerId(), action.getDamage(), action.getWeaponRange(),
                action.getAttackPointX(), action.getAttackPointY());
    }

    /**
     * Updates the server's authoritative health values for a player.
     */
    @Override
    public void handleHealthUpdate(HealthDTO health) {
        String worldId = resolveWorldId(health.getSessionId());
        PlayerWorldStateEntity state = playerStateRepository
                .findByPlayerIdAndWorldId(health.getPlayerId(), worldId)
                .orElseGet(() -> PlayerWorldStateEntity.builder()
                        .playerId(health.getPlayerId())
                        .worldId(worldId)
                        .build());

        state.setCurrentHealth(health.getCurrentHealth());
        state.setMaxHealth(health.getMaxHealth());

        playerStateRepository.save(state);
        log.debug("[Sync] Health saved: playerId={} HP={}/{}",
                health.getPlayerId(), health.getCurrentHealth(), health.getMaxHealth());
    }

    /**
     * Returns the last known position from the database.
     * Used when a player reconnects mid-session to restore their location.
     *
     * @param playerId  The player whose position to retrieve
     * @param worldId   The world/session context (passed as sessionId in DTOs)
     * @return The last saved position, or a default spawn at (0,0) facing right
     */
    @Override
    public PositionDTO getLastKnownPosition(String playerId, String worldId) {
        Long pid = Long.parseLong(playerId);

        return playerStateRepository.findByPlayerIdAndWorldId(pid, worldId)
                .map(state -> PositionDTO.builder()
                        .playerId(state.getPlayerId())
                        .sessionId(state.getWorldId())
                        .x(state.getPositionX())
                        .y(state.getPositionY())
                        .facingDirection(state.getFacingDirection())
                        .timestamp(System.currentTimeMillis())
                        .build())
                .orElseGet(() -> {
                    log.debug("[Sync] No saved position for playerId={} worldId={} — returning default spawn",
                            playerId, worldId);
                    return PositionDTO.builder()
                            .playerId(pid)
                            .sessionId(worldId)
                            .x(0.0f)
                            .y(0.0f)
                            .facingDirection(1)
                            .timestamp(System.currentTimeMillis())
                            .build();
                });
    }

    // ========================================================================
    // ENEMY SYNC
    // ========================================================================

    /**
     * Updates the position of an enemy instance.
     */
    @Override
    public void handleEnemyPositionUpdate(EnemyPositionDTO position) {
        enemyInstanceRepository.findById(position.getEnemyId()).ifPresentOrElse(
                enemy -> {
                    enemy.setPositionX(position.getX());
                    enemy.setPositionY(position.getY());
                    enemy.setFacingDirection(position.getFacingDirection());
                    enemyInstanceRepository.save(enemy);
                    log.trace("[Sync] Enemy position: enemyId={} pos=({},{})",
                            position.getEnemyId(), position.getX(), position.getY());
                },
                () -> log.warn("[Sync] Enemy position update for unknown enemyId={} — ignored",
                        position.getEnemyId())
        );
    }

    /**
     * Records an enemy combat action for session replay.
     */
    @Override
    public void handleEnemyAction(EnemyActionDTO action) {
        log.debug("[Sync] Enemy action: enemyId={} damage={}",
                action.getEnemyId(), action.getDamage());
    }

    /**
     * Updates the health of an enemy instance.
     * If health drops to 0 or below, marks the enemy as dead.
     */
    @Override
    public void handleEnemyHealthUpdate(EnemyHealthDTO health) {
        enemyInstanceRepository.findById(health.getEnemyId()).ifPresentOrElse(
                enemy -> {
                    enemy.setCurrentHealth(health.getCurrentHealth());
                    if (health.getCurrentHealth() <= 0) {
                        enemy.setCurrentHealth(0);
                        enemy.setAlive(false);
                        log.info("[Sync] Enemy died: enemyId={} typeId={}",
                                health.getEnemyId(), enemy.getTypeId());
                    }
                    enemyInstanceRepository.save(enemy);
                    log.debug("[Sync] Enemy health: enemyId={} HP={}/{}",
                            health.getEnemyId(), health.getCurrentHealth(), health.getMaxHealth());
                },
                () -> log.warn("[Sync] Enemy health update for unknown enemyId={} — ignored",
                        health.getEnemyId())
        );
    }

    /**
     * Spawns a new enemy instance in the world.
     * Copies base stats from the enemy type catalog.
     */
    @Override
    public void handleEnemySpawn(EnemyLifecycleDTO spawn) {
        String worldId = resolveWorldId(spawn.getSessionId());
        // Look up the enemy type to get base stats
        EnemyTypeEntity type = enemyTypeRepository.findById(spawn.getEnemyType())
                .orElse(null);

        EnemyInstanceEntity instance = EnemyInstanceEntity.builder()
                .worldId(worldId)
                .typeId(spawn.getEnemyType())
                .currentHealth(type != null ? type.getBaseHealth() : 5)
                .positionX(spawn.getX())
                .positionY(spawn.getY())
                .facingDirection(type != null ? type.getNativeSpriteFacingSign() : 1)
                .enemyState("IDLE")
                .isAlive(true)
                .build();

        EnemyInstanceEntity saved = enemyInstanceRepository.save(instance);

        // Update the spawn DTO with the server-assigned enemy ID so it can be
        // included in the WebSocket broadcast to all clients.
        spawn.setEnemyId(saved.getEnemyId());

        log.info("[Sync] Enemy spawned: enemyId={} typeId={} pos=({},{}) health={}",
                saved.getEnemyId(), spawn.getEnemyType(), spawn.getX(), spawn.getY(),
                saved.getCurrentHealth());
    }

    /**
     * Marks an enemy as dead (despawned).
     */
    @Override
    public void handleEnemyDespawn(EnemyLifecycleDTO despawn) {
        enemyInstanceRepository.findById(despawn.getEnemyId()).ifPresentOrElse(
                enemy -> {
                    enemy.setAlive(false);
                    enemy.setEnemyState("IDLE");
                    enemyInstanceRepository.save(enemy);
                    log.info("[Sync] Enemy despawned: enemyId={} typeId={}",
                            despawn.getEnemyId(), enemy.getTypeId());
                },
                () -> log.warn("[Sync] Despawn for unknown enemyId={} — ignored",
                        despawn.getEnemyId())
        );
    }

    /**
     * Logs a boss phase transition (Phase 1 → Phase 2 enraged mode).
     * The authoritative state is tracked via BossService REST endpoints.
     * This handler exists so the WebSocket broadcast reaches the guest client
     * for real-time sync of the phase 2 scream (Boss_Scream.mp3), health restore,
     * damage buff (+2), and speed multiplier (1.5×).
     */
    @Override
    public void handleBossPhase(Object payload) {
        log.info("[Sync] Boss phase 2 triggered — payload: {}", payload);
    }

    /**
     * Stores the latest ammo state for a player during a multiplayer session.
     * Keeps the opponent's ammo UI in sync and supports reconnect resync.
     */
    @Override
    public void handleAmmoUpdate(AmmoUpdateDTO ammo) {
        String worldId = resolveWorldId(ammo.getSessionId());
        PlayerAmmoEntity entity = playerAmmoRepository
                .findByPlayerIdAndWorldId(ammo.getPlayerId(), worldId)
                .orElseGet(() -> PlayerAmmoEntity.builder()
                        .playerId(ammo.getPlayerId())
                        .worldId(worldId)
                        .build());

        entity.setCurrentClip(ammo.getCurrentClip());
        entity.setMaxClipSize(ammo.getMaxClipSize());
        entity.setTotalAmmoReserve(ammo.getTotalAmmoReserve());

        playerAmmoRepository.save(entity);
        log.debug("[Sync] Ammo saved: playerId={} clip={}/{} reserve={}",
                ammo.getPlayerId(), ammo.getCurrentClip(), ammo.getMaxClipSize(),
                ammo.getTotalAmmoReserve());
    }
}
