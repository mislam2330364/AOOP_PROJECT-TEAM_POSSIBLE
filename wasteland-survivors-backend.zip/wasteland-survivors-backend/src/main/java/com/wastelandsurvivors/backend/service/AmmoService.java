package com.wastelandsurvivors.backend.service;

import com.wastelandsurvivors.backend.entity.PlayerAmmoEntity;

/**
 * Declares ammunition management capabilities per player per world.
 * Tracks clip ammo, max clip size, and total reserve.
 */
public interface AmmoService {

    /**
     * Returns the current ammo state for a player in a world.
     * Auto-creates default state (30/30 clip, 60 reserve) if none exists.
     */
    PlayerAmmoEntity getAmmo(Long playerId, String worldId);

    /**
     * Consumes one bullet from the current clip.
     * Called when the player fires a gunshot.
     *
     * @return Updated ammo state
     * @throws com.wastelandsurvivors.backend.exception.GameException if clip is empty
     */
    PlayerAmmoEntity consumeBullet(Long playerId, String worldId);

    /**
     * Performs a reload: moves bullets from reserve to clip.
     * Calculates bulletsNeeded = maxClipSize - currentClip,
     * bulletsToLoad = min(bulletsNeeded, totalAmmoReserve).
     *
     * @return Updated ammo state after reload
     * @throws com.wastelandsurvivors.backend.exception.GameException if clip is full or reserve is empty
     */
    PlayerAmmoEntity reload(Long playerId, String worldId);

    /**
     * Adds bullets to the player's reserve (from pickups, etc.).
     *
     * @param amount How many bullets to add
     * @return Updated ammo state
     */
    PlayerAmmoEntity addAmmo(Long playerId, String worldId, int amount);
}
