package com.wastelandsurvivors.backend.repository;

import com.wastelandsurvivors.backend.entity.DialogueOptionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Spring Data JPA repository for {@link DialogueOptionEntity} (dialogue_options table).
 */
public interface DialogueOptionRepository extends JpaRepository<DialogueOptionEntity, Long> {

    /**
     * Returns all choice options for a dialogue tree, ordered by option_index.
     */
    List<DialogueOptionEntity> findByDialogueIdOrderByOptionIndexAsc(String dialogueId);
}
