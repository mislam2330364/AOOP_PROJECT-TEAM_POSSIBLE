package com.wastelandsurvivors.backend.controller;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.dto.game.InventoryDTO;
import com.wastelandsurvivors.backend.service.InventoryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST Controller for inventory management.
 * Endpoint signatures are contract — they define what Unity can call and what shape data takes.
 * Method bodies are implementation — they are replaced when the backend is ready.
 * RULE: This class handles HTTP routing only. Business logic belongs in Service classes.
 */
@RestController
@RequestMapping(AppConstants.API_V1 + "/inventory")
@Slf4j
@RequiredArgsConstructor
public class InventoryController {

    /*
     Inventory is now persisted for the demo to prove DB connectivity.
     These endpoints are ready for full implementation as the game evolves.
     */

    private final InventoryService inventoryService;

    /**
     * Loads a player's inventory for a specific world.
     * Unity sends: playerId in URL path, worldId as request parameter.
     * Unity receives: InventoryDTO with a list of inventory items.
     * HTTP status: 200 OK.
     * @param playerId The player whose inventory to load — taken from the URL path
     * @param worldId  The world context — inventory is stored per world
     */
    @GetMapping("/{playerId}")
    public ResponseEntity<?> getInventory(@PathVariable Long playerId,
                                          @RequestParam String worldId) {
        log.info("[InventoryController] GET /{playerId} called");
        return ResponseEntity.ok(inventoryService.getInventory(playerId, worldId));
    }

    /**
     * Saves a player's inventory for a specific world.
     * Unity sends: playerId in URL path, full InventoryDTO as JSON body.
     * Unity receives: confirmation on success.
     * HTTP status on success: 200 OK.
     * @param playerId      The player whose inventory to save — taken from the URL path
     * @param inventoryData The full inventory to persist
     */
    @PostMapping("/{playerId}")
    public ResponseEntity<?> saveInventory(@PathVariable Long playerId,
                                           @RequestBody InventoryDTO inventoryData) {
        log.info("[InventoryController] POST /{playerId} called");
        return ResponseEntity.ok(inventoryService.saveInventory(playerId, inventoryData));
    }

    /**
     * Drops (removes) a specific quantity of an item from a player's inventory.
     * Called by Unity's ItemSlot.onRightClick() when the player drops an item in the world.
     *
     * <p><b>Unity sends:</b></p>
     * <pre>
     * DELETE /api/v1/inventory/1/item?worldId=WORLD_ABC&itemName=HealthPack&quantity=1
     * </pre>
     *
     * <p><b>Unity receives (200 OK):</b> Updated InventoryDTO with the item removed or quantity reduced.</p>
     *
     * @param playerId The player dropping the item
     * @param worldId  The world context
     * @param itemName The item to drop
     * @param quantity How many to drop (default 1)
     */
    @DeleteMapping("/{playerId}/item")
    public ResponseEntity<?> dropItem(@PathVariable Long playerId,
                                      @RequestParam String worldId,
                                      @RequestParam String itemName,
                                      @RequestParam(defaultValue = "1") int quantity) {
        log.info("[InventoryController] DELETE /{}/item — worldId={} itemName={} quantity={}",
                playerId, worldId, itemName, quantity);
        return ResponseEntity.ok(inventoryService.removeItem(playerId, worldId, itemName, quantity));
    }
}

