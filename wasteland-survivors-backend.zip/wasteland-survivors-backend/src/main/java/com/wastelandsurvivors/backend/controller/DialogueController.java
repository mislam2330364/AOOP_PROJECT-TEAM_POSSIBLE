package com.wastelandsurvivors.backend.controller;

import com.wastelandsurvivors.backend.config.AppConstants;
import com.wastelandsurvivors.backend.service.DialogueService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST Controller for NPC actor catalog and dialogue trees.
 * Quest-state-driven routing: Unity passes the current quest state
 * and the server returns the correct dialogue for that NPC + state.
 */
@RestController
@RequestMapping(AppConstants.API_V1)
@Slf4j
public class DialogueController {

    private final DialogueService dialogueService;

    public DialogueController(DialogueService dialogueService) {
        this.dialogueService = dialogueService;
    }

    /**
     * Lists all NPC actors in the catalog.
     * GET /api/v1/npcs
     */
    @GetMapping("/npcs")
    public ResponseEntity<?> getAllNpcs() {
        log.debug("[DialogueController] GET /npcs");
        return ResponseEntity.ok(dialogueService.getAllNpcs());
    }

    /**
     * Returns a single NPC actor by ID.
     * GET /api/v1/npcs/{actorId}
     */
    @GetMapping("/npcs/{actorId}")
    public ResponseEntity<?> getNpc(@PathVariable String actorId) {
        log.debug("[DialogueController] GET /npcs/{}", actorId);
        return ResponseEntity.ok(dialogueService.getNpc(actorId));
    }

    /**
     * Returns the correct dialogue tree for an NPC at a given quest state.
     * This is the main endpoint Unity calls when interacting with an NPC.
     * GET /api/v1/npcs/{npcId}/dialogue?questState=0
     */
    @GetMapping("/npcs/{npcId}/dialogue")
    public ResponseEntity<?> getDialogueForNpc(@PathVariable String npcId,
                                                @RequestParam int questState) {
        log.info("[DialogueController] GET /npcs/{}/dialogue?questState={}", npcId, questState);
        return ResponseEntity.ok(dialogueService.getDialogueForNpc(npcId, questState));
    }

    /**
     * Returns a complete dialogue tree by its ID (lines + options).
     * GET /api/v1/dialogues/{dialogueId}
     */
    @GetMapping("/dialogues/{dialogueId}")
    public ResponseEntity<?> getDialogue(@PathVariable String dialogueId) {
        log.debug("[DialogueController] GET /dialogues/{}", dialogueId);
        return ResponseEntity.ok(dialogueService.getDialogue(dialogueId));
    }
}
