# Wasteland Survivors — Backend Verification Script
# Run after starting the Spring Boot server (mvn spring-boot:run)
# Usage: powershell -ExecutionPolicy Bypass -File verify_all.ps1

$base = "http://localhost:8080/api/v1"
$ErrorActionPreference = "Continue"

function Test-Endpoint {
    param($Label, $Method, $Path, $Body, $ExtraHeaders)
    Write-Host "`n=== $Label ===" -ForegroundColor Cyan
    try {
        $headers = @{"Content-Type" = "application/json" }
        if ($ExtraHeaders) { $headers += $ExtraHeaders }
        $args = @{
            Method  = $Method
            Uri     = "$base$Path"
            Headers = $headers
        }
        if ($Body) { $args["Body"] = $Body }
        # PowerShell 5.1 does not support -SkipCertificateCheck; use -UseBasicParsing for compatibility.
        try {
            $response = Invoke-WebRequest @args -TimeoutSec 10 -UseBasicParsing
        } catch {
            # In newer PowerShell versions -UseBasicParsing is not needed; fall back to default call
            $response = Invoke-WebRequest @args -TimeoutSec 10
        }
        Write-Host "HTTP $($response.StatusCode)" -ForegroundColor Green
        Write-Host $response.Content
        return $response.Content | ConvertFrom-Json
    } catch {
        Write-Host "FAILED: $_" -ForegroundColor Red
        return $null
    }
}

Write-Host "============================================" -ForegroundColor Yellow
Write-Host " Wasteland Survivors Backend Verification" -ForegroundColor Yellow
Write-Host " Server: $base" -ForegroundColor Yellow
Write-Host "============================================" -ForegroundColor Yellow

# --- 1. Register ---
$reg = Test-Endpoint "1. Register (expect 201)" "POST" "/auth/register" `
    '{"username":"verify_user","password":"verify123"}'
if (-not $reg) { Write-Host "ABORTING: Registration failed - is the server running?" -ForegroundColor Red; exit 1 }
$playerId = $reg.playerId
$token = $reg.token
Write-Host "playerId=$playerId"

# --- 2. Login ---
$login = Test-Endpoint "2. Login (expect 200)" "POST" "/auth/login" `
    '{"username":"verify_user","password":"verify123"}'
$token = $login.token
$authHeader = @{"Authorization" = "Bearer $token" }

# --- 3. Create World ---
$world = Test-Endpoint "3. Create World (expect 201)" "POST" "/worlds/create?ownerId=$playerId&worldName=VerifyWorld"
$worldId = $world.worldId
Write-Host "worldId=$worldId"

# --- 4. Get Stats ---
Test-Endpoint "4. Get Player Stats" "GET" "/players/$playerId/stats?worldId=$worldId"

# --- 5. Update Stats ---
Test-Endpoint "5. Update Player Stats" "POST" "/players/$playerId/stats/update?worldId=$worldId" `
    '{"currentHealth":18,"maxHealth":20,"damage":2.0,"positionX":10.0,"positionY":3.0,"facingDirection":1,"currentScene":"village_scene_1"}'

# --- 6. Get EXP ---
Test-Endpoint "6. Get Progression" "GET" "/players/$playerId/exp?worldId=$worldId"

# --- 7. Add EXP (enough for level-up) ---
Test-Endpoint "7. Add EXP (expect level-up)" "POST" "/players/$playerId/exp/add?worldId=$worldId&amount=12"

# --- 8. Intro Played ---
Test-Endpoint "8a. Check Intro (expect false/true)" "GET" "/players/$playerId/intro-played"
Test-Endpoint "8b. Mark Intro Played" "POST" "/players/$playerId/intro-played"

# --- 9. Inventory ---
Test-Endpoint "9a. Get Inventory (expect empty)" "GET" "/inventory/$playerId?worldId=$worldId"
Test-Endpoint "9b. Save Inventory" "POST" "/inventory/$playerId" `
    '{"playerId":'$playerId',"worldId":"'$worldId'","items":[{"itemId":"MEDKIT","itemName":"Med Kit","quantity":3}]}'

# --- 10. Lobby ---
$lobby = Test-Endpoint "10a. Create Lobby" "POST" "/lobby/create" `
    "{\`"worldId\`":\`"$worldId\`",\`"ownerId\`":$playerId}"
if ($lobby) {
    $sessionId = $lobby.sessionId
    Write-Host "sessionId=$sessionId joinKey=$($lobby.joinKey)"

    # Register player 2
    Test-Endpoint "10b. Register Player 2" "POST" "/auth/register" `
        '{"username":"verify_guest","password":"verify123"}'

    Test-Endpoint "10c. Join Lobby (guest=2)" "POST" "/lobby/join/$($lobby.joinKey)" `
        '{"guestId":2}'

    Test-Endpoint "10d. Poll Status" "GET" "/lobby/status/$sessionId"

    Test-Endpoint "10e. Start Session" "POST" "/lobby/start/$sessionId`?ownerId=$playerId"
}

# --- 11. Enemy Types (requires seed data) ---
Test-Endpoint "11. Get Enemy Types" "GET" "/enemies/types"

# --- 12. Spawn Enemy ---
$enemy = Test-Endpoint "12. Spawn Enemy" "POST" "/enemies/instances/spawn?worldId=$worldId&typeId=ZOMBIE_VARIANT_01&x=2.0&y=0.0"
if ($enemy) {
    $enemyId = $enemy.enemyId
    Write-Host "enemyId=$enemyId"

    # --- 13. Damage Enemy ---
    Test-Endpoint "13. Damage Enemy" "POST" "/enemies/instances/$enemyId/damage?amount=3"

    # --- 14. Combat ---
    Test-Endpoint "14. Combat Attack" "POST" "/combat/attack?playerId=$playerId&worldId=$worldId&attackPointX=0&attackPointY=0&weaponRange=5.0"
}

# --- 15. Frenzy State ---
Test-Endpoint "15. Frenzy State" "GET" "/combat/frenzy-state/$playerId?worldId=$worldId"

# --- 16. Quest ---
Test-Endpoint "16a. Get Quest (expect state 0)" "GET" "/worlds/$worldId/quest"
Test-Endpoint "16b. Activate Quest" "POST" "/worlds/$worldId/quest/activate"
Test-Endpoint "16c. Record Zombie Kill" "POST" "/worlds/$worldId/quest/enemy-killed?isBoss=false"
Test-Endpoint "16d. Record Boss Kill" "POST" "/worlds/$worldId/quest/enemy-killed?isBoss=true"

# --- 17. Boss ---
Test-Endpoint "17a. Get Boss State" "GET" "/worlds/$worldId/boss"
Test-Endpoint "17b. Start Boss Fight" "POST" "/worlds/$worldId/boss/start?bossEnemyId=1"
Test-Endpoint "17c. Defeat Boss" "POST" "/worlds/$worldId/boss/defeat"

# --- 18. Hand In Quest ---
Test-Endpoint "18. Hand In Quest" "POST" "/worlds/$worldId/quest/hand-in"

# --- 19. NPC & Dialogue (requires seed data) ---
Test-Endpoint "19a. List NPCs" "GET" "/npcs"
Test-Endpoint "19b. Get Sara Dialogue" "GET" "/npcs/SARA/dialogue?questState=0"

# --- 20. Persistent Objects ---
Test-Endpoint "20a. Mark Object Destroyed" "POST" "/worlds/$worldId/destroyed-objects/test_object_1"
Test-Endpoint "20b. Check Object Destroyed" "GET" "/worlds/$worldId/destroyed-objects/test_object_1"
Test-Endpoint "20c. List Destroyed Objects" "GET" "/worlds/$worldId/destroyed-objects"

# --- 21. Save World ---
Test-Endpoint "21. Save World" "POST" "/worlds/$worldId/save?playerId=$playerId" `
    '{"currentHealth":18,"maxHealth":20,"currentScene":"village_scene_1"}'

# --- 22. Logout ---
Test-Endpoint "22. Logout" "POST" "/auth/logout" -ExtraHeaders $authHeader

# --- Summary ---
Write-Host "`n============================================" -ForegroundColor Yellow
Write-Host " VERIFICATION COMPLETE" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Yellow
Write-Host ""
Write-Host "Database verification commands:" -ForegroundColor Cyan
Write-Host "  mysql -u root -p wasteland_survivors"
Write-Host "  SELECT * FROM players WHERE username IN ('verify_user','verify_guest');"
Write-Host "  SELECT * FROM worlds WHERE id='$worldId';"
Write-Host "  SELECT * FROM player_world_state WHERE world_id='$worldId';"
Write-Host "  SELECT * FROM player_progression WHERE world_id='$worldId';"
Write-Host "  SELECT * FROM quests WHERE world_id='$worldId';"
Write-Host "  SELECT * FROM boss_encounters WHERE world_id='$worldId';"
Write-Host "  SELECT * FROM sessions;"
Write-Host "  SELECT * FROM persistent_objects WHERE world_id='$worldId';"
Write-Host "  SELECT * FROM inventory_items;"
Write-Host "  SELECT * FROM enemy_instances WHERE world_id='$worldId';"
