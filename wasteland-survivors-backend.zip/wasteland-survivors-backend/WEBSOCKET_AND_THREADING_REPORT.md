# WebSocket and Threading Usage Report
## Wasteland Survivors Backend

---

## 1. WEBSOCKET IMPLEMENTATION

### 1.1 WebSocket Configuration
**File:** [config/WebSocketConfig.java](src/main/java/com/wastelandsurvivors/backend/config/WebSocketConfig.java)

- **Framework:** Spring WebSocket with STOMP (Simple Text Oriented Messaging Protocol)
- **Messaging Broker:** In-memory broker at `/topic` and `/queue` prefixes
  - For production with multiple server instances, should be replaced with Redis or RabbitMQ
- **Application Destination Prefix:** `/app` - Messages sent to `/app/*` are routed to `@MessageMapping` methods
- **User Destination Prefix:** `/user` - For point-to-point messaging

**Endpoints:**
- **Raw WebSocket:** `/ws` (for Unity client using `System.Net.WebSockets.ClientWebSocket`)
- **SockJS Fallback:** `/ws/sockjs` (for browser-based clients)

### 1.2 Message Flow Architecture

```
Unity Client sends to /app/game
          ↓
WebSocketConfig routes to @MessageMapping
          ↓
GameSocketHandler.handleGameMessage() receives message
          ↓
SyncService processes the message (stores state, validates, applies logic)
          ↓
SimpMessagingTemplate broadcasts to /topic/session/{sessionId}
          ↓
All subscribed clients receive the message
```

### 1.3 Main WebSocket Handler
**File:** [websocket/GameSocketHandler.java](src/main/java/com/wastelandsurvivors/backend/websocket/GameSocketHandler.java)

**Entry Point:** `@MessageMapping("/game")`

**Responsibilities:**
- Receives ALL incoming WebSocket messages from Unity clients
- Routes messages based on message type (MSG_POSITION, MSG_ACTION, MSG_HEALTH, etc.)
- Calls appropriate SyncService methods for business logic
- Broadcasts processed messages to session subscribers

**Supported Message Types:**
1. `MSG_POSITION` - Player position updates (broadcasted to all session clients)
2. `MSG_ACTION` - Combat action (stored in replay log, broadcasted)
3. `MSG_HEALTH` - Player health update (broadcasted to opponent)
4. `MSG_ENEMY_POSITION` - Enemy position (broadcasted to all clients)
5. `MSG_ENEMY_ACTION` - Enemy combat action (broadcasted to all clients)
6. `MSG_ENEMY_HEALTH` - Enemy health update (host-only, broadcasted to all)
7. `MSG_ENEMY_SPAWN` - Enemy spawn event (host-only, broadcasted)
8. `MSG_ENEMY_DESPAWN` - Enemy despawn event (host-only, broadcasted)
9. `MSG_AMMO_UPDATE` - Ammunition update
10. `MSG_PLAYER_DIED` - Player death event
11. `MSG_HOST_DIED` - Host death (session terminator)

### 1.4 WebSocket Session Lifecycle Management
**File:** [websocket/WebSocketSessionLifecycleListener.java](src/main/java/com/wastelandsurvivors/backend/websocket/WebSocketSessionLifecycleListener.java)

**Event Listeners:**
- `@EventListener` on `SessionSubscribeEvent`
- `@EventListener` on `SessionDisconnectEvent`

**Session Tracking:**
- Maps STOMP `simpSessionId` → game `sessionId` (one-to-one)
- Tracks connected simpSession IDs per game session
- Uses `ConcurrentHashMap` for thread-safe access

**Disconnect Behavior (Phase 6):**
- No longer auto-closes the session on disconnect
- Broadcasts `PLAYER_DISCONNECTED` message to remaining player
- Allows guest rejoin after accidental disconnect
- Session closure delegated to explicit `HOST_DIED` messages or timeout cleanup

**Thread Safety:**
```java
// Thread-safe session mapping
private final Map<String, String> simpSessionToGameSession = new ConcurrentHashMap<>();

// Thread-safe connection tracking per game session
private final Map<String, Set<String>> gameSessionConnections = new ConcurrentHashMap<>();
```

---

## 2. THREADING IMPLEMENTATION

### 2.1 Scheduled Thread Pool for Enemy AI
**File:** [service/impl/EnemySessionManager.java](src/main/java/com/wastelandsurvivors/backend/service/impl/EnemySessionManager.java)

**Thread Pool Creation:**
```java
private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(4);
```

**Configuration:**
- **Pool Size:** 4 threads
- **Purpose:** Run per-session AI loops for enemy behavior
- **Type:** `ScheduledExecutorService` for periodic tasks

**AI Loop Scheduling:**
```java
ScheduledFuture<?> loop = scheduler.scheduleAtFixedRate(
    () -> aiTick(sessionId, worldId, playerIds),
    INITIAL_SPAWN_DELAY_MS,    // 5000 ms initial delay
    AI_TICK_MS,                 // 250 ms interval
    TimeUnit.MILLISECONDS
);
sessionLoops.put(sessionId, loop);  // Track by session ID
```

**Thread-Safe Tracking:**
```java
private final Map<String, ScheduledFuture<?>> sessionLoops = new ConcurrentHashMap<>();
```

**AI Tick Operations (run every 250ms):**
1. Retrieve all alive enemies in the world
2. Get all connected player positions
3. For each enemy:
   - Find closest player
   - Calculate distance
   - If distance > ATTACK_RANGE: Move toward player
   - If distance ≤ ATTACK_RANGE: Broadcast attack action
   - Update enemy state (CHASING, ATTACKING, IDLE)
4. Broadcast position and action updates via WebSocket

**Lifecycle:**
- Started when session transitions to ACTIVE state
- Cancelled when session closes
- All scheduled futures cleaned up before removal

### 2.2 Combat Cooldown and Frenzy State
**File:** [service/impl/CombatServiceImpl.java](src/main/java/com/wastelandsurvivors/backend/service/impl/CombatServiceImpl.java)

**Thread-Safe State Maps:**
```java
private final Map<String, Long> lastAttackTime = new ConcurrentHashMap<>();
private final Map<String, Integer> frenzyBonus = new ConcurrentHashMap<>();
private final Map<String, Long> frenzyMaxActiveSince = new ConcurrentHashMap<>();
```

**Key Format:** `"playerId:worldId"` for map keys

**Purpose:**
- **lastAttackTime:** Tracks last attack timestamp per player per world
- **frenzyBonus:** Tracks frenzy damage bonus (increments on each hit, caps at 4)
- **frenzyMaxActiveSince:** Timestamp when frenzy reached max bonus

**Attack Cooldown Validation:**
```java
String frenzyKey = playerId + ":" + worldId;
long now = System.currentTimeMillis();
Long lastAttack = lastAttackTime.getOrDefault(frenzyKey, 0L);
if (now - lastAttack < ATTACK_COOLDOWN_MS) {  // 500ms cooldown
    return Map.of("hit", false, "reason", "cooldown", 
        "cooldownRemainingMs", ATTACK_COOLDOWN_MS - (now - lastAttack));
}
lastAttackTime.put(frenzyKey, now);
```

**Thread Safety Rationale:**
- Multiple players can attack simultaneously across different sessions
- Web server thread pool processes concurrent requests from multiple clients
- `ConcurrentHashMap` prevents race conditions without explicit locking

### 2.3 JWT Token Blacklist
**File:** [service/impl/AuthServiceImpl.java](src/main/java/com/wastelandsurvivors/backend/service/impl/AuthServiceImpl.java)

**Thread-Safe Token Management:**
```java
private final Set<String> tokenBlacklist = ConcurrentHashMap.newKeySet();
```

**Purpose:**
- Maintains revoked tokens for logged-out players
- Checked during every token validation

**Thread Safety:**
- Multiple players can log out simultaneously
- `ConcurrentHashMap.newKeySet()` provides atomic operations
- Safe for concurrent reads and writes

**Limitation:** 
- In-memory only - lost on server restart
- For production: replace with Redis for multi-instance deployments

---

## 3. THREADING PATTERNS & THREAD SAFETY

### 3.1 ConcurrentHashMap Usage Summary

| Location | Purpose | Thread Safety |
|----------|---------|----------------|
| WebSocketSessionLifecycleListener | Session mapping (STOMP → Game) | ✓ ConcurrentHashMap |
| WebSocketSessionLifecycleListener | Connection tracking per session | ✓ ConcurrentHashMap.newKeySet() |
| CombatServiceImpl | Attack cooldown tracking | ✓ ConcurrentHashMap |
| CombatServiceImpl | Frenzy bonus tracking | ✓ ConcurrentHashMap |
| CombatServiceImpl | Frenzy max active timestamp | ✓ ConcurrentHashMap |
| EnemySessionManager | Scheduled AI loops | ✓ ConcurrentHashMap |
| AuthServiceImpl | JWT token blacklist | ✓ ConcurrentHashMap.newKeySet() |

### 3.2 Spring Boot Thread Pools

From startup logs:
```
inboundChannel[pool size = 0, active threads = 0, queued tasks = 0, completed tasks = 0]
outboundChannel[pool size = 0, active threads = 0, queued tasks = 0, completed tasks = 0]
sockJsScheduler[pool size = 1, active threads = 1, queued tasks = 0, completed tasks = 0]
```

**Spring WebSocket Built-in Thread Pools:**
- **Inbound Channel:** Processes incoming messages (dynamically scaled)
- **Outbound Channel:** Broadcasts outgoing messages (dynamically scaled)
- **SockJS Scheduler:** Background task scheduler for SockJS transport (1 thread reserved)

### 3.3 Concurrency Guarantees

**WebSocket Messages:**
- Spring handles thread-safe message delivery
- Each message processed independently
- No explicit locking required in message handlers

**Game State Synchronization:**
- Server is authoritative for:
  - Enemy AI state (runs on thread pool)
  - Combat cooldowns (checked per request)
  - Player health (stored in DB, updated via WebSocket)
- Client state is eventually consistent via WebSocket broadcasts

---

## 4. MESSAGE FLOW WITH THREADING

### 4.1 Multiplayer Combat Example

```
Player 1 (Thread: Netty-1)
    ↓ sends MSG_ACTION to /app/game
    
GameSocketHandler.handleGameMessage()
    ↓ delegates to CombatService.resolveAttack()
    ↓ checks ConcurrentHashMap<"playerId:worldId", lastAttackTime>
    ↓ updates cooldown timestamp (atomic put)
    ↓ updates frenzy bonus (atomic put)
    
SimpMessagingTemplate.convertAndSend()
    ↓ broadcasts to /topic/session/{sessionId}
    
Player 2 (Thread: Netty-2) receives via WebSocket
Server-Side Enemy AI (Thread: ScheduledThreadPool-0)
    ↓ runs aiTick() every 250ms
    ↓ finds closest player from ConcurrentHashMap
    ↓ calculates damage
    ↓ broadcasts EnemyActionDTO to /topic/session/{sessionId}
    ↓ both players receive attack data
```

### 4.2 Enemy AI Loop Threading

```
Session becomes ACTIVE
    ↓
EnemySessionManager.onSessionActive(sessionId)
    ↓
scheduler.scheduleAtFixedRate(
    aiTick task,
    INITIAL_SPAWN_DELAY_MS = 5000ms,
    AI_TICK_MS = 250ms
)
    ↓
ScheduledExecutorService ThreadPool:
    Thread-0: Runs aiTick for Session-1 every 250ms
    Thread-1: Runs aiTick for Session-2 every 250ms
    Thread-2: Runs aiTick for Session-3 every 250ms
    Thread-3: Runs aiTick for Session-4 every 250ms
    ↓
Each aiTick:
    - Loads ConcurrentHashMap<enemyId, position>
    - Broadcasts updates via WebSocket
    - Updates database (enemy positions, state)
```

---

## 5. PRODUCTION CONSIDERATIONS

### 5.1 Known Limitations

| Feature | Current Implementation | Production Needs |
|---------|------------------------|-------------------|
| Message Broker | In-memory simple broker | Redis or RabbitMQ for multi-instance deployments |
| Token Blacklist | In-memory ConcurrentHashMap | Redis for shared state across server instances |
| Combat Cooldowns | In-memory ConcurrentHashMap | Persisted in Redis for restart resilience |
| Frenzy State | In-memory ConcurrentHashMap | Persisted in Redis for restart resilience |
| Thread Pool Size | Fixed 4 threads for AI | Should scale with expected session count |

### 5.2 Scaling Recommendations

1. **Message Broker Scaling:**
   - Replace `enableSimpleBroker()` with `enableStompBrokerRelay()`
   - Configure external message broker (Redis/RabbitMQ)
   - Enables multi-instance deployments

2. **Thread Pool Scaling:**
   ```java
   // Current: Fixed 4 threads
   // Recommended: Dynamic based on session count
   ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(
       Runtime.getRuntime().availableProcessors() * 2
   );
   ```

3. **State Persistence:**
   - Move `ConcurrentHashMap` caches to Redis
   - Use Redis expiration for auto-cleanup
   - Enables horizontal scaling

4. **Connection Limits:**
   - Configure max WebSocket connections
   - Implement connection pooling
   - Monitor thread pool saturation

---

## 6. KEY FILES SUMMARY

| File | Purpose | Threading Model |
|------|---------|-----------------|
| [config/WebSocketConfig.java](src/main/java/com/wastelandsurvivors/backend/config/WebSocketConfig.java) | STOMP configuration | Spring-managed |
| [websocket/GameSocketHandler.java](src/main/java/com/wastelandsurvivors/backend/websocket/GameSocketHandler.java) | Message routing | Request-per-thread (Netty) |
| [websocket/WebSocketSessionLifecycleListener.java](src/main/java/com/wastelandsurvivors/backend/websocket/WebSocketSessionLifecycleListener.java) | Session tracking | ConcurrentHashMap |
| [service/impl/EnemySessionManager.java](src/main/java/com/wastelandsurvivors/backend/service/impl/EnemySessionManager.java) | AI loop scheduling | ScheduledExecutorService (4 threads) |
| [service/impl/CombatServiceImpl.java](src/main/java/com/wastelandsurvivors/backend/service/impl/CombatServiceImpl.java) | Combat validation | ConcurrentHashMap state |
| [service/impl/AuthServiceImpl.java](src/main/java/com/wastelandsurvivors/backend/service/impl/AuthServiceImpl.java) | Token management | ConcurrentHashMap |

---

## 7. CONCURRENCY FLOW DIAGRAM

```
┌─────────────────────────────────────────────────────────────────┐
│ CLIENT REQUESTS (Thread Pool: Netty/Tomcat)                      │
└─────────────────────────────────────────────────────────────────┘
           │
           ├─→ REST Endpoints (each thread handles one request)
           │
           └─→ WebSocket Messages (each thread processes independently)
                    │
                    ├─→ GameSocketHandler.handleGameMessage()
                    │         │
                    │         ├─→ Reads/Updates ConcurrentHashMap
                    │         │   (Combat cooldowns, frenzy)
                    │         │
                    │         └─→ SimpMessagingTemplate.convertAndSend()
                    │             (Thread-safe broadcast)
                    │
                    └─→ WebSocketSessionLifecycleListener
                            │
                            └─→ Maps STOMP Session → Game Session
                                (ConcurrentHashMap operations)

┌─────────────────────────────────────────────────────────────────┐
│ BACKGROUND TASKS (ScheduledExecutorService: 4 fixed threads)     │
└─────────────────────────────────────────────────────────────────┘
           │
           └─→ EnemySessionManager.aiTick() (every 250ms per session)
                    │
                    ├─→ Load enemy positions from DB
                    │
                    ├─→ Calculate AI behavior
                    │
                    └─→ Broadcast via SimpMessagingTemplate
                        (thread-safe WebSocket push)
```

---

## 8. SUMMARY

### WebSocket Usage:
- ✅ STOMP protocol for structured messaging
- ✅ Raw WebSocket endpoint for Unity clients
- ✅ SockJS fallback for browser clients
- ✅ In-memory message broker (production: upgrade to Redis/RabbitMQ)
- ✅ Server-push architecture for real-time multiplayer sync

### Threading Usage:
- ✅ 4-thread ScheduledExecutorService for enemy AI loops
- ✅ ConcurrentHashMap for thread-safe state tracking (7 use cases)
- ✅ Spring's built-in thread pools for WebSocket channels
- ✅ Request-per-thread model for REST/WebSocket handlers
- ✅ No explicit synchronization (safe ConcurrentHashMap usage throughout)

### Thread Safety Mechanisms:
1. **ConcurrentHashMap:** 6 implementations for state that requires thread-safe access
2. **ScheduledExecutorService:** 4 dedicated threads for periodic AI tasks
3. **SimpMessagingTemplate:** Spring manages thread-safe WebSocket delivery
4. **Spring WebSocket Thread Pools:** Automatic inbound/outbound channel management

