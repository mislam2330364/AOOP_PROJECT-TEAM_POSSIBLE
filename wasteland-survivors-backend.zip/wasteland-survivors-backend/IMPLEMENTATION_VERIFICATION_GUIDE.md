# Wasteland Survivors Backend — Implementation & Verification Guide

**Date:** 2026-06-08  
**Build:** 98 Java source files, 46 Unity C# scripts  
**Stack:** Spring Boot 4.0.6, Java 26, MySQL 8.0, JJWT 0.12.6, STOMP WebSocket  
**Last Update:** Boss Phase 2 system — two-phase boss fight with scream, health restore, stat buffs; new endpoint `POST /boss/phase2`

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Architecture Overview](#2-architecture-overview)
3. [Database Setup](#3-database-setup)
4. [Start the Backend](#4-start-the-backend)
5. [Verify REST Endpoints (41 total)](#5-verify-rest-endpoints)
6. [Verify WebSocket (STOMP)](#6-verify-websocket)
7. [Verify Database Changes](#7-verify-database-changes)
8. [End-to-End Feature Verification](#8-end-to-end-feature-verification)
9. [Unity Integration](#9-unity-integration)
10. [Multiplayer — Two Clients on One Machine](#10-multiplayer--two-clients-on-one-machine)
11. [Known Issues & Caveats](#11-known-issues--caveats)
12. [Complete REST API Reference](#12-complete-rest-api-reference)

---

## 1. Prerequisites

> **Why these specific versions?**  
> Java 26 and Spring Boot 4.0.6 are the actual versions in the `pom.xml`. MySQL 8.0 is required because the schema uses `utf8mb4` charset (emoji support), `TIMESTAMP` defaults, and InnoDB foreign keys — features absent or different in MySQL 5.x.

| Component | Required | How to Check |
|---|---|---|
| **Java 26** | Yes | `java -version` → must show `26.x` |
| **Maven 3.9+** | Yes | `mvn --version` |
| **MySQL 8.0** | Must be running | `mysql -u root -p -e "SELECT VERSION()"` |
| **Port 3306** | MySQL default | Must be free |
| **Port 8080** | Spring Boot default | Must be free |
| **curl** | Recommended | For REST testing. **IMPORTANT:** Use `curl.exe` not `curl` in PowerShell — PowerShell aliases `curl` to `Invoke-WebRequest` which has different syntax and silently drops request bodies. |
| **wscat** | Recommended | For WebSocket STOMP frame testing |

> ⚠️ **PowerShell users:** Always type `curl.exe` (with the `.exe` extension). In PowerShell, `curl` alone is an alias for `Invoke-WebRequest`, which uses `-Body` instead of `-d`. If you type `curl -d '...'` in PowerShell, the body is silently ignored and the server sees an empty request. Using `curl.exe` forces the real cURL binary.

### Install WebSocket test tools

```powershell
# Option A: wscat (Node.js required)
npm install -g wscat

# Option B: websocat (standalone, no dependencies)
winget install vi.websocat
```

---

## 2. Architecture Overview

> **Why understand the architecture first?**  
> Every verification step in this guide traces a request through a specific path in the diagram below. Knowing where a request enters, what processes it, and where the data lands lets you isolate problems instantly — instead of guessing which component is broken.

```
                            UNITY (C#)                              SPRING BOOT (Java)                    MYSQL
                    ┌──────────────────────┐              ┌──────────────────────────────┐       ┌──────────────┐
                    │                      │              │                              │       │              │
 Login/Register ──►│  MockLoginManager.cs  │─── REST ───►│  AuthController.java         │───►│  players     │
                    │       ↓              │    JSON      │       ↓                      │    │              │
                    │  GameAPI.Instance     │              │  AuthServiceImpl.java        │       │              │
                    │  .Login()            │              │   • BCrypt hash password      │       │              │
                    │  .Register()         │              │   • Generate JWT (JJWT 0.12)  │       │              │
                    │                      │              │   • Token blacklist (logout)  │       │              │
                    │                      │              │                              │       │              │
 Create/Join ──────►│  GameAPI.cs           │─── REST ───►│  LobbyController.java        │───►│  sessions    │
 Lobby              │  .CreateLobby()      │    JSON      │       ↓                      │    │              │
                    │  .JoinLobby()        │              │  LobbyServiceImpl.java       │       │              │
                    │  .StartSession()     │              │   • Generate 6-char joinKey   │       │              │
                    │                      │              │   • WAITING→ACTIVE→CLOSED     │       │              │
                    │                      │              │                              │       │              │
 World State ──────►│  GameAPI.cs           │─── REST ───►│  WorldController.java        │───►│  worlds      │
                    │  .GetWorld()         │    JSON      │       ↓                      │    │  player_     │
                    │  .SaveWorld()        │              │  WorldServiceImpl.java       │    │  world_state │
                    │                      │              │   • Bootstrap 5 tables        │    │  player_     │
                    │                      │              │                              │    │  progression│
                    │                      │              │                              │       │              │
 Real-time Sync ───►│  GameAPI.cs           │─── STOMP ──►│  GameSocketHandler.java      │───►│  player_     │
 (100ms loop)       │  .SendPosition()     │  over WS     │       ↓                      │    │  world_state │
                    │  .SendCombatAction() │              │  SyncServiceImpl.java        │    │  enemy_      │
                    │  .SendHealthUpdate() │              │   • Position→player_world_    │    │  instances   │
                    │  .SendEnemySpawn()   │              │     state                    │       │              │
                    │                      │              │   • Enemy→enemy_instances     │       │              │
                    │                      │              │   • Broadcast to /topic/      │       │              │
                    │                      │              │     session/{id}              │       │              │
                    │                      │              │                              │       │              │
 Receive Sync ◄─────│  GameAPI.cs           │◄── STOMP ───│  (same handler broadcasts    │       │              │
 (events fire)      │  OnPositionReceived  │  over WS     │   to all subscribers)        │       │              │
                    │  OnCombatAction...    │              │                              │       │              │
                    │  OnEnemySpawned...    │              │                              │       │              │
                    │                      │              │                              │       │              │
 Combat ───────────►│  (via REST or WS)    │─── REST ───►│  CombatController.java       │───►│  enemy_      │
 Resolution         │                      │    JSON      │       ↓                      │    │  instances   │
                    │                      │              │  CombatServiceImpl.java      │    │  player_     │
                    │                      │              │   • Cooldown validation       │    │  progression│
                    │                      │              │   • Dot-product targeting     │    │  quests      │
                    │                      │              │   • Frenzy mechanic           │       │              │
                    │                      │              │   • Kill→EXP + Quest cascade  │       │              │
                    │                      │              │                              │       │              │
 Quest/Boss/ ──────►│  GameAPI.cs           │─── REST ───►│  QuestController.java        │───►│  quests      │
 Dialogue/Enemy     │  (future calls)      │    JSON      │  BossController.java         │    │  boss_       │
                    │                      │              │  DialogueController.java     │    │  encounters  │
                    │                      │              │  EnemyController.java        │    │  dialogue_*  │
                    │                      │              │  PersistenceController.java  │    │  enemy_*     │
                    │                      │              │                              │    │  persistent_ │
                    └──────────────────────┘              └──────────────────────────────┘    │  objects     │
                                                                                              └──────────────┘
```

### Data Flow — Step by Step

**REST flow (auth, world, lobby, combat):**
1. Unity C# builds JSON → sends HTTP POST/GET via `UnityWebRequest`
2. Spring `@RestController` receives request → validates with `@Valid`
3. Controller calls `@Service` interface method (never the impl directly — can swap impls)
4. Service impl contains business logic → calls `@Repository` (Spring Data JPA)
5. Repository translates method name to SQL (e.g., `findByPlayerIdAndWorldId` → `SELECT ... WHERE player_id=? AND world_id=?`)
6. MySQL stores/returns data → JPA tmaps rows to `@Entity` objects → returned as JSON

**WebSocket flow (real-time position/combat/health/enemy):**
1. Unity `GameAPI.ConnectWebSocket()` opens `ClientWebSocket` to `ws://localhost:8080/ws/game`
2. STOMP CONNECT frame sent → server accepts → STOMP CONNECTED response
3. STOMP SUBSCRIBE to `/topic/session/{id}` → server registers subscription
4. Unity calls `.SendPosition()` → builds `WebSocketMessage` JSON → wraps in STOMP SEND frame → sends to `/app/game`
5. Server `GameSocketHandler.handleGameMessage()` receives → switches on `type` field
6. Calls `SyncServiceImpl.handlePositionUpdate()` → saves to `player_world_state` table
7. Broadcasts message to ALL subscribers of `/topic/session/{id}` (including the sender)
8. Receiving clients parse STOMP MESSAGE frame → deserialize JSON → fire C# event
9. Game scripts subscribed to `OnPositionReceived` update opponent's transform

> **How the server tells clients apart:** Every `WebSocketMessage` carries `senderId`. The receiving client checks `senderId != LocalPlayerId` and ignores its own messages. The server doesn't filter — it broadcasts to everyone and lets clients self-filter. This is simpler and means the server never needs to track "who is whose opponent."

---

## 3. Database Setup

> **Why `ddl-auto=update` instead of running SQL files?**  
> Hibernate's `update` mode reads your `@Entity` classes and ALTERs existing tables to match. This means:
> - You never write a `CREATE TABLE` or `ALTER TABLE` statement manually
> - Adding a field to a Java class automatically adds the column to MySQL on next restart
> - You CAN still run seed SQL files (enemy types, NPCs, dialogues) — those are DATA, not schema
> - Trade-off: production should use `validate` (verify, don't alter) + Flyway/Liquibase migrations

### 3.1 Create the database

```sql
mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS wasteland_survivors CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
```

> **Why `utf8mb4`?** MySQL's `utf8` charset only supports 3-byte characters (no emoji, no some CJK). `utf8mb4` is the real UTF-8 — 4 bytes per character. Unity rich text tags and player names can include these characters.

### 3.2 How tables get created

File: `src/main/resources/application.properties`
```properties
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
```

`show-sql=true` prints every SQL statement to the console. This is your primary debugging tool — you can see exactly what Hibernate does.

> **How `ddl-auto=update` works step by step:**
> 1. On startup, Hibernate scans all classes annotated with `@Entity`
> 2. For each entity, it reads `@Table(name="...")` and `@Column` annotations
> 3. It queries `INFORMATION_SCHEMA` to see what tables/columns exist
> 4. Missing tables → `CREATE TABLE`; missing columns → `ALTER TABLE ... ADD COLUMN`
> 5. It NEVER drops columns or tables (that's `create-drop` mode)
> 6. Foreign keys are created from `@JoinColumn` and `@ManyToOne` annotations

### 3.3 Seed data (enemy types, NPCs, dialogues, items — and optional player accounts)

After the first server start (which creates all tables), populate lookup data:

```bash
mysql -u root -p wasteland_survivors < "D:\Unity Projects\Aoop Game\DB\wasteland_survivors_seed_v2.sql"
```

> **Why seed data is separate from schema:** The seed file inserts rows into tables that already exist. Running it before the server starts will fail because the tables don't exist yet. Always: start server once → stop → run seed → restart.

> **Where player accounts come from:** There are exactly two paths for account creation:
> 1. **Registration endpoint** (`POST /api/v1/auth/register`) — the primary path for all users
> 2. **Seed SQL** — pre-populated accounts for dev/testing convenience
>
> The application code does NOT create any accounts on startup. There is no `DataInitializer` — accounts are a database concern, not an application code concern. If you need pre-populated accounts, run the seed SQL. Otherwise, register through the Unity client.

💡 **TIP:** To verify seed data loaded correctly:
```sql
SELECT COUNT(*) AS enemy_types FROM enemy_types;       -- expect 6+
SELECT COUNT(*) AS npc_count FROM npc_actors;          -- expect 1+ (SARA)
SELECT COUNT(*) AS dialogue_trees FROM dialogue_trees; -- expect 3+ (SARA_INTRO, etc.)
SELECT COUNT(*) AS item_count FROM item_definitions;   -- expect 2+ (MEDKIT, GOLD_BAR)
```

### 3.4 Database connection troubleshooting

```powershell
# If MySQL password differs from default "12345678":
$env:DB_PASSWORD = "your_password"
mvn spring-boot:run
```

⚠️ **WARNING:** `createDatabaseIfNotExist=true` in the JDBC URL means the DATABASE is auto-created if missing. The TABLES are created by Hibernate. But the seed DATA must be manually inserted.

---

## 4. Start the Backend

```powershell
cd "D:\Unity Projects\Aoop Game\wasteland-survivors-backend"
mvn clean compile
mvn spring-boot:run
```

### What each startup log line means

| Log line | What happened | If missing... |
|---|---|---|
| `[Auth] JWT signing key initialised. Algorithm: HS256. Token lifetime: 86400000 ms` | `AuthServiceImpl.init()` derived the HMAC key from `app.jwt.secret` in application.properties | JWT tokens won't sign — auth will fail |
| `Hibernate: create table ...` / `Hibernate: alter table ...` | `ddl-auto=update` is creating/altering tables to match entities | Tables don't match entities — queries will fail |
| `Initialized JPA EntityManagerFactory for persistence unit 'default'` | All `@Entity` classes are mapped and the DB connection is validated | Database is unreachable or entities have mapping errors |
| `Tomcat started on port 8080 (http) with context path ''` | The embedded Tomcat server is listening | Port 8080 is in use, or another process is bound to it |
| `Started WastelandSurvivorsBackendApplication in X.XXX seconds` | Spring context fully loaded, all beans created, app ready for requests | A bean failed to create — check the stack trace above this line |

### Common startup failures

| Error | Root cause | Fix |
|---|---|---|
| `Communications link failure` | MySQL not running or wrong credentials | `mysql -u root -p -e "SELECT 1"` to verify connection |
| `Table '...' doesn't exist` (on first run) | Hibernate tried to ALTER a table before creating it | Normal — restart the server; tables were created on the first attempt |
| `Port 8080 already in use` | Another process bound to 8080 | `netstat -ano \| findstr :8080` → find PID → `taskkill /PID XXXX` |
| `Unable to build Hibernate SessionFactory` | Entity mapping mismatch with existing table | Drop the conflicting table or set `ddl-auto=create` for a clean start |

---

## 4.5 Unity → Backend: First Login (READ THIS FIRST)

> **The single most common setup issue:** Trying to log in with seed data accounts before verifying the server is actually running and reachable. Always verify with curl FIRST, then open Unity.

### 4.5.1 Verify the server is running (30-second check)

```powershell
# Step 1: Check the server responds at all
# NOTE: Use escaped double quotes \" for JSON — works in both PowerShell and cmd.exe.
# Single quotes around JSON only work in PowerShell, not Command Prompt.
curl.exe -X POST http://localhost:8080/api/v1/auth/register -H "Content-Type: application/json" -d "{\"username\":\"testplayer\",\"password\":\"test123456\"}"
```

✓ **If this returns JSON with a token** → the server is running, the database is connected, and auth works. Move to Step 2.

✗ **If this hangs or fails with "connection refused"** → the server is NOT running. Go back to Section 4 and start it. Check the Spring Boot console for errors.

✗ **If this returns a 500 error** → the server is running but the database is not reachable. Check MySQL is running: `mysql -u root -p -e "SELECT 1"`.

### 4.5.2 Try logging in from Unity

```
Unity build → Login_register_page.unity scene → Press Play
```

| What to try | Username | Password | Expected result |
|---|---|---|---|
| **Option A (RECOMMENDED): Register** | *anything new* | *6+ characters* | Creates account + logs in immediately |
| **Option B: Seed account** | `demo_owner` | `password123` | Logs in (only if seed SQL was run) |

> **ALWAYS try Option A (Register) first.** Registration creates a new account AND logs you in — it's a single click and always works if the server is reachable. Seed accounts (Option B) only work if you manually ran `wasteland_survivors_seed_v2.sql` AFTER the first server start created the tables. There is no code-level account creation — the server does not auto-create any user accounts on startup.
>
> **Seed password:** Both `demo_owner` and `demo_guest` use password `password123`. The BCrypt hash in the seed SQL was generated using Spring Security's `BCryptPasswordEncoder` (the same library the server uses), so the passwords WILL match when the server verifies them.

### 4.5.3 What Unity Console should show on success

```
[MockLoginManager] Created GameAPI singleton (was null on scene load).
[Auth] Registration in progress...
[GameAPI] Register success: playerId=1 username=testplayer
[MockLoginManager] Auth success — playerId=1 username=testplayer
```

### 4.5.4 Unity → Server Connectivity Troubleshooting

| Symptom | Check | Fix |
|---|---|---|
| **"connection refused"** in Unity Console | Is Spring Boot running? | Run `mvn spring-boot:run` in the backend folder |
| **Status: "Authentication failed"** | Are you using seed accounts without running the seed SQL? | Click **Register** instead — create a fresh account |
| **Press Play → nothing happens** | Are the UI fields wired in the Inspector? | Select the `LoginController` GameObject in `Login_register_page.unity`. Verify: Username Input, Password Input, Login Button, Register Button are all assigned |
| **404 Not Found** | Is the URL correct? | Unity `NetworkConstants.BASE_URL` must be `http://localhost:8080/api/v1` |
| **500 Internal Server Error** | Is MySQL running? Database exists? | `mysql -u root -p -e "SHOW DATABASES;"` — should show `wasteland_survivors` |
| **CORS error in browser console** | *(shouldn't happen)* `CorsConfig` allows all origins | Check `CorsConfig.java` — `allowedOrigins("*")` must be present |
| **Register works, Login fails** | BCrypt hash mismatch in seed data | The seed uses a pre-computed hash. Register a new account instead of using seed accounts |
| **Token received but next scene doesn't load** | Scene name mismatch | Check `MockLoginManager.nextSceneName` in Inspector — should be `Main_Menu_main` |

### 4.5.5 Quick database check

```sql
-- After registering in Unity, verify the player was created:
SELECT id, username, has_played_intro, created_at FROM players ORDER BY id DESC LIMIT 5;

-- Seed accounts (only present if you ran the seed SQL):
SELECT id, username FROM players WHERE username IN ('demo_owner', 'demo_guest');
```

---

## 5. Verify REST Endpoints (42 total)

> **Verification philosophy:** Every curl command in this section should return the documented JSON. If it doesn't, don't move on — fix the issue at this step. Each endpoint is independent enough that one failure rarely means all are broken. The error response body (always `ErrorResponse` JSON) tells you exactly what went wrong.

💡 **TIP:** Save the token as a PowerShell variable after the first register/login so subsequent authenticated calls work:
```powershell
$token = (curl.exe -X POST http://localhost:8080/api/v1/auth/register -H "Content-Type: application/json" -d "{\"username\":\"player2\",\"password\":\"test123456\"}" 2>$null | ConvertFrom-Json).token
```

### 5.1 Authentication

> **Why JWT instead of server-side sessions?**  
> JWTs are stateless — the server never stores who's logged in. The token itself contains the player's ID (`sub` claim), signed with HMAC-SHA256. Any server that knows the secret can verify it without a database lookup. This means:
> - No session table to query on every request
> - Server restarts don't log players out (tokens survive until they expire)
> - Multiple server instances can all verify the same token (only need the shared secret)
> - **Trade-off:** You can't "delete" a token server-side — logout works by blacklisting the token in memory

#### Register

```powershell
$body = '{"username":"testplayer","password":"test123456"}'
curl.exe -X POST http://localhost:8080/api/v1/auth/register `
  -H "Content-Type: application/json" `
  -d $body
```

> **How it works:**  
> 1. `AuthController.register()` receives the request  
> 2. `@Valid` checks username is 3-20 chars, password is 6+ chars  
> 3. `AuthServiceImpl.register()` checks `playerRepository.existsByUsername()`  
> 4. If taken → throws `GameException.badRequest("USERNAME_TAKEN", ...)` → 400 response  
> 5. If available → BCrypt hashes password → saves `PlayerEntity` to MySQL → generates JWT  
> 6. The JWT contains `{"sub":"1","iat":1717800000,"exp":1717886400}` signed with the secret

✓ **Expected:** HTTP 201 with JSON containing `token`, `playerId`, `username`, `message`.

#### Login

```powershell
curl.exe -X POST http://localhost:8080/api/v1/auth/login -H "Content-Type: application/json" -d "{\"username\":\"testplayer\",\"password\":\"test123456\"}"
```

> **How it works:**  
> 1. Looks up player by username in MySQL  
> 2. `BCryptPasswordEncoder.matches(plainTextPassword, storedHash)` compares hashes  
> 3. BCrypt generates a different hash each time (random salt) — you can NEVER compare two BCrypt hashes directly  
> 4. Updates `last_login_at` timestamp  
> 5. Returns same JWT structure as register  
> 6. If username doesn't exist OR password wrong → SAME error message "Invalid username or password" (prevents account enumeration)

✓ **Expected:** HTTP 200. Verify at [jwt.io](https://jwt.io) — paste the token, you should see `sub` (playerId), `iat`, `exp` claims.

#### Logout

```powershell
curl.exe -X POST http://localhost:8080/api/v1/auth/logout `
  -H "Authorization: Bearer $token"
```

> **How it works:**  
> 1. Extracts token from `Authorization: Bearer ...` header (strips "Bearer " prefix)  
> 2. `AuthServiceImpl.logout()` adds token to `ConcurrentHashMap.newKeySet()` blacklist  
> 3. Future `validateToken()` calls check this set first → blacklisted tokens return false  
> 4. ⚠️ Blacklist is IN-MEMORY — lost on server restart. Tokens become valid again until they expire

✓ **Expected:** HTTP 200 with `{"message":"Logged out successfully"}`.

---

### 5.2 World Management

> **Why create a world bootstraps 5 tables?**  
> A "world" isn't just a row in `worlds` — it's a complete game state container. When you create a world, the server inserts default rows in `worlds`, `player_world_state`, `player_progression`, `quests`, and `boss_encounters` in one transaction. This means the world is immediately ready for gameplay — no separate "initialize world" step needed.

#### Create a world

```powershell
curl.exe -X POST "http://localhost:8080/api/v1/worlds/create?ownerId=1&worldName=TestWorld"
```

> **How it works:**  
> 1. Validates `ownerId` exists in `players` table  
> 2. Generates `worldId` = `WORLD_` + 8 random hex chars  
> 3. In one logical operation: inserts `WorldEntity`, `PlayerWorldStateEntity` (default stats), `PlayerProgressionEntity` (level 1, 0 EXP, 10 to next), `QuestEntity` (state 0, 12 zombies, boss alive), `BossEncounterEntity` (not started)  
> 4. Returns the worldId — save this; all future calls reference it

✓ **Expected:** HTTP 201 with `{"worldId":"WORLD_XXXXXXXX"}`.

#### Get world state

```powershell
curl.exe -X GET "http://localhost:8080/api/v1/worlds/WORLD_XXXXXXXX?playerId=1"
```

✓ **Expected:** JSON with `worldId`, `worldName`, `ownerId`, `playerState`, `quest`, `boss`.

#### Save world state

```powershell
$worldData = '{"currentHealth":18,"maxHealth":20,"currentScene":"village_scene_1","positionX":5.5,"positionY":-2.3}'
curl.exe -X POST "http://localhost:8080/api/v1/worlds/WORLD_XXXXXXXX/save?playerId=1" `
  -H "Content-Type: application/json" `
  -d $worldData
```

> **How it works:** Only the fields PRESENT in the JSON body are updated. Fields omitted (e.g., `damage`, `speed`) keep their existing values. This is a partial update (PATCH semantics on a POST endpoint).

✓ **Expected:** HTTP 200 with `{"message":"World saved successfully"}`.

---

### 5.3 Lobby & Session (Multiplayer)

> **Why a 6-character join key?**  
> The join key is shared out-of-band (Discord, Steam chat, text message). 6 alphanumeric chars = 36^6 = ~2.1 billion combinations. Short enough to type, large enough to prevent brute-force guessing during a game session. The key is UNIQUE across all active sessions (database constraint enforces this).

#### Create session

```powershell
$lobbyBody = '{"worldId":"WORLD_XXXXXXXX","ownerId":1}'
curl.exe -X POST http://localhost:8080/api/v1/lobby/create `
  -H "Content-Type: application/json" `
  -d $lobbyBody
```

> **How session creation works:**  
> 1. Validates `worldId` exists  
> 2. Generates random 6-char alphanumeric join key → checks uniqueness (retries on collision)  
> 3. Generates `sessionId` = `SESS_` + 8 random chars  
> 4. Inserts row with `status=WAITING`, `ownerId` set, `guestId=NULL`

✓ **Expected:** HTTP 201 with `sessionId`, `joinKey` (6 chars), `status="WAITING"`.

#### Join session (guest)

```powershell
# Register player 2 first
curl.exe -X POST http://localhost:8080/api/v1/auth/register -H "Content-Type: application/json" -d "{\"username\":\"guestplayer\",\"password\":\"test123456\"}"

# Join using the joinKey from the create response
curl.exe -X POST http://localhost:8080/api/v1/lobby/join/XXXXXX -H "Content-Type: application/json" -d "{\"guestId\":2}"
```

> **How join works:**  
> 1. Looks up session by join key → 404 if not found  
> 2. Validates session is WAITING → 400 if already ACTIVE or CLOSED  
> 3. Validates `guestId` is not already set → 400 if session full  
> 4. Validates `guestId != ownerId` → 400 if self-join attempt  
> 5. Sets `guestId`, saves, returns updated session

✓ **Expected:** HTTP 200 with `guestId=2`, status still `WAITING`.

#### Poll + Start

```powershell
curl.exe -X GET http://localhost:8080/api/v1/lobby/status/SESS_XXXXXXXX       # Poll
curl.exe -X POST "http://localhost:8080/api/v1/lobby/start/SESS_XXXXXXXX?ownerId=1"  # Start
```

> **How polling works in a real game:** Unity calls `PollLobbyStatus()` every 2 seconds from a coroutine. Both owner and guest poll. When either sees `status=ACTIVE`, they stop polling and load the game scene. This is a "dumb poll" pattern — the server is the single source of truth; clients just check repeatedly.

✓ **Expected:** Poll returns `WAITING`/`ACTIVE`. Start returns `status="ACTIVE"`.

---

### 5.4 Player Stats

> **Why per-world stats?** A player can exist in multiple worlds with different health, position, and scene. The `player_world_state` table has a UNIQUE constraint on `(player_id, world_id)` — one row per player per world. This is the 3NF separation: player identity in `players`, world metadata in `worlds`, and the intersection (runtime state) in `player_world_state`.

```powershell
curl.exe -X GET "http://localhost:8080/api/v1/players/1/stats?worldId=WORLD_XXXXXXXX"
```
✓ **Expected:** `currentHealth:20, maxHealth:20, damage:1.0, weaponRange:3.5, speed:5.0, positionX:0, positionY:0, facingDirection:1, currentScene:null`

```powershell
$statsBody = '{"currentHealth":15,"maxHealth":20,"damage":2.0,"weaponRange":4.0,"speed":5.5,"positionX":10.0,"positionY":3.0,"facingDirection":-1,"currentScene":"Interior_02"}'
curl.exe -X POST "http://localhost:8080/api/v1/players/1/stats/update?worldId=WORLD_XXXXXXXX" `
  -H "Content-Type: application/json" -d $statsBody
```
✓ **Expected:** HTTP 200 with updated values.

---

### 5.5 Experience & Leveling

> **Why the level-up loop handles multiple levels at once?**  
> A single large EXP award (e.g., boss kill = 50 EXP) can trigger multiple level-ups. The formula from `ExpManager.cs`: when `experience >= expToLevel` → level++, subtract threshold, multiply threshold by `expGrowthMultiplier` (1.2x). This loops until `experience < expToLevel`.

```powershell
curl.exe -X GET "http://localhost:8080/api/v1/players/1/exp?worldId=WORLD_XXXXXXXX"
```
✓ **Expected:** `level:1, experience:0, expToLevel:10, expGrowthMultiplier:1.2`

```powershell
# 12 EXP = 4 zombie kills (3 EXP each). Expect: level up 1→2, 2 remaining EXP, next threshold=12
curl.exe -X POST "http://localhost:8080/api/v1/players/1/exp/add?worldId=WORLD_XXXXXXXX&amount=12"
```
✓ **Expected:** `level:2, experience:2, expToLevel:12` (10 consumed, 2 remaining, 10×1.2=12 new threshold)

```powershell
# 24 more EXP = enough for level 2→3 (12 needed) + 3→4 (14.4 needed, partial)
curl.exe -X POST "http://localhost:8080/api/v1/players/1/exp/add?worldId=WORLD_XXXXXXXX&amount=24"
```
✓ **Expected:** `level:3, experience:11.6` (2+24=26, 12 consumed→level 3, 14 remaining, 14.4 needed for next)

---

### 5.6 Combat

> **Why server-authoritative combat?**  
> In a multiplayer game, the CLIENT tells the server "I want to attack." The SERVER decides:
> - Was the cooldown respected? (500ms minimum between attacks)
> - Is there an enemy in range AND in front of the player? (dot-product check)
> - How much damage? (base damage + frenzy bonus)
> - Did the enemy die? (triggers EXP + quest cascades)
>
> If the client decided damage, a hacked client could one-shot everything. The server is the referee.

```powershell
# No enemies yet — expect "no_target"
curl.exe -X POST "http://localhost:8080/api/v1/combat/attack?playerId=1&worldId=WORLD_XXXXXXXX&attackPointX=0&attackPointY=0&weaponRange=5.0"
```
✓ **Expected:** `{"hit":false,"reason":"no_target","enemiesInRange":0}`

```powershell
curl.exe -X GET "http://localhost:8080/api/v1/combat/frenzy-state/1?worldId=WORLD_XXXXXXXX"
```
✓ **Expected:** `{"frenzyActive":false,"currentDamage":1,"baseDamage":1,"maxDamage":5,"frenzyBonus":0}`

> **How the frenzy mechanic works (mirrors Player_Combat.cs):**
> - Base damage = `player_world_state.damage` (e.g., 1)
> - Each successful hit → +1 frenzy bonus (capped at +4 = max 5 total)
> - Once frenzy hits max, a 10-second countdown starts
> - When countdown expires → frenzy resets to 0 (back to base damage)
> - Server tracks frenzy state in `ConcurrentHashMap` keyed by `"playerId:worldId"`

### 5.6a Melee Combat

> **Why a separate melee system?** Player_Combat.cs now has two attack modes. Gun attacks use dot-product targeting (only enemies in front) and scale with frenzy. Melee attacks use proximity-only targeting (any enemy in melee range regardless of facing) and deal fixed damage with no frenzy scaling. Melee also applies knockback — the enemy is pushed backward on hit.

```powershell
# Gun attack (default actionType=ATTACK)
curl.exe -X POST "http://localhost:8080/api/v1/combat/attack?playerId=1&worldId=WORLD_XXXXXXXX&attackPointX=0&attackPointY=0&weaponRange=5.0&actionType=ATTACK"

# Melee attack (proximity targeting, knockback on hit)
curl.exe -X POST "http://localhost:8080/api/v1/combat/attack?playerId=1&worldId=WORLD_XXXXXXXX&attackPointX=0&attackPointY=0&weaponRange=1.0&actionType=MELEE&meleeDamage=2"
```

> **How melee targeting differs from gun:** Melee uses `weaponRange=1.0` (the meleeRange from Player_Combat). It finds the CLOSEST enemy within that radius regardless of which direction the player faces — you can melee enemies behind you. The `meleeDamage` parameter (default 2) is the fixed damage — no frenzy scaling.

✓ **Expected melee response:**
```json
{"hit":true, "targetEnemyId":1, "damageDealt":2, "enemyDied":false,
 "actionType":"MELEE",
 "knockback":{"directionX":1.0, "directionY":0.0, "force":10.0, "duration":0.2}}
```

The `knockback` object tells the client to push the enemy in `directionX` (matching the player's facing) at `force=10.0` for `duration=0.2` seconds. Only present for melee hits that don't kill.

---

### 5.6b Ammunition System

> **Why track ammo server-side?** Without server authority, a hacked client could set `totalAmmoReserve=999999`. With server-side ammo tracking, every bullet consumed and every reload is validated. The server deducts bullets on fire and calculates reload amounts — the client is NOT trusted with ammo counts in multiplayer.

```powershell
# Get ammo state
curl.exe -X GET "http://localhost:8080/api/v1/players/1/ammo?worldId=WORLD_XXXXXXXX"
```
✓ **Expected:** `{"currentClip":30, "maxClipSize":30, "totalAmmoReserve":60}`

```powershell
# Consume one bullet (fired a shot)
curl.exe -X POST "http://localhost:8080/api/v1/players/1/ammo/consume?worldId=WORLD_XXXXXXXX"
```
✓ **Expected:** `currentClip` decrements to 29

```powershell
# Reload: moves bullets from reserve to clip
# Player fires 5 more shots (clip goes from 29 to 24), then reloads:
curl.exe -X POST "http://localhost:8080/api/v1/players/1/ammo/reload?worldId=WORLD_XXXXXXXX"
# bulletsNeeded = 30 - 24 = 6, bulletsToLoad = min(6, 60) = 6
# Result: clip=30, reserve=54
```
✓ **Expected:** `{"currentClip":30, "totalAmmoReserve":54}`

```powershell
# Add ammo to reserve (ammo pickup)
curl.exe -X POST "http://localhost:8080/api/v1/players/1/ammo/add?worldId=WORLD_XXXXXXXX&amount=15"
```
✓ **Expected:** `totalAmmoReserve` increases by 15

> **How reload logic works (mirrors Player_Combat.ReloadRoutine):**
> 1. `bulletsNeeded = maxClipSize - currentClip`
> 2. `bulletsToLoad = min(bulletsNeeded, totalAmmoReserve)`
> 3. `currentClip += bulletsToLoad`, `totalAmmoReserve -= bulletsToLoad`
> 4. Validates: clip not full (400), reserve not empty (400)

⚠️ **Error cases:**
- `POST /ammo/consume` when `currentClip=0` → 400 `"CLIP_EMPTY"`
- `POST /ammo/reload` when `currentClip=maxClipSize` → 400 `"CLIP_FULL"`
- `POST /ammo/reload` when `totalAmmoReserve=0` → 400 `"NO_AMMO"`

> **3NF design:** Ammo is stored in `player_ammo` table (separate from `player_world_state`). Reason: ammo changes at different frequency than position/health, and separating them avoids lock contention during combat-heavy sessions.

---

### 5.7 Enemy System

> **Why separate enemy_types from enemy_instances?**  
> This is 3NF normalization. `enemy_types` stores STATIC template data (base health, damage, sprite name, prefab) — one row per zombie variant. `enemy_instances` stores DYNAMIC runtime data (current health, position, AI state) — one row per spawned enemy. When an enemy spawns, its type's template stats are COPIED to the instance. From then on, the instance changes independently.

```powershell
# Spawn a zombie (requires seed data for ZOMBIE_VARIANT_01 to exist)
curl.exe -X POST "http://localhost:8080/api/v1/enemies/instances/spawn?worldId=WORLD_XXXXXXXX&typeId=ZOMBIE_VARIANT_01&x=2.0&y=0"
```
✓ **Expected:** HTTP 200 with `enemyId`, `typeId`, `currentHealth` (copied from template), `positionX/Y`, `enemyState="IDLE"`, `isAlive=true`

```powershell
curl.exe -X GET "http://localhost:8080/api/v1/enemies/types"                          # All types
curl.exe -X GET "http://localhost:8080/api/v1/enemies/types/ZOMBIE_VARIANT_01"        # One type
curl.exe -X GET "http://localhost:8080/api/v1/enemies/instances/alive?worldId=WORLD_XXXXXXXX"  # Alive only
curl.exe -X POST "http://localhost:8080/api/v1/enemies/instances/1/damage?amount=3"   # Damage enemy
```

⚠️ **If "ENEMY_TYPE_NOT_FOUND":** You skipped the seed data step (see Section 3.3). Run `wasteland_survivors_seed_v2.sql`.

---

### 5.8 Quest System

> **Why a state machine with strict transitions?**  
> The quest has 4 states with defined legal transitions: 0→1 (activate), 1→2 (auto on objectives complete), 2→3 (hand-in). Illegal transitions (e.g., handing in before completing, activating an already-active quest) throw `GameException.badRequest()`. This prevents client bugs or exploits from corrupting quest state.
>
> **Boss Phase 2 & Quest integration:** The Mutated Boss now has two phases (see Section 5.9). The quest system still tracks `isBossAlive` as a single boolean — the boss is considered "alive" until defeated in Phase 2. The phase transition (Phase 1 → Phase 2) does NOT set `isBossAlive=false`; only the final defeat in Phase 2 does. This means the quest auto-completion (state 1→2) only triggers after the phase 2 boss is killed.

```powershell
curl.exe -X GET "http://localhost:8080/api/v1/worlds/WORLD_XXXXXXXX/quest"             # State 0
curl.exe -X POST "http://localhost:8080/api/v1/worlds/WORLD_XXXXXXXX/quest/activate"   # 0→1
curl.exe -X POST "http://localhost:8080/api/v1/worlds/WORLD_XXXXXXXX/quest/enemy-killed?isBoss=false"  # Zombie -1
curl.exe -X POST "http://localhost:8080/api/v1/worlds/WORLD_XXXXXXXX/quest/enemy-killed?isBoss=true"   # Boss dead
curl.exe -X POST "http://localhost:8080/api/v1/worlds/WORLD_XXXXXXXX/quest/hand-in"    # 2→3
```

> **Auto-transition logic:** After `recordEnemyKilled()`, if `zombiesRemaining <= 0 && !isBossAlive`, state automatically changes from 1 to 2. Unity doesn't need to call a separate "complete quest" endpoint — it just reports kills, and the server decides when objectives are met.

---

### 5.9 Boss System (Two-Phase Fight)

> **Why a two-phase boss fight?** The Mutated Boss now has two phases, matching the updated `Enemy_Health.cs` boss phase system. Phase 1 is a normal boss fight. When the boss health first hits 0, instead of dying, it enters Phase 2: plays a scream (`Boss_Scream.mp3`), restores to 100 HP, gains +2 damage, and moves at 1.5× speed. The boss can only be truly killed in Phase 2. This prevents one-shot exploits and adds dramatic tension.

```powershell
curl.exe -X GET "http://localhost:8080/api/v1/worlds/WORLD_XXXXXXXX/boss"              # Check boss state
curl.exe -X POST "http://localhost:8080/api/v1/worlds/WORLD_XXXXXXXX/boss/start?bossEnemyId=1"  # Start fight
curl.exe -X POST "http://localhost:8080/api/v1/worlds/WORLD_XXXXXXXX/boss/phase2"      # Trigger Phase 2 (boss "dies" first time)
curl.exe -X POST "http://localhost:8080/api/v1/worlds/WORLD_XXXXXXXX/boss/defeat"      # Kill boss (Phase 2 only)
```

> **How the two-phase system works:**
> 1. `POST /boss/start` — sets `fightStarted=true`, `currentPhase=1`
> 2. Client damages boss until health hits 0 (phase 1)
> 3. Client calls `POST /boss/phase2` — sets `currentPhase=2`, `phase2Activated=true`
> 4. Boss restores to `phase2Health` (100 HP), gains +2 damage, 1.5× speed
> 5. Client damages boss again until health hits 0 (phase 2 — this time it's real)
> 6. Client calls `POST /boss/defeat` — sets `isDefeated=true`, calls `questService.recordEnemyKilled(worldId, true)`

> **Phase 2 validation:** `triggerPhase2()` validates the fight is started, the boss isn't already defeated, and phase 2 hasn't already been activated. Attempts to trigger phase 2 twice return `BOSS_ALREADY_PHASE2` (400).

> **How boss defeat cascades:** `BossServiceImpl.defeatBoss()` sets `isDefeated=true` AND calls `questService.recordEnemyKilled(worldId, true)`. This is cross-service integration — the boss service doesn't duplicate quest logic; it delegates.

---

### 5.10 Dialogue & NPC

> **How quest-state routing works (matching NPC_Talk.cs):**  
> Unity calls `GET /npcs/SARA/dialogue?questState=0` to get Sara's intro dialogue. The backend queries `dialogue_trees` WHERE `npc_actor_id='SARA' AND quest_state_filter=0`. If no match, falls back to any dialogue for that NPC without a state filter. This means adding a new quest state only requires inserting a new dialogue tree row — no code changes.

```powershell
curl.exe -X GET http://localhost:8080/api/v1/npcs
curl.exe -X GET http://localhost:8080/api/v1/npcs/SARA
curl.exe -X GET "http://localhost:8080/api/v1/npcs/SARA/dialogue?questState=0"   # Intro
curl.exe -X GET "http://localhost:8080/api/v1/npcs/SARA/dialogue?questState=2"   # Completion
curl.exe -X GET http://localhost:8080/api/v1/dialogues/SARA_INTRO                 # Direct access
```

---

### 5.11 Persistent Objects

> **Why track destroyed objects server-side?**  
> Without server tracking, a player could: collect a health pack → leave scene → re-enter → health pack respawns → collect again (infinite farming). The `persistent_objects` table stores `(world_id, object_unique_id)` pairs. `ScenePersistentObject.Start()` checks this table — if the object is destroyed, it self-destructs on scene load.

```powershell
curl.exe -X GET "http://localhost:8080/api/v1/worlds/WORLD_XXXXXXXX/destroyed-objects"
curl.exe -X GET "http://localhost:8080/api/v1/worlds/WORLD_XXXXXXXX/destroyed-objects/Zombie_01_5_3"
curl.exe -X POST "http://localhost:8080/api/v1/worlds/WORLD_XXXXXXXX/destroyed-objects/HealthPack_10_2"
```

### 5.12 Intro Tracking + Inventory

```powershell
curl.exe -X GET http://localhost:8080/api/v1/players/1/intro-played
curl.exe -X POST http://localhost:8080/api/v1/players/1/intro-played
curl.exe -X GET "http://localhost:8080/api/v1/inventory/1?worldId=WORLD_XXXXXXXX"
curl.exe -X POST http://localhost:8080/api/v1/inventory/1 -H "Content-Type: application/json" -d "{\"playerId\":1,\"worldId\":\"WORLD_XXXXXXXX\",\"items\":[{\"itemId\":\"MEDKIT\",\"itemName\":\"Med Kit\",\"quantity\":3}]}"
```

---

## 6. Verify WebSocket (STOMP)

> **Why STOMP over raw WebSocket?**  
> Raw WebSocket is just a TCP pipe — you send bytes, you receive bytes. There's no concept of "destinations," "subscriptions," or "message types." STOMP (Streaming Text Oriented Messaging Protocol) adds these on top:
> - `SEND destination:/app/game` → routes to `@MessageMapping("/game")`
> - `SUBSCRIBE destination:/topic/session/123` → receive broadcasts for session 123
> - `CONNECT` / `DISCONNECT` frames manage the connection lifecycle
> - The `content-length` header ensures binary-safe message bodies
>
> **How it maps to the backend:** Spring's STOMP broker reads the `destination` header and routes SEND frames to `@MessageMapping` methods, and SUBSCRIBE frames register for `SimpMessagingTemplate.convertAndSend()` broadcasts.

### 6.1 Connect with websocat

```powershell
websocat ws://localhost:8080/ws/game
```

### 6.2 STOMP handshake

Type each frame exactly (including the blank line between headers and body, and the null terminator `\0`). In websocat, press `Ctrl+Shift+@` or paste `\0`:

```
CONNECT
accept-version:1.1,1.2
heart-beat:0,30000

\0
```

> **What happens server-side:** The STOMP broker accepts the connection, parses the CONNECT frame, and replies with CONNECTED. The `heart-beat:0,30000` means "I won't send heartbeats, but I'll accept them from you every 30 seconds." The `accept-version:1.1,1.2` tells the server which STOMP protocol versions the client supports.

✓ **Expected response:**
```
CONNECTED
version:1.1
heart-beat:0,0

\0
```

### 6.3 Subscribe to session topic

```
SUBSCRIBE
id:sub-0
destination:/topic/session/SESS_TEST

\0
```

> **Why subscribe BEFORE sending?** Messages broadcast to `/topic/session/{id}` are only delivered to clients that are subscribed at the moment of broadcast. Subscribe first, then send, or you'll miss messages.

### 6.4 Send a game message

```
SEND
destination:/app/game
content-type:application/json
content-length:150

{"type":"POSITION","sessionId":"SESS_TEST","senderId":1,"payload":"{\"playerId\":1,\"x\":10.5,\"y\":-2.3,\"facingDirection\":1}","timestamp":1717800000000}\0
```

> **How the message flows:**
> 1. STOMP SEND frame arrives at `/app/game`
> 2. Spring routes to `GameSocketHandler.handleGameMessage()` (because `@MessageMapping("/game")` matches `/app/game`)
> 3. `switch(message.getType())` → case `"POSITION"` → `syncService.handlePositionUpdate()`
> 4. `SyncServiceImpl` saves position to `player_world_state` table
> 5. `broadcastToSession(message)` → `messagingTemplate.convertAndSend("/topic/session/SESS_TEST", message)`
> 6. Since you subscribed to `/topic/session/SESS_TEST`, you receive it back as a MESSAGE frame

✓ **You should receive the message back** (since you're subscribed to the topic the handler broadcasts to).

### 6.5 PING/PONG keep-alive

```
SEND
destination:/app/game
content-type:application/json

{"type":"PING","sessionId":"SESS_TEST","senderId":1,"timestamp":1717800000000}\0
```

> **How PING/PONG works:**
> 1. Unity's `GameAPI.PingLoopAsync()` sends PING every 30 seconds
> 2. `GameSocketHandler` case `MSG_PING` → creates a PONG message → sends to sender's user queue (`/user/queue/pong`)
> 3. If Unity doesn't receive PONG within 5 seconds, it should disconnect and reconnect
> 4. Must also subscribe to `/user/queue/pong` to receive PONG replies

### 6.6 All WebSocket message types

| Type | Triggered by | Handler | Persisted to |
|---|---|---|---|
| `POSITION` | Player moves | `SyncService.handlePositionUpdate()` | `player_world_state` |
| `ACTION` | Player attacks | `SyncService.handleCombatAction()` | *(logged only)* |
| `HEALTH` | Player health changes | `SyncService.handleHealthUpdate()` | `player_world_state` |
| `INVENTORY` | *(reserved)* | *(not yet handled)* | — |
| `PING` | Keep-alive timer | Server replies PONG | — |
| `PONG` | Server reply | *(client receives)* | — |
| `SESSION_READY` | Session becomes ACTIVE | *(broadcast by server)* | — |
| `PLAYER_DISCONNECTED` | Opponent drops | *(broadcast by server)* | — |
| `ENEMY_POSITION` | Enemy moves | `SyncService.handleEnemyPositionUpdate()` | `enemy_instances` |
| `ENEMY_ACTION` | Enemy attacks | `SyncService.handleEnemyAction()` | *(logged only)* |
| `ENEMY_HEALTH` | Enemy damaged | `SyncService.handleEnemyHealthUpdate()` | `enemy_instances` |
| `ENEMY_SPAWN` | Enemy created | `SyncService.handleEnemySpawn()` | `enemy_instances` (INSERT) |
| `ENEMY_DESPAWN` | Enemy removed | `SyncService.handleEnemyDespawn()` | `enemy_instances` (set dead) |
| `ENEMY_KNOCKBACK` | Enemy melee knockback | *(broadcast by host)* | `enemy_instances` (position) |
| `AMMO_UPDATE` | Player ammo changed | *(broadcast by server)* | `player_ammo` |
| `BOSS_PHASE` | Boss enters Phase 2 (enraged) | `SyncService.handleBossPhase()` | `boss_encounters` (via REST) |

---

## 7. Verify Database Changes

> **Why query MySQL directly instead of trusting REST responses?**  
> A REST endpoint returning `"hit":true` doesn't prove data was actually persisted. The service might return a hardcoded response, an in-memory map, or cached data. The ONLY way to verify the full stack is working is to see the row in MySQL with your own eyes. This is the difference between "the endpoint responds" and "the system works."

### 7.1 Connect

```powershell
mysql -u root -p wasteland_survivors
```

### 7.2 Verify tables exist

```sql
SHOW TABLES;
```
✓ **Expected (15+ tables):** `players`, `worlds`, `player_world_state`, `player_progression`, `inventories`, `inventory_items`, `enemy_types`, `enemy_instances`, `boss_encounters`, `quests`, `sessions`, `persistent_objects`, `npc_actors`, `dialogue_trees`, `dialogue_lines`, `dialogue_options`, `item_definitions`.

### 7.3 Endpoint → Database verification

```sql
-- After POST /auth/register
SELECT id, username, has_played_intro, created_at FROM players WHERE username = 'testplayer';

-- After POST /worlds/create (WORLD_XX = your world ID)
SELECT * FROM worlds WHERE id = 'WORLD_XXXXXXXX';
SELECT * FROM player_world_state WHERE world_id = 'WORLD_XXXXXXXX';
SELECT * FROM player_progression WHERE world_id = 'WORLD_XXXXXXXX';
SELECT * FROM quests WHERE world_id = 'WORLD_XXXXXXXX';
SELECT * FROM boss_encounters WHERE world_id = 'WORLD_XXXXXXXX';

-- After POST /lobby/create
SELECT session_id, join_key, status, owner_id, guest_id FROM sessions;

-- After WebSocket POSITION message
SELECT player_id, position_x, position_y, facing_direction, current_scene
FROM player_world_state WHERE world_id = 'WORLD_XXXXXXXX';

-- After POST /enemies/instances/spawn
SELECT enemy_id, type_id, current_health, position_x, position_y, is_alive
FROM enemy_instances WHERE world_id = 'WORLD_XXXXXXXX';

-- After quest activate + kills
SELECT quest_state, zombies_remaining, is_boss_alive FROM quests WHERE world_id = 'WORLD_XXXXXXXX';

-- After boss phase 2 + defeat
SELECT current_phase, phase2_activated, phase2_health, is_defeated FROM boss_encounters WHERE world_id = 'WORLD_XXXXXXXX';

-- After POST /worlds/.../destroyed-objects/...
SELECT object_unique_id, is_destroyed, destroyed_at FROM persistent_objects WHERE world_id = 'WORLD_XXXXXXXX';

-- After POST /players/{id}/intro-played
SELECT id, username, has_played_intro FROM players WHERE id = 1;

-- After POST /inventory/{id}
SELECT ii.item_id, ii.quantity, ii.item_name
FROM inventory_items ii
JOIN inventories i ON ii.inventory_id = i.id
WHERE i.player_id = 1 AND i.world_id = 'WORLD_XXXXXXXX';
```

### 7.4 Cross-system integration chain

> **Why test the chain?** Isolated endpoint tests don't catch integration bugs. The combat→EXP→quest chain is the most important cross-system flow — if it breaks, the core game loop is broken.

```sql
-- Step 1: Spawn an enemy (via REST: POST /enemies/instances/spawn)
-- Step 2: Verify it exists
SELECT enemy_id, type_id, current_health, is_alive
FROM enemy_instances WHERE world_id = 'WORLD_XX' AND is_alive = TRUE;

-- Step 3: Attack (via REST: POST /combat/attack)
-- Step 4: Verify health decreased
SELECT enemy_id, current_health, is_alive FROM enemy_instances WHERE enemy_id = 1;

-- Step 5: If enemy died (current_health <= 0), verify EXP was awarded
SELECT level, experience, exp_to_level FROM player_progression
WHERE player_id = 1 AND world_id = 'WORLD_XX';

-- Step 6: Verify quest was updated (if quest was active)
SELECT quest_state, zombies_remaining, is_boss_alive FROM quests WHERE world_id = 'WORLD_XX';
```

### 7.5 JWT stateless verification

```sql
-- There is NO auth_sessions table. JWT tokens are never stored.
SELECT COUNT(*) FROM sessions WHERE status = 'WAITING';
```
The `sessions` table stores **lobby sessions** (game lobbies), NOT authentication sessions. JWT validation is purely cryptographic — `AuthServiceImpl.validateToken()` verifies the HMAC-SHA256 signature against the secret key, checks expiry, checks the in-memory blacklist, and verifies the player still exists in the database. No database write happens during login or token validation.

---

## 8. End-to-End Feature Verification

Follow these 38 steps in order to verify the complete game loop. Each "Verification" column tells you the SQL to run to prove the operation actually persisted.

### Phase 1: Single Player Setup

| # | Action | ✓ SQL proof |
|---|---|---|
| 1 | `POST /auth/register` | `SELECT * FROM players WHERE username='testplayer'` |
| 2 | `POST /auth/login` | Verify JWT at [jwt.io](https://jwt.io) |
| 3 | `POST /worlds/create` | Check `worlds` + 4 dependent tables all have rows |
| 4 | `GET /players/1/stats` | Returns HP=20, damage=1.0, speed=5.0 |
| 5 | `POST /players/1/stats/update` | `SELECT current_health, damage FROM player_world_state` |
| 6 | `GET /players/1/exp` | Level 1, 0 EXP |
| 7 | `POST /players/1/exp/add?amount=12` | `SELECT level, experience FROM player_progression` |
| 8 | `POST /players/1/intro-played` | `SELECT has_played_intro FROM players` → true |
| 9 | `GET /inventory/1` | Empty items list |
| 10 | `POST /inventory/1` with items | `SELECT * FROM inventory_items` |
| 11 | `POST /worlds/.../save` with worldData | `SELECT position_x, current_scene FROM player_world_state` |
| 12 | `POST /auth/logout` | Token blacklisted — reuse returns 401 |

### Phase 2: Multiplayer

| # | Action | ✓ SQL proof |
|---|---|---|
| 13 | Register player 2 | `SELECT * FROM players WHERE username='guestplayer'` |
| 14 | `POST /lobby/create` | `SELECT * FROM sessions` — WAITING, joinKey populated |
| 15 | `POST /lobby/join/{key}` with guestId=2 | Session has guestId=2 |
| 16 | `GET /lobby/status/{sessionId}` | Returns WAITING |
| 17 | `POST /lobby/start/{sessionId}` | Returns ACTIVE |
| 18 | WebSocket connect + subscribe | Receive SESSION_READY |

### Phase 3: Combat Loop

| # | Action | ✓ SQL proof |
|---|---|---|
| 19 | Seed enemy types: run `seed_v2.sql` | `SELECT * FROM enemy_types` |
| 20 | `POST /enemies/instances/spawn` | `enemy_instances` row, alive=true |
| 21 | `POST /combat/attack` (player facing right at 0,0, enemy at 2,0, range 5) | Hit if enemy in range + in front |
| 22 | Check enemy health | `SELECT current_health FROM enemy_instances` |
| 23 | Kill via `POST /enemies/.../damage?amount=100` | `is_alive=false`, EXP awarded |
| 24 | `GET /combat/frenzy-state/1` | Frenzy bonus incremented |

### Phase 4: Quest & Boss

| # | Action | ✓ SQL proof |
|---|---|---|
| 25 | `GET /worlds/.../quest` | State 0 |
| 26 | `POST /worlds/.../quest/activate` | State 1 |
| 27 | Record zombie kills via `POST /quest/enemy-killed?isBoss=false` | zombiesRemaining decrements |
| 28 | `GET /worlds/.../boss` | Not started, currentPhase=1 |
| 29 | `POST /worlds/.../boss/start?bossEnemyId=X` | fightStarted=true |
| 30 | `POST /worlds/.../boss/phase2` | currentPhase=2, phase2Activated=true |
| 31 | `POST /worlds/.../boss/defeat` | isDefeated=true, quest.isBossAlive→false |
| 32 | Record boss kill via `POST /quest/enemy-killed?isBoss=true` | State auto→2 (if zombies also 0) |
| 33 | `POST /worlds/.../quest/hand-in` | State 3 |

### Phase 5: Dialogue & Persistence

| # | Action | ✓ SQL proof |
|---|---|---|
| 34 | `GET /npcs` | List of NPCs |
| 35 | `GET /npcs/SARA/dialogue?questState=0` | Intro dialogue |
| 36 | `GET /npcs/SARA/dialogue?questState=2` | Completion dialogue |
| 37 | `POST /worlds/.../destroyed-objects/test_obj` | `SELECT * FROM persistent_objects` |
| 38 | `GET /worlds/.../destroyed-objects/test_obj` | Returns `isDestroyed:true` |
| 39 | `GET /worlds/.../destroyed-objects` | List includes `test_obj` |

---

## 9. Unity Integration

> **Why `IGameAPI` interface?** Every game script holds an `IGameAPI` reference, never `GameAPI` directly. This means: (a) scripts are testable — pass a mock implementation, (b) the network layer can be swapped (e.g., replace WebSocket with WebRTC) without changing any game script, (c) the contract is explicit — the interface is the source of truth for what methods exist.

### 9.1 Network file inventory

| File | Lines | Purpose |
|---|---|---|
| `IGameAPI.cs` | 329 | Interface — 29 methods + 10 events + XML docs |
| `GameAPI.cs` | ~770 | Full implementation — REST via `UnityWebRequest`, WebSocket via `ClientWebSocket` with STOMP |
| `NetworkConstants.cs` | 106 | All URL/type/status constants — mirrors `AppConstants.java` |
| `DTO/` (16 files) | ~300 | All request/response DTOs with `[Serializable]` for `JsonUtility` |
| `MockLoginManager.cs` | ~185 | Auth UI → auto-creates `GameAPI` singleton if missing, delegates Login/Register, wired to `Login_register_page.unity` scene |
| `MultiplayerTestDriver.cs` | ~230 | Automated 6-phase multiplayer test |

### 9.2 WebSocket event wiring pattern

```csharp
// In your game script (e.g., MultiplayerSync.cs)
private IGameAPI _api;

void Start()
{
    _api = GameAPI.Instance;

    // SUBSCRIBE FIRST — messages arrive immediately after ConnectWebSocket
    _api.OnPositionReceived += HandleOpponentPosition;
    _api.OnCombatActionReceived += HandleOpponentCombat;
    _api.OnHealthReceived += HandleOpponentHealth;
    _api.OnEnemySpawned += HandleEnemySpawn;
    _api.OnEnemyDespawned += HandleEnemyDespawn;
    _api.OnSessionReady += HandleSessionReady;
    _api.OnOpponentDisconnected += HandleDisconnect;

    // THEN connect
    _api.ConnectWebSocket(_api.CurrentSessionId);
}

void OnDisable()
{
    // ALWAYS unsubscribe — prevents memory leaks and stale references
    if (_api != null)
    {
        _api.OnPositionReceived -= HandleOpponentPosition;
        _api.OnCombatActionReceived -= HandleOpponentCombat;
        _api.OnHealthReceived -= HandleOpponentHealth;
        _api.OnEnemySpawned -= HandleEnemySpawn;
        _api.OnEnemyDespawned -= HandleEnemyDespawn;
        _api.OnSessionReady -= HandleSessionReady;
        _api.OnOpponentDisconnected -= HandleDisconnect;
    }
}
```

### 9.3 Position send loop (100ms interval)

> **Why 100ms (10 updates/sec)?** Every frame (60fps = 16ms) is too fast — it saturates the WebSocket and MySQL with writes for no gameplay benefit. 100ms gives smooth movement while keeping server load manageable. For fast-paced combat actions, send immediately (don't batch).

```csharp
IEnumerator PositionSendLoop()
{
    while (true)
    {
        yield return new WaitForSeconds(0.1f);
        if (_api.IsWebSocketConnected)
            _api.SendPosition(transform.position.x, transform.position.y, facingDirection);
    }
}
```

### 9.4 Verify Unity → Server communication

1. Start Spring Boot server
2. Open Unity, load `Login_register_page.unity` scene
3. ✓ Verify `LoginController` GameObject in Inspector shows all fields populated:
   - **Username Input** → UserName (TMP_InputField)
   - **Password Input** → Password (TMP_InputField)
   - **Login Button** → Login (Button)
   - **Register Button** → Button (Button) — *the "Register" button*
   - **Status Text** → None (assign a TMP_Text for on-screen feedback)
   - **Next Scene Name** → Main_Menu_main
4. Press Play → check Console for `[MockLoginManager] Created GameAPI singleton`
5. Enter username + password → click Register or Login
6. ✓ Unity Console: `[Auth] Registration in progress...` / `[Auth] Login in progress...`
7. ✓ If backend is running: `[GameAPI] Register success: playerId=1`
8. ✓ If backend is offline: Status shows error message instead of crash
9. On auth success, scene transitions to `Main_Menu_main`

### 9.5 Login Scene Bootstrap (How It Works)

When `Login_register_page.unity` is the first scene loaded:

1. **`MockLoginManager.Awake()`** calls `GetOrCreateAPI()` which checks `GameAPI.Instance`
2. If `null` (no GameAPI in scene) → creates a new `GameObject("GameAPI")` with `GameAPI` component → `DontDestroyOnLoad` applies automatically
3. **`MockLoginManager.Start()`** assigns `_api = GameAPI.Instance` (now non-null) and wires button click listeners
4. **Register button** (`registerButton`) is connected to the "Register" button's `onClick` event → calls `HandleRegistration()`
5. **Login button** is connected to the Login button → calls `HandleLogin()`
6. Both handlers validate input, then delegate to `_api.Login()` / `_api.Register()` via `StartCoroutine`
7. GameAPI sends the REST request; `OnAuthComplete` callback stores the JWT token and loads the next scene

This auto-creation pattern means the login scene can be the *very first* scene in the build — no bootstrap/init scene required.

---

## 10. Multiplayer — Two Clients on One Machine

> **The question:** "How do I prove two players are actually syncing through the server, and not just seeing local illusions?"  
> **The answer:** Run TWO separate game processes — Unity Editor as Player 1 (Host), a standalone build as Player 2 (Guest). Both connect to `localhost:8080`. The server routes messages between them. You can watch the Spring Boot console log messages arriving from BOTH players, and query MySQL to see BOTH players' positions being updated in real time.

### 10.1 Architecture — Two Clients, One Machine

```
┌──────────────────────────────────────────────────────┐
│                  YOUR COMPUTER                       │
│                                                      │
│  ┌─────────────────┐     ┌──────────────────┐        │
│  │  Unity Editor   │     │  Standalone Build │        │
│  │  Player 1 (Host)│     │  Player 2 (Guest) │        │
│  │  localPlayerId=1│     │  localPlayerId=2  │        │
│  └────────┬────────┘     └────────┬─────────┘        │
│           │ REST + WS             │ REST + WS         │
│           │ :8080                 │ :8080             │
│           └───────────┬───────────┘                   │
│                       ▼                               │
│  ┌────────────────────────────────────────┐          │
│  │        Spring Boot (localhost:8080)     │          │
│  │  GameSocketHandler routes messages     │          │
│  │  between session subscribers           │          │
│  └────────────────┬───────────────────────┘          │
│                   ▼                                   │
│  ┌────────────────────────────────────────┐          │
│  │     MySQL (localhost:3306)              │          │
│  │  player_world_state — both positions   │          │
│  │  sessions — WAITING→ACTIVE→CLOSED      │          │
│  └────────────────────────────────────────┘          │
└──────────────────────────────────────────────────────┘
```

> **How the server tells them apart:** Each connection sends a different `playerId` in every WebSocket message. The server doesn't care about IP addresses — it cares about `senderId`. Player 1 sends `senderId=1`, Player 2 sends `senderId=2`. When the server broadcasts, both receive the message. Each client checks `senderId != LocalPlayerId` and ignores its own messages.

### 10.2 Creating the Player 2 Build

**Step 1 — Build Settings**

1. **File → Build Settings**
2. **Add Open Scenes** — include ALL scenes (`Login_register_page`, `Main_Menu_main`, game scenes)
3. Target: `Windows, Mac, Linux` → Architecture: `Intel 64-bit`
4. ✓ CHECK: **Development Build** — enables `Debug.Log` output in the build
5. ✓ CHECK: **Run in Background** (Project Settings → Player → Resolution) — Player 2 keeps running when unfocused
6. Click **Build** → save to `D:\Unity Projects\Aoop Game\Build\`

**Step 2 — Launch script with log output**

Create `run_player2.bat` next to the `.exe`:

```batch
@echo off
REM Run Player 2 in a smaller window with full debug logging
set "LOG=%USERPROFILE%\Desktop\wasteland_player2.log"
echo === Player 2 started at %date% %time% === > "%LOG%"
"Aoop Game.exe" -logFile "%LOG%" -screen-width 960 -screen-height 540
echo === Player 2 exited at %date% %time% === >> "%LOG%"
pause
```

> **Why `-screen-width 960 -screen-height 540`?** This is exactly half of 1920×1080. Both windows fit side by side on a single 1080p monitor. Player 1 (Unity Editor Game view) at 960×540 on the left, Player 2 (standalone build) at 960×540 on the right.

**Step 3 — Verify both launch**

| Client | Launch method | Register as |
|---|---|---|
| **Player 1** | Unity Editor → Play button | `host_player` |
| **Player 2** | Double-click `run_player2.bat` | `guest_player` |

Both should see the login screen and reach the game.

### 10.3 Automated Test Driver

The `MultiplayerTestDriver.cs` script (already in `Assets/Scripts/`) automates the full 6-phase flow. Attach it to a GameObject:

1. **Player 1 (Editor):** Create empty GameObject → attach `MultiplayerTestDriver` → set `Is Host = true`
2. **Player 2 (Build):** Same script is already in the build → `Is Host = false` by default

#### What the test does

| Phase | Host (Editor) | Guest (Build) |
|---|---|---|
| **1. Auth** | Registers as `mp_host` | Registers as `mp_guest_XXX` |
| **2. Lobby** | Creates world + lobby, writes join key to `PlayerPrefs` | Reads join key from `PlayerPrefs`, joins lobby |
| **3. Start** | Calls `StartSession()` → ACTIVE | *(waits)* |
| **4. WebSocket** | Connects + subscribes to session topic | Connects + subscribes to session topic |
| **5. Position** | Sends position every 100ms (bounces 0→5→0) | Sends position every 100ms (bounces 5→0→5) |
| **6. Combat** | Sends combat action, enemy spawn, health update | Receives all three from host |

### 10.4 Expected Console Output

**Player 1 (Unity Editor Console):**
```
[MPTest] === Phase 1: Auth (isHost=True) ===
[GameAPI] Register success: playerId=1 username=mp_host
[MPTest] === Phase 2: Create World ===
[GameAPI] Lobby created! sessionId=SESS_A1B2C3D4 joinKey=XK9M2P
[MPTest] === Phase 3: Start Session ===
[GameAPI] Session started! status=ACTIVE
[MPTest] === Phase 4: Connect WebSocket ===
[GameAPI] WebSocket connected + subscribed to session SESS_A1B2C3D4
[MPTest] ← SESSION_READY — both players connected!
[MPTest] === Phase 5: Sending position every 100ms ===
[MPTest] ← POSITION from senderId=2    ← RECEIVING PLAYER 2's POSITION!
[MPTest] ← POSITION from senderId=2
[MPTest] === Phase 6: Host sends combat + enemy spawn ===
```

**Player 2 (log file `wasteland_player2.log`):**
```
[MPTest] === Phase 1: Auth (isHost=False) ===
[GameAPI] Register success: playerId=2 username=mp_guest_847
[MPTest] === Phase 2: Waiting for host lobby... ===
[MPTest] Read join key from PlayerPrefs: XK9M2P
[GameAPI] Lobby joined! sessionId=SESS_A1B2C3D4
[MPTest] === Phase 4: Connect WebSocket ===
[GameAPI] WebSocket connected + subscribed to session SESS_A1B2C3D4
[MPTest] ← SESSION_READY — both players connected!
[MPTest] === Phase 5: Sending position every 100ms ===
[MPTest] ← POSITION from senderId=1    ← RECEIVING PLAYER 1's POSITION!
[MPTest] ← COMBAT from senderId=1      ← HOST's COMBAT ACTION!
[MPTest] ← HEALTH from senderId=1      ← HOST's HEALTH UPDATE!
[MPTest] ← ENEMY_SPAWN                 ← HOST SPAWNED AN ENEMY!
```

### 10.5 Server-Side Proof (Spring Boot Console)

```
[AuthController] POST /register — username: mp_host
[Auth] New player registered: id=1 username=mp_host
[LobbyController] POST /create — ownerId=1 worldId=WORLD_TEST_MP
[Lobby] Session created: id=SESS_A1B2C3D4 joinKey=XK9M2P
[AuthController] POST /register — username: mp_guest_847
[LobbyController] POST /join/XK9M2P — guestId=2
[Lobby] Guest joined: sessionId=SESS_A1B2C3D4 guestId=2
[LobbyController] POST /start/SESS_A1B2C3D4 — ownerId=1
[Lobby] Session started: sessionId=SESS_A1B2C3D4 status=ACTIVE
[GameSocketHandler] WebSocket connection opened
[GameSocketHandler] type=POSITION session=SESS_A1B2C3D4 sender=1
[GameSocketHandler] type=POSITION session=SESS_A1B2C3D4 sender=2
[Sync] Position saved: playerId=1 pos=(0.1,0.0) facing=1
[Sync] Position saved: playerId=2 pos=(4.9,0.0) facing=1
```

> **This is the definitive proof:** The server is receiving messages from two different `senderId` values (1 and 2), and `SyncServiceImpl` is persisting both to MySQL. The messages aren't local illusions — they traveled over TCP through the server.

### 10.6 Database Proof (MySQL)

```sql
-- Two different players, both registered during the test
SELECT id, username, has_played_intro FROM players WHERE username LIKE 'mp_%';

-- One session, ACTIVE, with both players
SELECT session_id, join_key, status, owner_id, guest_id FROM sessions WHERE status = 'ACTIVE';

-- BOTH players' positions are being updated in real time
SELECT player_id, position_x, position_y, updated_at
FROM player_world_state WHERE world_id = 'WORLD_TEST_MP';

-- Enemy spawned by the host exists in the database
SELECT enemy_id, type_id, position_x, position_y, is_alive
FROM enemy_instances WHERE world_id = 'WORLD_TEST_MP';
```

### 10.7 Troubleshooting

| Problem | Root cause | Fix |
|---|---|---|
| Player 2 can't reach server | Build uses wrong URL | Verify `NetworkConstants.BASE_URL = "http://localhost:8080/api/v1"` |
| Both clients get same playerId | PlayerPrefs collision (rare on same machine) | Editor uses registry `HKCU\Software\Unity\UnityEditor`, Build uses `HKCU\Software\<Company>\<GameName>` — naturally separate |
| WebSocket 404 | SockJS info endpoint not found | Try `ws://localhost:8080/ws/game/websocket` (SockJS raw WS endpoint) |
| `JoinLobby` returns 404 | Guest reads stale join key | Increase `WaitForSeconds` in guest script to give host time to write to PlayerPrefs |
| Position not received | Wrong STOMP subscription destination | Verify destination is `/topic/session/{sessionId}` (case-sensitive) |
| Build crashes on start | Missing scenes | File → Build Settings → Add Open Scenes for ALL scenes in the game |

### 10.8 Manual Testing (Without Test Script)

If you prefer testing through actual game UI:

1. **Start server** → `mvn spring-boot:run`
2. **Player 1 (Editor)** → Press Play → Login/Register → Enter game world → Open multiplayer lobby
3. **Player 2 (Build)** → Launch `.exe` → Login with DIFFERENT username → Enter game → Join lobby (enter join key shown on Player 1's screen)
4. **Both see "Session Ready"** → game loads
5. **Move both characters** → each player sees the other's movement in real time

**Proof points that multiplayer is real:**
- ✓ Player 1 attacks → Player 2 sees the combat effect
- ✓ Player 1 damages an enemy → enemy health changes on Player 2's screen
- ✓ Close Player 2 → Player 1 sees "Opponent Disconnected"
- ✓ `SELECT status FROM sessions` → `CLOSED`
- ✓ `SELECT position_x, position_y FROM player_world_state` → both players' last positions persisted

---

## 11. Known Issues & Caveats

### 11.1 Schema Notes (Entity vs v2 SQL)

| Issue | Status | Detail |
|---|---|---|
| ~~`PlayerEntity` had `currentHealth`/`maxHealth` not in v2 `players` table~~ | ✅ **FIXED** | Removed from `PlayerEntity`. Health is now exclusively in `player_world_state` (3NF). |
| `InventoryEntity` maps to old `inventories` table vs v2's direct `inventory_items`→`item_definitions` FK | Known | Two different schema designs — the entity uses the old one, the v2 SQL uses the new one. Hibernate creates both. Full migration needs entity refactoring to match v2. |

### 11.2 Lombok `sun.misc.Unsafe` Warnings

```
WARNING: sun.misc.Unsafe::objectFieldOffset has been called by lombok.permit.Permit
```

> **Root cause:** Lombok uses `Unsafe` internally for bytecode generation. Java 23+ deprecated `Unsafe` for removal. These are **compile-time warnings only** — they don't affect runtime behavior or generated code correctness. Lombok maintainers are tracking this in [issue #3393](https://github.com/projectlombok/lombok/issues/3393).

### 11.3 In-Memory State (Lost on Restart)

| State | Storage | Survives restart? |
|---|---|---|
| JWT token blacklist | `ConcurrentHashMap` in `AuthServiceImpl` | ❌ No — blacklisted tokens become valid again until they expire |
| Combat cooldowns | `ConcurrentHashMap` in `CombatServiceImpl` | ❌ No — player can attack immediately after restart |
| Frenzy state | `ConcurrentHashMap` in `CombatServiceImpl` | ❌ No — frenzy bonus resets to 0 |
| Lobby sessions | MySQL `sessions` table | ✓ Yes |
| Player stats | MySQL `player_world_state` table | ✓ Yes |
| Enemy instances | MySQL `enemy_instances` table | ✓ Yes |
| Quest progress | MySQL `quests` table | ✓ Yes |

> **Production fix:** Replace in-memory maps with Redis. Redis survives restarts and works across multiple server instances. The `ConcurrentHashMap` pattern is intentionally simple for development.

### 11.4 No Authentication Filter

The endpoints do NOT currently enforce JWT validation. The `AuthService.validateToken()` method exists and is fully implemented, but there's no Spring Security filter calling it on each request. This is intentional for local development (you can test everything without managing tokens).

> **Production fix:** Add a `OncePerRequestFilter` that reads `Authorization: Bearer XXX`, calls `authService.validateToken(token)`, and returns 401 if invalid. This is ~30 lines of code in a single filter class.

---

## 12. Complete REST API Reference

### Authentication
| Method | Path | Body/Params | Response |
|---|---|---|---|
| `POST` | `/api/v1/auth/register` | `{"username":"...","password":"..."}` | `AuthResponse` (201) |
| `POST` | `/api/v1/auth/login` | `{"username":"...","password":"..."}` | `AuthResponse` (200) |
| `POST` | `/api/v1/auth/logout` | Header: `Authorization: Bearer {token}` | `{"message":"..."}` (200) |

### Worlds
| Method | Path | Params |
|---|---|---|
| `POST` | `/api/v1/worlds/create` | `?ownerId=&worldName=` |
| `GET` | `/api/v1/worlds/{id}` | `?playerId=` |
| `POST` | `/api/v1/worlds/{id}/save` | `?playerId=` + JSON body |

### Lobby
| Method | Path | Params |
|---|---|---|
| `POST` | `/api/v1/lobby/create` | `CreateLobbyRequest` body |
| `POST` | `/api/v1/lobby/join/{key}` | `JoinLobbyRequest` body |
| `GET` | `/api/v1/lobby/status/{id}` | — |
| `POST` | `/api/v1/lobby/start/{id}` | `?ownerId=` |

### Players
| Method | Path | Params |
|---|---|---|
| `GET` | `/api/v1/players/{id}/stats` | `?worldId=` |
| `POST` | `/api/v1/players/{id}/stats/update` | `?worldId=` + body |
| `GET` | `/api/v1/players/{id}/exp` | `?worldId=` |
| `POST` | `/api/v1/players/{id}/exp/add` | `?worldId=&amount=` |
| `GET` | `/api/v1/players/{id}/intro-played` | — |
| `POST` | `/api/v1/players/{id}/intro-played` | — |

### Combat
| Method | Path | Params |
|---|---|---|
| `POST` | `/api/v1/combat/attack` | `?playerId=&worldId=&attackPointX=&attackPointY=&weaponRange=&actionType=ATTACK\|MELEE&meleeDamage=2` |
| `GET` | `/api/v1/combat/frenzy-state/{id}` | `?worldId=` |

### Ammo
| Method | Path | Params |
|---|---|---|
| `GET` | `/api/v1/players/{id}/ammo` | `?worldId=` |
| `POST` | `/api/v1/players/{id}/ammo/consume` | `?worldId=` |
| `POST` | `/api/v1/players/{id}/ammo/reload` | `?worldId=` |
| `POST` | `/api/v1/players/{id}/ammo/add` | `?worldId=&amount=` |

### Enemies
| Method | Path | Params |
|---|---|---|
| `GET` | `/api/v1/enemies/types` | — |
| `GET` | `/api/v1/enemies/types/{id}` | — |
| `GET` | `/api/v1/enemies/instances` | `?worldId=` |
| `GET` | `/api/v1/enemies/instances/alive` | `?worldId=` |
| `POST` | `/api/v1/enemies/instances/spawn` | `?worldId=&typeId=&x=&y=` |
| `POST` | `/api/v1/enemies/instances/{id}/damage` | `?amount=` |

### Quest
| Method | Path | Params |
|---|---|---|
| `GET` | `/api/v1/worlds/{id}/quest` | — |
| `POST` | `/api/v1/worlds/{id}/quest/activate` | — |
| `POST` | `/api/v1/worlds/{id}/quest/enemy-killed` | `?isBoss=` |
| `POST` | `/api/v1/worlds/{id}/quest/hand-in` | — |

### Boss
| Method | Path | Params |
|---|---|---|
| `GET` | `/api/v1/worlds/{id}/boss` | — |
| `POST` | `/api/v1/worlds/{id}/boss/start` | `?bossEnemyId=` |
| `POST` | `/api/v1/worlds/{id}/boss/phase2` | — |
| `POST` | `/api/v1/worlds/{id}/boss/defeat` | — |

### Dialogue & NPC
| Method | Path | Params |
|---|---|---|
| `GET` | `/api/v1/npcs` | — |
| `GET` | `/api/v1/npcs/{actorId}` | — |
| `GET` | `/api/v1/npcs/{npcId}/dialogue` | `?questState=` |
| `GET` | `/api/v1/dialogues/{dialogueId}` | — |

### Persistence
| Method | Path |
|---|---|
| `GET` | `/api/v1/worlds/{id}/destroyed-objects` |
| `GET` | `/api/v1/worlds/{id}/destroyed-objects/{objectId}` |
| `POST` | `/api/v1/worlds/{id}/destroyed-objects/{objectId}` |

### Inventory
| Method | Path | Params |
|---|---|---|
| `GET` | `/api/v1/inventory/{playerId}` | `?worldId=` |
| `POST` | `/api/v1/inventory/{playerId}` | InventoryDTO body |

### WebSocket
| Endpoint | Protocol | Sub-protocol |
|---|---|---|
| `ws://localhost:8080/ws/game` | WebSocket | STOMP v1.1/v1.2 |

---

## Quick Verification Script

Run this PowerShell script against a running server. It calls 22 endpoints and prints DB verification queries:

```powershell
powershell -ExecutionPolicy Bypass -File verify_all.ps1
```

The script is located at: `wasteland-survivors-backend/verify_all.ps1`

---

*Guide updated 2026-06-08. Backend: 93 Java source files, 42 REST endpoints, 1 WebSocket endpoint with 13 message types. Unity: 46 C# scripts including 16 DTOs, test driver, full GameAPI implementation, wired login/register GUI with auto-bootstrap, and two-phase boss fight system (Boss_Scream.mp3).*
