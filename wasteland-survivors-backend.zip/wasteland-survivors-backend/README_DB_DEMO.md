# Wasteland Survivors — DB Demo

This demo proves database connectivity with three flows:
- Register
- Login
- Inventory save/load

## Prerequisites
- MySQL running locally
- Database created: `wasteland_survivors`

## Configure DB
Set environment variables (PowerShell):

```powershell
$env:DB_URL = "jdbc:mysql://localhost:3306/wasteland_survivors?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC"
$env:DB_USERNAME = "root"
$env:DB_PASSWORD = "password"
```

## Run the backend

```powershell
$env:JAVA_HOME = "C:\Program Files\Java\jdk-26.0.1"
Push-Location "D:\Unity Projects\Aoop Game\wasteland-survivors-backend"
& "C:\Program Files\apache-maven-3.9.16\bin\mvn.cmd" spring-boot:run
Pop-Location
```

## Run the demo script

```powershell
Push-Location "D:\Unity Projects\Aoop Game\wasteland-survivors-backend"
.\scripts\demo_db.ps1
Pop-Location
```

## Test Game Save/Load

After registering and logging in, test the unified save/load:

```powershell
# Save game state (substitute actual IDs from register/login response)
$body = @{
    playerId = 1
    worldId = "WORLD_DEFAULT"
    currentHealth = 18
    maxHealth = 20
    damage = 1.5
    weaponRange = 3.5
    speed = 5.0
    positionX = 12.3
    positionY = 4.7
    facingDirection = 1
    currentScene = "village_scene_1"
    experience = 150
    level = 2
    expToLevel = 12
    expGrowthMultiplier = 1.2
    currentClip = 25
    maxClipSize = 30
    totalAmmoReserve = 55
    questState = 1
    zombiesRemaining = 8
    isBossAlive = $true
    fightStarted = $false
    isDefeated = $false
    currentPhase = 1
    phase2Activated = $false
    destroyedObjectIds = @("HealthPack_10_5", "GoldBar_3_2")
} | ConvertTo-Json

$bodyJson = $body
Invoke-RestMethod -Uri "http://localhost:8080/api/v1/gamesave/save" -Method Post -Body $bodyJson -ContentType "application/json"

# Load game state
Invoke-RestMethod -Uri "http://localhost:8080/api/v1/gamesave/load/1?worldId=WORLD_DEFAULT" -Method Get | ConvertTo-Json -Depth 5
```

## Verify in MySQL

```sql
SELECT * FROM players ORDER BY id DESC LIMIT 5;
SELECT * FROM inventories ORDER BY id DESC LIMIT 5;
SELECT * FROM inventory_items ORDER BY id DESC LIMIT 10;
SELECT * FROM player_world_state ORDER BY id DESC LIMIT 5;
SELECT * FROM player_progression ORDER BY id DESC LIMIT 5;
SELECT * FROM player_ammo ORDER BY id DESC LIMIT 5;
```

